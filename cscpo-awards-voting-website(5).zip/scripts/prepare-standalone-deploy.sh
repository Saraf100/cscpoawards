#!/usr/bin/env sh
set -eu

ROOT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
STANDALONE_DIR="$ROOT_DIR/.next/standalone"

if [ ! -f "$STANDALONE_DIR/server.js" ]; then
  echo "Standalone server is missing. Run 'npm run build' first."
  exit 1
fi

mkdir -p "$STANDALONE_DIR/public" "$STANDALONE_DIR/.next/static"
cp -R "$ROOT_DIR/public/." "$STANDALONE_DIR/public/"
cp -R "$ROOT_DIR/.next/static/." "$STANDALONE_DIR/.next/static/"

cat <<EOF
Standalone deployment prepared at:
  $STANDALONE_DIR

Transfer the contents to a Node.js application's app root (not a static-only public_html folder).
Set NODE_ENV=production and DATABASE_URL in the hosting provider's private environment,
configure server.js as the startup file, and start/restart the Node application.
EOF
