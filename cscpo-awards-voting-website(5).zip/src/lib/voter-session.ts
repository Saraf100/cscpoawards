import { createHmac, timingSafeEqual } from "node:crypto";

export const VOTER_SESSION_COOKIE = "cscpo_voter_session";
const SESSION_LIFETIME_SECONDS = 60 * 60 * 24 * 30;

export interface VoterSessionPayload {
  voterId: number;
  email: string;
  name: string;
  authProvider: "GOOGLE" | "FACEBOOK" | "EMAIL_OTP";
  country: string;
  exp: number;
}

export function getVoterSessionSecret() {
  const secret = process.env.VOTER_SESSION_SECRET || process.env.DATABASE_URL;
  if (!secret || secret.length < 24) {
    throw new Error("Set VOTER_SESSION_SECRET (at least 24 characters) for voter sessions.");
  }
  return secret;
}

function sign(payload: string) {
  return createHmac("sha256", getVoterSessionSecret()).update(payload).digest("base64url");
}

export function createVoterSession(payload: Omit<VoterSessionPayload, "exp">) {
  const session: VoterSessionPayload = {
    ...payload,
    exp: Math.floor(Date.now() / 1000) + SESSION_LIFETIME_SECONDS,
  };
  const encoded = Buffer.from(JSON.stringify(session)).toString("base64url");
  return `${encoded}.${sign(encoded)}`;
}

export function readVoterSession(token?: string | null): VoterSessionPayload | null {
  if (!token) return null;
  const [encoded, signature, extra] = token.split(".");
  if (!encoded || !signature || extra) return null;

  try {
    const expectedSignature = sign(encoded);
    const actual = Buffer.from(signature);
    const expected = Buffer.from(expectedSignature);
    if (actual.length !== expected.length || !timingSafeEqual(actual, expected)) return null;

    const payload = JSON.parse(Buffer.from(encoded, "base64url").toString("utf8")) as VoterSessionPayload;
    if (!payload.voterId || !payload.email || !payload.exp || payload.exp <= Math.floor(Date.now() / 1000)) {
      return null;
    }
    return payload;
  } catch {
    return null;
  }
}

export function voterSessionCookieOptions() {
  return {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax" as const,
    path: "/",
    maxAge: SESSION_LIFETIME_SECONDS,
  };
}
