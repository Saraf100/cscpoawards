import { createHmac, randomBytes, timingSafeEqual } from "node:crypto";
import { getVoterSessionSecret, VoterSessionPayload } from "@/lib/voter-session";

interface ChallengePayload {
  voterId: number;
  answer: number;
  nonce: string;
  exp: number;
}

function sign(encoded: string) {
  return createHmac("sha256", getVoterSessionSecret()).update(`vote-captcha:${encoded}`).digest("base64url");
}

export function createVoteChallenge(voterId: number) {
  const first = Math.floor(Math.random() * 8) + 2;
  const second = Math.floor(Math.random() * 8) + 2;
  const payload: ChallengePayload = {
    voterId,
    answer: first + second,
    nonce: randomBytes(16).toString("hex"),
    exp: Math.floor(Date.now() / 1000) + 5 * 60,
  };
  const encoded = Buffer.from(JSON.stringify(payload)).toString("base64url");
  return { first, second, token: `${encoded}.${sign(encoded)}` };
}

export function verifyVoteChallenge(token: string | undefined, answer: unknown, session: VoterSessionPayload) {
  if (!token || answer === undefined || answer === null) return false;
  const [encoded, providedSignature, extra] = token.split(".");
  if (!encoded || !providedSignature || extra) return false;

  try {
    const expectedSignature = sign(encoded);
    const provided = Buffer.from(providedSignature);
    const expected = Buffer.from(expectedSignature);
    if (provided.length !== expected.length || !timingSafeEqual(provided, expected)) return false;

    const payload = JSON.parse(Buffer.from(encoded, "base64url").toString("utf8")) as ChallengePayload;
    return payload.voterId === session.voterId &&
      payload.exp > Math.floor(Date.now() / 1000) &&
      Number(answer) === payload.answer;
  } catch {
    return false;
  }
}
