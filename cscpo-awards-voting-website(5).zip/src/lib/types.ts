export interface Category {
  id: number;
  slug: string;
  name: string;
  nameBn?: string | null;
  description: string;
  icon?: string | null;
  displayOrder: number;
  isActive: boolean;
  maxNominees?: number | null;
  createdAt?: Date | string;
  nomineeCount?: number;
  totalVotes?: number;
}

export interface Nominee {
  id: number;
  slug: string;
  refNumber: string;
  categoryId: number | null;
  categoryName?: string | null;
  name: string;
  designation: string;
  organization: string;
  country: string;
  email: string;
  mobile: string;
  photoUrl: string;
  achievementSummary: string;
  whyNominate: string;
  experienceYears: number;
  bio?: string | null;
  careerHistory?: string | null;
  supplyChainContributions?: string | null;
  supportingDocuments?: unknown;
  linkedinUrl?: string | null;
  websiteUrl?: string | null;
  status: string; // PENDING, APPROVED, REJECTED, DRAFT
  rejectionReason?: string | null;
  isVerified: boolean;
  isFeatured: boolean;
  voteCount: number;
  rank: number;
  nominatorName?: string | null;
  nominatorEmail?: string | null;
  nominatorRelation?: string | null;
  createdAt: Date | string;
  updatedAt: Date | string;
}

export interface Voter {
  id: number;
  email: string;
  name: string;
  authProvider: string;
  providerId?: string | null;
  avatarUrl?: string | null;
  phone?: string | null;
  country: string;
  isIdentityVerified: boolean;
  status: string;
  voteCountTotal: number;
}

export interface SponsorLogo {
  id: string;
  name: string;
  tier: string; // "Title Sponsor" | "Platinum Sponsor" | "Gold Sponsor" | "Associate Sponsor"
  logoUrl: string;
  websiteUrl?: string;
}

export interface SupportLogo {
  id: string;
  name: string;
  role: string; // "Strategic Partner" | "Academic Partner" | "Media Partner" | "Industry Association" | "Technology Partner"
  logoUrl: string;
  websiteUrl?: string;
}

export interface VotingSettings {
  id: number;
  votingStatus: string;
  votingStartDate: Date | string;
  votingEndDate: Date | string;
  votingPolicy: string;
  showPublicCounts: boolean;
  showPublicRankings: boolean;
  requireCaptcha: boolean;
  allowNominationDrafts: boolean;
  nominationDeadline: Date | string;
  announcementText?: string | null;
  bannerTitle?: string | null;
  bannerSubtitle?: string | null;
  logoUrl?: string | null;
  sponsorLogos?: SponsorLogo[];
  supportLogos?: SupportLogo[];
  updatedAt?: Date | string;
}

export interface VoteRecord {
  id: number;
  voterId: number;
  nomineeId: number;
  categoryId: number;
  voterEmail: string;
  ipAddress?: string | null;
  userAgent?: string | null;
  verificationMethod: string;
  isFraud: boolean;
  fraudReason?: string | null;
  isValid: boolean;
  revokedReason?: string | null;
  revokedBy?: string | null;
  createdAt: Date | string;
  nomineeName?: string;
  categoryName?: string;
}
