import { pgTable, serial, varchar, text, integer, boolean, timestamp, jsonb, index } from "drizzle-orm/pg-core";

export const categories = pgTable("categories", {
  id: serial("id").primaryKey(),
  slug: varchar("slug", { length: 120 }).notNull().unique(),
  name: varchar("name", { length: 255 }).notNull(),
  nameBn: varchar("name_bn", { length: 255 }),
  description: text("description").notNull(),
  icon: varchar("icon", { length: 64 }).default("Award"),
  displayOrder: integer("display_order").default(0).notNull(),
  isActive: boolean("is_active").default(true).notNull(),
  maxNominees: integer("max_nominees").default(50),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const nominees = pgTable("nominees", {
  id: serial("id").primaryKey(),
  slug: varchar("slug", { length: 150 }).notNull().unique(),
  refNumber: varchar("ref_number", { length: 64 }).notNull().unique(),
  categoryId: integer("category_id").references(() => categories.id),
  categoryName: varchar("category_name", { length: 255 }),
  name: varchar("name", { length: 255 }).notNull(),
  designation: varchar("designation", { length: 255 }).notNull(),
  organization: varchar("organization", { length: 255 }).notNull(),
  country: varchar("country", { length: 100 }).notNull(),
  email: varchar("email", { length: 255 }).notNull(),
  mobile: varchar("mobile", { length: 50 }).notNull(),
  photoUrl: text("photo_url").notNull(),
  achievementSummary: text("achievement_summary").notNull(),
  whyNominate: text("why_nominate").notNull(),
  experienceYears: integer("experience_years").default(5).notNull(),
  bio: text("bio"),
  careerHistory: text("career_history"),
  supplyChainContributions: text("supply_chain_contributions"),
  supportingDocuments: jsonb("supporting_documents").default([]),
  linkedinUrl: varchar("linkedin_url", { length: 500 }),
  websiteUrl: varchar("website_url", { length: 500 }),
  status: varchar("status", { length: 32 }).default("PENDING").notNull(), // PENDING, APPROVED, REJECTED, DRAFT
  rejectionReason: text("rejection_reason"),
  isVerified: boolean("is_verified").default(true).notNull(),
  isFeatured: boolean("is_featured").default(false).notNull(),
  voteCount: integer("vote_count").default(0).notNull(),
  rank: integer("rank").default(0).notNull(),
  nominatorName: varchar("nominator_name", { length: 255 }),
  nominatorEmail: varchar("nominator_email", { length: 255 }),
  nominatorRelation: varchar("nominator_relation", { length: 100 }),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const voters = pgTable("voters", {
  id: serial("id").primaryKey(),
  email: varchar("email", { length: 255 }).notNull().unique(),
  name: varchar("name", { length: 255 }).notNull(),
  authProvider: varchar("auth_provider", { length: 50 }).default("EMAIL_OTP").notNull(), // GOOGLE, FACEBOOK, EMAIL_OTP, PHONE_OTP
  providerId: varchar("provider_id", { length: 255 }),
  avatarUrl: text("avatar_url"),
  phone: varchar("phone", { length: 50 }),
  country: varchar("country", { length: 100 }).default("Bangladesh"),
  isIdentityVerified: boolean("is_identity_verified").default(false).notNull(),
  ipAddress: varchar("ip_address", { length: 100 }),
  userAgent: text("user_agent"),
  status: varchar("status", { length: 32 }).default("ACTIVE").notNull(), // ACTIVE, FLAGGED, SUSPENDED
  suspiciousReason: text("suspicious_reason"),
  voteCountTotal: integer("vote_count_total").default(0).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  lastVotedAt: timestamp("last_voted_at"),
});

export const emailOtpRequests = pgTable(
  "email_otp_requests",
  {
    id: serial("id").primaryKey(),
    email: varchar("email", { length: 255 }).notNull(),
    name: varchar("name", { length: 255 }).notNull(),
    codeHash: varchar("code_hash", { length: 128 }).notNull(),
    attempts: integer("attempts").default(0).notNull(),
    requestedIp: varchar("requested_ip", { length: 100 }),
    expiresAt: timestamp("expires_at").notNull(),
    consumedAt: timestamp("consumed_at"),
    createdAt: timestamp("created_at").defaultNow().notNull(),
  },
  (table) => ({ emailCreatedAtIdx: index("email_otp_requests_email_created_idx").on(table.email, table.createdAt) })
);

export const votes = pgTable("votes", {
  id: serial("id").primaryKey(),
  voterId: integer("voter_id").references(() => voters.id).notNull(),
  nomineeId: integer("nominee_id").references(() => nominees.id).notNull(),
  categoryId: integer("category_id").references(() => categories.id).notNull(),
  voterEmail: varchar("voter_email", { length: 255 }).notNull(),
  ipAddress: varchar("ip_address", { length: 100 }),
  userAgent: text("user_agent"),
  deviceFingerprint: varchar("device_fingerprint", { length: 255 }),
  verificationMethod: varchar("verification_method", { length: 50 }).default("EMAIL_OTP").notNull(),
  isFraud: boolean("is_fraud").default(false).notNull(),
  fraudReason: text("fraud_reason"),
  isValid: boolean("is_valid").default(true).notNull(),
  revokedReason: text("revoked_reason"),
  revokedBy: varchar("revoked_by", { length: 100 }),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const votingSettings = pgTable("voting_settings", {
  id: serial("id").primaryKey(),
  votingStatus: varchar("voting_status", { length: 32 }).default("OPEN").notNull(), // OPEN, PAUSED, CLOSED, SCHEDULED
  votingStartDate: timestamp("voting_start_date").notNull(),
  votingEndDate: timestamp("voting_end_date").notNull(),
  votingPolicy: varchar("voting_policy", { length: 64 }).default("ONE_VOTE_PER_CATEGORY").notNull(), // ONE_VOTE_PER_CATEGORY, ONE_VOTE_PER_NOMINEE, ONE_VOTE_OVERALL
  showPublicCounts: boolean("show_public_counts").default(true).notNull(),
  showPublicRankings: boolean("show_public_rankings").default(true).notNull(),
  requireCaptcha: boolean("require_captcha").default(true).notNull(),
  allowNominationDrafts: boolean("allow_nomination_drafts").default(true).notNull(),
  nominationDeadline: timestamp("nomination_deadline").notNull(),
  announcementText: text("announcement_text"),
  bannerTitle: varchar("banner_title", { length: 255 }).default("CSCPO South Asian Leadership Awards"),
  bannerSubtitle: text("banner_subtitle").default("Recognizing Visionary Leadership, Operational Excellence & Innovation Across South Asia"),
  logoUrl: text("logo_url").default("/images/cscpo-award-logo.png"),
  sponsorLogos: jsonb("sponsor_logos").default([]),
  supportLogos: jsonb("support_logos").default([]),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const notificationsLog = pgTable("notifications_log", {
  id: serial("id").primaryKey(),
  recipientEmail: varchar("recipient_email", { length: 255 }).notNull(),
  recipientName: varchar("recipient_name", { length: 255 }).notNull(),
  subject: varchar("subject", { length: 255 }).notNull(),
  type: varchar("type", { length: 64 }).notNull(), // NOMINATION_SUBMITTED, NOMINATION_APPROVED, NOMINATION_REJECTED, VOTE_CONFIRMATION, ADMIN_ALERT
  body: text("body").notNull(),
  refNumber: varchar("ref_number", { length: 64 }),
  status: varchar("status", { length: 32 }).default("DELIVERED").notNull(),
  sentAt: timestamp("sent_at").defaultNow().notNull(),
});

export const adminAuditLogs = pgTable("admin_audit_logs", {
  id: serial("id").primaryKey(),
  action: varchar("action", { length: 64 }).notNull(),
  performedBy: varchar("performed_by", { length: 100 }).default("CSCPO Administrator").notNull(),
  details: text("details").notNull(),
  ipAddress: varchar("ip_address", { length: 100 }).default("127.0.0.1"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const previousWinners = pgTable("previous_winners", {
  id: serial("id").primaryKey(),
  year: integer("year").notNull(),
  categoryName: varchar("category_name", { length: 255 }).notNull(),
  winnerName: varchar("winner_name", { length: 255 }).notNull(),
  designation: varchar("designation", { length: 255 }).notNull(),
  organization: varchar("organization", { length: 255 }).notNull(),
  country: varchar("country", { length: 100 }).notNull(),
  photoUrl: text("photo_url").notNull(),
  achievement: text("achievement").notNull(),
});
