"use client";

import React, { useState } from "react";
import { Nominee } from "@/lib/types";
import { X, Copy, Check, Download, QrCode, Share2, ExternalLink } from "lucide-react";

interface ShareModalProps {
  nominee: Nominee | null;
  isOpen: boolean;
  onClose: () => void;
}

export default function ShareModal({ nominee, isOpen, onClose }: ShareModalProps) {
  const [copied, setCopied] = useState(false);
  const [activeTab, setActiveTab] = useState<"LINKS" | "QR" | "POSTER">("LINKS");

  if (!isOpen || !nominee) return null;

  const origin = typeof window !== "undefined" ? window.location.origin : "https://cscpo.org/cscpobdawards2026";
  const votingUrl = `${origin}/nominee/${nominee.slug}`;
  const shareText = `Support outstanding South Asian Supply Chain Leadership! Cast your vote for ${nominee.name} (${nominee.designation}, ${nominee.organization}) in the CSCPO South Asian Leadership Awards. Vote here: ${votingUrl}`;

  const copyUrl = () => {
    navigator.clipboard.writeText(votingUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadPoster = () => {
    // Canvas flyer generator
    const canvas = document.createElement("canvas");
    canvas.width = 1080;
    canvas.height = 1350;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    // Background gradient
    const bgGradient = ctx.createLinearGradient(0, 0, 0, 1350);
    bgGradient.addColorStop(0, "#090d16");
    bgGradient.addColorStop(0.5, "#0f172a");
    bgGradient.addColorStop(1, "#1c1404");
    ctx.fillStyle = bgGradient;
    ctx.fillRect(0, 0, 1080, 1350);

    // Decorative borders
    ctx.strokeStyle = "#d4af37";
    ctx.lineWidth = 6;
    ctx.strokeRect(40, 40, 1000, 1270);
    ctx.strokeStyle = "rgba(212, 175, 55, 0.4)";
    ctx.lineWidth = 2;
    ctx.strokeRect(52, 52, 976, 1246);

    // Header Title
    ctx.fillStyle = "#d4af37";
    ctx.font = "bold 32px sans-serif";
    ctx.textAlign = "center";
    ctx.fillText("CSCPO SOUTH ASIAN LEADERSHIP AWARDS", 540, 120);

    ctx.fillStyle = "#94a3b8";
    ctx.font = "20px sans-serif";
    ctx.fillText("OFFICIAL PUBLIC VOTING NOMINEE CAMPAIGN", 540, 160);

    // Award Category Badge
    ctx.fillStyle = "#1e293b";
    ctx.roundRect(140, 200, 800, 50, 12);
    ctx.fill();
    ctx.strokeStyle = "#f59e0b";
    ctx.lineWidth = 1;
    ctx.stroke();

    ctx.fillStyle = "#fbbf24";
    ctx.font = "bold 22px sans-serif";
    ctx.fillText(nominee.categoryName || "Leadership Award", 540, 233);

    // Nominee Name
    ctx.fillStyle = "#ffffff";
    ctx.font = "bold 52px sans-serif";
    ctx.fillText(nominee.name, 540, 340);

    // Designation & Organization
    ctx.fillStyle = "#cbd5e1";
    ctx.font = "28px sans-serif";
    ctx.fillText(`${nominee.designation}`, 540, 395);

    ctx.fillStyle = "#94a3b8";
    ctx.font = "24px sans-serif";
    ctx.fillText(`${nominee.organization} · ${nominee.country}`, 540, 435);

    // Verified badge
    ctx.fillStyle = "#10b981";
    ctx.font = "bold 20px sans-serif";
    ctx.fillText("✓ VERIFIED CSCPO FINALIST NOMINEE", 540, 485);

    // Big CTA Box
    ctx.fillStyle = "rgba(212, 175, 55, 0.15)";
    ctx.fillRect(100, 540, 880, 520);
    ctx.strokeStyle = "#d4af37";
    ctx.lineWidth = 3;
    ctx.strokeRect(100, 540, 880, 520);

    ctx.fillStyle = "#fbbf24";
    ctx.font = "bold 38px sans-serif";
    ctx.fillText("CAST YOUR VERIFIED VOTE ONLINE", 540, 620);

    ctx.fillStyle = "#ffffff";
    ctx.font = "22px sans-serif";
    ctx.fillText("Every verified vote honors South Asian operational excellence.", 540, 670);

    // Key stats
    ctx.fillStyle = "#0f172a";
    ctx.roundRect(240, 720, 600, 160, 16);
    ctx.fill();
    ctx.strokeStyle = "#334155";
    ctx.stroke();

    ctx.fillStyle = "#d4af37";
    ctx.font = "bold 64px sans-serif";
    ctx.fillText(`#${nominee.voteCount.toLocaleString()}`, 540, 795);

    ctx.fillStyle = "#94a3b8";
    ctx.font = "20px sans-serif";
    ctx.fillText("TOTAL LIVE VOTES RECORDED", 540, 845);

    // Footer URL & QR notice
    ctx.fillStyle = "#ffffff";
    ctx.font = "bold 26px sans-serif";
    ctx.fillText(votingUrl, 540, 940);

    ctx.fillStyle = "#64748b";
    ctx.font = "18px sans-serif";
    ctx.fillText("Organized by Council of Supply Chain Professionals Organization (CSCPO)", 540, 1220);
    ctx.fillText("Voting verified by Google, Facebook & Secure OTP authentication", 540, 1250);

    const link = document.createElement("a");
    link.download = `CSCPO-Campaign-Poster-${nominee.slug}.png`;
    link.href = canvas.toDataURL("image/png");
    link.click();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-fade-in">
      <div className="relative w-full max-w-md bg-slate-900 border border-amber-500/30 rounded-2xl shadow-2xl text-slate-100 overflow-hidden flex flex-col">
        {/* Header */}
        <div className="p-5 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center space-x-2.5">
            <Share2 className="w-5 h-5 text-amber-400" />
            <h3 className="font-bold text-white text-base">Share Voting Link</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex border-b border-slate-800 px-5 pt-3 space-x-4 text-xs font-semibold">
          <button
            onClick={() => setActiveTab("LINKS")}
            className={`pb-2.5 border-b-2 transition ${
              activeTab === "LINKS" ? "border-amber-400 text-amber-400" : "border-transparent text-slate-400 hover:text-white"
            }`}
          >
            Social Channels
          </button>
          <button
            onClick={() => setActiveTab("QR")}
            className={`pb-2.5 border-b-2 transition ${
              activeTab === "QR" ? "border-amber-400 text-amber-400" : "border-transparent text-slate-400 hover:text-white"
            }`}
          >
            QR Code
          </button>
          <button
            onClick={() => setActiveTab("POSTER")}
            className={`pb-2.5 border-b-2 transition ${
              activeTab === "POSTER" ? "border-amber-400 text-amber-400" : "border-transparent text-slate-400 hover:text-white"
            }`}
          >
            Campaign Flyer
          </button>
        </div>

        {/* Tab Contents */}
        <div className="p-6 space-y-5">
          {activeTab === "LINKS" && (
            <div className="space-y-4">
              <p className="text-xs text-slate-400">
                Share directly to your social and professional network to garner verified votes for{" "}
                <span className="text-white font-semibold">{nominee.name}</span>.
              </p>

              <div className="grid grid-cols-2 gap-2.5">
                {/* LinkedIn */}
                <a
                  href={`https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(votingUrl)}`}
                  target="_blank"
                  rel="noreferrer"
                  className="p-3 rounded-xl bg-[#0077b5] hover:bg-[#006097] text-white font-medium text-xs flex items-center justify-center space-x-2 transition"
                >
                  <span>LinkedIn</span>
                  <ExternalLink className="w-3 h-3" />
                </a>

                {/* WhatsApp */}
                <a
                  href={`https://api.whatsapp.com/send?text=${encodeURIComponent(shareText)}`}
                  target="_blank"
                  rel="noreferrer"
                  className="p-3 rounded-xl bg-[#25D366] hover:bg-[#20ba59] text-white font-medium text-xs flex items-center justify-center space-x-2 transition"
                >
                  <span>WhatsApp</span>
                  <ExternalLink className="w-3 h-3" />
                </a>

                {/* Facebook */}
                <a
                  href={`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(votingUrl)}`}
                  target="_blank"
                  rel="noreferrer"
                  className="p-3 rounded-xl bg-[#1877F2] hover:bg-[#1465cc] text-white font-medium text-xs flex items-center justify-center space-x-2 transition"
                >
                  <span>Facebook</span>
                  <ExternalLink className="w-3 h-3" />
                </a>

                {/* X / Twitter */}
                <a
                  href={`https://twitter.com/intent/tweet?text=${encodeURIComponent(shareText)}`}
                  target="_blank"
                  rel="noreferrer"
                  className="p-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-medium text-xs flex items-center justify-center space-x-2 transition border border-slate-700"
                >
                  <span>X (Twitter)</span>
                  <ExternalLink className="w-3 h-3" />
                </a>
              </div>

              {/* Direct Link Copy */}
              <div className="space-y-1.5 pt-2">
                <label className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                  Direct Nominee Voting URL
                </label>
                <div className="flex items-center space-x-2">
                  <input
                    type="text"
                    readOnly
                    value={votingUrl}
                    className="flex-1 bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-300 font-mono truncate select-all"
                  />
                  <button
                    onClick={copyUrl}
                    className="p-2.5 bg-amber-500 hover:bg-amber-600 text-slate-950 rounded-xl font-bold text-xs flex items-center space-x-1 cursor-pointer transition shrink-0"
                  >
                    {copied ? <Check className="w-4 h-4 text-slate-950" /> : <Copy className="w-4 h-4" />}
                    <span>{copied ? "Copied" : "Copy"}</span>
                  </button>
                </div>
              </div>
            </div>
          )}

          {activeTab === "QR" && (
            <div className="space-y-4 text-center">
              <p className="text-xs text-slate-400">
                Scan this QR code with any smartphone camera to open {nominee.name}&rsquo;s voting profile instantly.
              </p>

              {/* Generated SVG QR Code representation */}
              <div className="bg-white p-5 rounded-2xl inline-block mx-auto shadow-xl border-4 border-amber-400/50">
                <div className="w-44 h-44 bg-slate-900 rounded-lg p-2 flex flex-col items-center justify-center text-white relative">
                  <QrCode className="w-36 h-36 text-white" />
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="bg-amber-500 p-1.5 rounded-md border-2 border-slate-900 shadow">
                      <span className="text-[10px] font-bold text-slate-950 uppercase">CSCPO</span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="text-xs text-slate-300 font-mono">
                Ref: <span className="text-amber-400 font-bold">{nominee.refNumber}</span>
              </div>
            </div>
          )}

          {activeTab === "POSTER" && (
            <div className="space-y-4 text-center">
              <p className="text-xs text-slate-400">
                Generate and download an official high-resolution nominee campaign poster ready for Instagram, LinkedIn,
                and corporate newsletters.
              </p>

              <div className="p-4 bg-slate-950 border border-slate-800 rounded-xl text-left space-y-2 text-xs">
                <div className="text-amber-400 font-semibold flex items-center space-x-1.5">
                  <span>✓ 1080x1350 High-Resolution Canvas</span>
                </div>
                <p className="text-slate-300">
                  Includes nominee name, category, official CSCPO seal, current vote stats, and direct voting link.
                </p>
              </div>

              <button
                onClick={handleDownloadPoster}
                className="w-full py-3 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-bold text-xs uppercase tracking-wider flex items-center justify-center space-x-2 transition shadow-lg shadow-amber-500/20"
              >
                <Download className="w-4 h-4" />
                <span>Download Official Campaign Poster (PNG)</span>
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
