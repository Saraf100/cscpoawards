"use client";

import React, { createContext, useCallback, useContext, useEffect, useState } from "react";
import { Voter } from "@/lib/types";

interface VoterAuthContextType {
  voter: Voter | null;
  isLoading: boolean;
  loginWithEmailOtp: (email: string, code: string, name?: string) => Promise<Voter>;
  refreshSession: () => Promise<Voter | null>;
  logout: () => Promise<void>;
  votedCategoryIds: number[];
  votedNomineeIds: number[];
  recordLocalVote: (categoryId: number, nomineeId: number) => void;
}

const VoterAuthContext = createContext<VoterAuthContextType>({
  voter: null,
  isLoading: true,
  loginWithEmailOtp: async () => { throw new Error("Voter authentication is not ready."); },
  refreshSession: async () => null,
  logout: async () => {},
  votedCategoryIds: [],
  votedNomineeIds: [],
  recordLocalVote: () => {},
});

export function VoterAuthProvider({ children }: { children: React.ReactNode }) {
  const [voter, setVoter] = useState<Voter | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [votedCategoryIds, setVotedCategoryIds] = useState<number[]>([]);
  const [votedNomineeIds, setVotedNomineeIds] = useState<number[]>([]);

  const refreshSession = useCallback(async () => {
    try {
      const response = await fetch("/api/auth/session", { cache: "no-store", credentials: "same-origin" });
      const result = await response.json();
      const nextVoter = response.ok && result.success && result.authenticated ? (result.voter as Voter) : null;
      setVoter(nextVoter);
      return nextVoter;
    } catch (error) {
      console.error("Unable to restore voter session:", error);
      setVoter(null);
      return null;
    }
  }, []);

  useEffect(() => {
    try {
      const savedCategories = localStorage.getItem("cscpo_voted_cats");
      if (savedCategories) setVotedCategoryIds(JSON.parse(savedCategories));
      const savedNominees = localStorage.getItem("cscpo_voted_noms");
      if (savedNominees) setVotedNomineeIds(JSON.parse(savedNominees));
      // Old browser-only demo credentials are intentionally not trusted or restored.
      localStorage.removeItem("cscpo_voter");
    } catch (error) {
      console.error("Unable to restore voter UI state:", error);
    }

    refreshSession().finally(() => setIsLoading(false));
  }, [refreshSession]);

  const loginWithEmailOtp = async (email: string, code: string, name?: string): Promise<Voter> => {
    const response = await fetch("/api/auth/email-otp", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      credentials: "same-origin",
      body: JSON.stringify({ action: "verify", email, code, name }),
    });
    const result = await response.json();
    if (!response.ok || !result.success || !result.voter) {
      throw new Error(result.error || "Email verification failed. Please request a new code.");
    }
    const nextVoter = result.voter as Voter;
    setVoter(nextVoter);
    return nextVoter;
  };

  const logout = async () => {
    try {
      await fetch("/api/auth/logout", { method: "POST", credentials: "same-origin" });
    } finally {
      setVoter(null);
      localStorage.removeItem("cscpo_voter");
    }
  };

  const recordLocalVote = (categoryId: number, nomineeId: number) => {
    setVotedCategoryIds((prev) => {
      const updated = Array.from(new Set([...prev, categoryId]));
      localStorage.setItem("cscpo_voted_cats", JSON.stringify(updated));
      return updated;
    });
    setVotedNomineeIds((prev) => {
      const updated = Array.from(new Set([...prev, nomineeId]));
      localStorage.setItem("cscpo_voted_noms", JSON.stringify(updated));
      return updated;
    });
    if (voter) {
      setVoter({ ...voter, voteCountTotal: (voter.voteCountTotal || 0) + 1 });
    }
  };

  return (
    <VoterAuthContext.Provider
      value={{ voter, isLoading, loginWithEmailOtp, refreshSession, logout, votedCategoryIds, votedNomineeIds, recordLocalVote }}
    >
      {children}
    </VoterAuthContext.Provider>
  );
}

export function useVoterAuth() {
  return useContext(VoterAuthContext);
}
