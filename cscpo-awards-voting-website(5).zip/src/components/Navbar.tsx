"use client";

import React, { useState } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useLanguage } from "./LanguageContext";
import { useVoterAuth } from "./VoterAuthContext";
import {
  Award,
  Vote,
  FileText,
  Trophy,
  BarChart3,
  Shield,
  Menu,
  X,
  UserCheck,
  LogOut,
  ExternalLink,
  BookOpen,
  Globe,
} from "lucide-react";
import VotingModal from "./VotingModal";

export default function Navbar() {
  const pathname = usePathname();
  const { lang, setLang, t } = useLanguage();
  const { voter, logout } = useVoterAuth();

  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [quickAuthOpen, setQuickAuthOpen] = useState(false);
  const [awardTitle, setAwardTitle] = useState("CSCPO South Asian Leadership Awards");
  const [awardLogo, setAwardLogo] = useState("/images/cscpo-award-logo.png");

  React.useEffect(() => {
    fetch("/api/admin/settings")
      .then((res) => res.json())
      .then((data) => {
        if (data.success && data.data) {
          if (data.data.bannerTitle) setAwardTitle(data.data.bannerTitle);
          if (data.data.logoUrl) setAwardLogo(data.data.logoUrl);
        }
      })
      .catch(() => {});
  }, []);

  const navLinks = [
    { href: "/", label: t("home") },
    { href: "/voting", label: t("voting") },
    { href: "/nominate", label: t("nominate") },
    { href: "/results", label: t("results") },
    { href: "/winners", label: t("winners") },
    { href: "/srs", label: t("srs") },
    { href: "/admin", label: t("admin") },
    { href: "/access", label: "Access & Keys" },
  ];

  return (
    <>
      {/* Top Banner Ribbon */}
      <div className="bg-gradient-to-r from-amber-600 via-amber-500 to-amber-700 text-slate-950 px-4 py-1.5 text-xs font-semibold flex items-center justify-between">
        <div className="container mx-auto flex items-center justify-between text-[11px] md:text-xs">
          <div className="flex items-center space-x-2 truncate">
            <span className="bg-slate-950 text-amber-400 font-bold px-1.5 py-0.5 rounded text-[10px] uppercase tracking-wide">
              Official Portal
            </span>
            <span className="truncate">
              {awardTitle} · Host Chapter: Bangladesh & South Asia
            </span>
          </div>
          <div className="flex items-center space-x-2 sm:space-x-3 shrink-0">
            <Link
              href="/admin"
              className="inline-flex items-center space-x-1 px-2 py-0.5 rounded bg-slate-950 text-amber-300 font-bold hover:bg-slate-900 transition text-[10px] sm:text-xs"
              title="Organizer Admin Portal Login"
            >
              <Shield className="w-3 h-3 text-amber-400" />
              <span>Admin Login</span>
            </Link>

            <a
              href="https://cscpo.org/cscpobdawards2026/"
              target="_blank"
              rel="noreferrer"
              className="hidden sm:inline-flex items-center space-x-1 hover:underline text-slate-950 font-bold"
            >
              <span>Main Site</span>
              <ExternalLink className="w-3 h-3" />
            </a>

            {/* Language switch */}
            <button
              onClick={() => setLang(lang === "en" ? "bn" : "en")}
              className="flex items-center space-x-1 px-2 py-0.5 rounded bg-slate-950/20 hover:bg-slate-950/30 font-bold"
            >
              <Globe className="w-3 h-3" />
              <span>{lang === "en" ? "বাংলা" : "English"}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main Nav */}
      <header className="sticky top-0 z-40 bg-slate-950/90 backdrop-blur-md border-b border-slate-800">
        <div className="container mx-auto px-4 h-18 flex items-center justify-between">
          {/* Logo & Brand */}
          <Link href="/" className="flex items-center space-x-3 group">
            <div className="w-11 h-11 rounded-full bg-gradient-to-br from-amber-400 to-amber-600 p-0.5 shadow-lg shadow-amber-500/20">
              <div className="w-full h-full rounded-full bg-slate-950 flex items-center justify-center overflow-hidden">
                <img
                  src={awardLogo}
                  alt="CSCPO Awards Crest"
                  className="w-10 h-10 object-contain"
                  onError={(e) => {
                    // Fallback to default
                    (e.target as HTMLImageElement).src = "/images/cscpo-award-logo.png";
                  }}
                />
              </div>
            </div>
            <div>
              <div className="font-extrabold text-base md:text-lg tracking-tight text-white flex items-center space-x-1.5">
                <span>CSCPO</span>
                <span className="text-amber-400">Leadership Awards</span>
              </div>
              <div className="text-[10px] text-slate-400 tracking-wider uppercase font-medium">
                South Asian Leadership
              </div>
            </div>
          </Link>

          {/* Desktop Nav Links */}
          <nav className="hidden lg:flex items-center space-x-1">
            {navLinks.map((link) => {
              const isActive = pathname === link.href;
              return (
                <Link
                  key={link.href}
                  href={link.href}
                  className={`px-3 py-2 rounded-xl text-xs font-semibold transition ${
                    isActive
                      ? "bg-amber-500/10 text-amber-400 border border-amber-500/20"
                      : "text-slate-300 hover:text-white hover:bg-slate-900"
                  }`}
                >
                  {link.label}
                </Link>
              );
            })}
          </nav>

          {/* Right Actions: Voter Status & CTA */}
          <div className="hidden sm:flex items-center space-x-3">
            {voter ? (
              <div className="flex items-center space-x-2 bg-slate-900 border border-emerald-500/30 rounded-xl px-3 py-1.5 text-xs">
                <UserCheck className="w-4 h-4 text-emerald-400" />
                <div className="text-left">
                  <div className="text-slate-200 font-bold text-[11px] truncate max-w-[120px]">{voter.name}</div>
                  <div className="text-[9px] text-emerald-400">Verified Voter</div>
                </div>
                <button
                  onClick={logout}
                  title="Sign out"
                  className="p-1 text-slate-400 hover:text-white rounded hover:bg-slate-800 transition"
                >
                  <LogOut className="w-3.5 h-3.5" />
                </button>
              </div>
            ) : (
              <button
                onClick={() => setQuickAuthOpen(true)}
                className="px-3 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-200 text-xs font-semibold flex items-center space-x-1.5 cursor-pointer"
              >
                <Shield className="w-3.5 h-3.5 text-amber-400" />
                <span>Verify Voter</span>
              </button>
            )}

            <Link
              href="/voting"
              className="px-4 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 text-xs font-bold shadow-md shadow-amber-500/20 transition flex items-center space-x-1.5"
            >
              <Vote className="w-4 h-4" />
              <span>Vote Now</span>
            </Link>
          </div>

          {/* Mobile menu button */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="lg:hidden p-2 text-slate-300 hover:text-white rounded-lg hover:bg-slate-900"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {/* Mobile Dropdown */}
        {mobileMenuOpen && (
          <div className="lg:hidden bg-slate-950 border-b border-slate-800 px-4 py-4 space-y-2 animate-fade-in">
            {navLinks.map((link) => {
              const isActive = pathname === link.href;
              return (
                <Link
                  key={link.href}
                  href={link.href}
                  onClick={() => setMobileMenuOpen(false)}
                  className={`block px-3 py-2.5 rounded-xl text-sm font-semibold ${
                    isActive ? "bg-amber-500/20 text-amber-300" : "text-slate-300 hover:bg-slate-900"
                  }`}
                >
                  {link.label}
                </Link>
              );
            })}

            <div className="pt-2 border-t border-slate-800 flex flex-col space-y-2">
              <Link
                href="/voting"
                onClick={() => setMobileMenuOpen(false)}
                className="w-full py-2.5 rounded-xl bg-amber-500 text-slate-950 font-bold text-center text-sm"
              >
                Public Voting
              </Link>
              <Link
                href="/nominate"
                onClick={() => setMobileMenuOpen(false)}
                className="w-full py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white font-semibold text-center text-sm"
              >
                Submit Nomination
              </Link>
              <Link
                href="/admin"
                onClick={() => setMobileMenuOpen(false)}
                className="w-full py-2.5 rounded-xl bg-amber-500/20 border border-amber-500/40 text-amber-300 font-bold text-center text-sm flex items-center justify-center space-x-1.5"
              >
                <Shield className="w-4 h-4 text-amber-400" />
                <span>Admin Login Portal</span>
              </Link>
            </div>
          </div>
        )}
      </header>

      {/* Quick Voter Verification Modal Trigger */}
      {quickAuthOpen && (
        <VotingModal
          nominee={{
            id: 1,
            slug: "voter-verification",
            refNumber: "CSCPO-VERIFY",
            categoryId: 1,
            categoryName: "Identity Verification Portal",
            name: "Voter Authentication",
            designation: "Verified Professional",
            organization: "CSCPO South Asian Voting Ledger",
            country: "South Asia",
            email: "voter@example.com",
            mobile: "+880 1700 000000",
            photoUrl: "https://images.pexels.com/photos/28442318/pexels-photo-28442318.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
            achievementSummary: "Authenticate a Google/Facebook account or verify control of an email address. This action does not cast a vote.",
            whyNominate: "Verification",
            experienceYears: 10,
            status: "APPROVED",
            isVerified: true,
            isFeatured: false,
            voteCount: 0,
            rank: 1,
            createdAt: new Date(),
            updatedAt: new Date(),
          }}
          isOpen={quickAuthOpen}
          authOnly
          onClose={() => setQuickAuthOpen(false)}
        />
      )}
    </>
  );
}
