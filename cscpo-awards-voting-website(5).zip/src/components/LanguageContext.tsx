"use client";

import React, { createContext, useContext, useState, useEffect } from "react";

type Language = "en" | "bn";

interface LanguageContextType {
  lang: Language;
  setLang: (lang: Language) => void;
  t: (key: string) => string;
}

const translations: Record<Language, Record<string, string>> = {
  en: {
    home: "Home",
    about: "About Awards",
    categories: "Categories",
    nominees: "Nominees",
    voting: "Public Voting",
    results: "Results",
    nominate: "Submit Nomination",
    winners: "Past Winners",
    srs: "SRS Spec",
    admin: "Admin Portal",
    voteNow: "Vote Now",
    viewProfile: "View Profile",
    share: "Share",
    totalVotes: "Total Votes",
    currentPosition: "Honored Nominee",
    approvedNominee: "Approved Nominee",
    verifiedVoter: "Verified Voter",
    signInToVote: "Verify & Vote",
    votingClosesIn: "Voting Closes In",
    searchNominees: "Search nominee, designation, or company...",
    allCategories: "All Categories",
    allCountries: "All Countries",
    sortBy: "Sort By",
    mostVotes: "Most Votes",
    nameAZ: "Name (A-Z)",
    recent: "Recently Added",
    heroTitle: "CSCPO South Asian Leadership Awards",
    heroSubtitle: "Celebrating Visionary Supply Chain & Logistics Pioneers Shaping South Asia's Economic Future",
    officialHost: "Organized by Council of Supply Chain Professionals Organization (CSCPO)",
    embedNotice: "Voting is open to all verified South Asian and global professionals.",
  },
  bn: {
    home: "হোম",
    about: "অ্যাওয়ার্ড সম্পর্কে",
    categories: "ক্যাটাগরি",
    nominees: "মনোনীত ব্যক্তিবর্গ",
    voting: "পাবলিক ভোটিং",
    results: "ফলাফল",
    nominate: "মনোনয়ন জমা দিন",
    winners: "বিগত বিজয়ী",
    srs: "এসআরএস স্পেক",
    admin: "অ্যাডমিন প্যানেল",
    voteNow: "ভোট দিন",
    viewProfile: "প্রোফাইল দেখুন",
    share: "শেয়ার করুন",
    totalVotes: "সর্বমোট ভোট",
    currentPosition: "বর্তমান অবস্থান",
    approvedNominee: "অনুমোদিত নমিনি",
    verifiedVoter: "যাচাইকৃত ভোটার",
    signInToVote: "যাচাই করে ভোট দিন",
    votingClosesIn: "ভোটের সময় বাকি",
    searchNominees: "নমিনি, পদবী বা প্রতিষ্ঠান খুঁজুন...",
    allCategories: "সকল ক্যাটাগরি",
    allCountries: "সকল দেশ",
    sortBy: "সর্ট করুন",
    mostVotes: "সর্বোচ্চ ভোট",
    nameAZ: "নাম (অ-ক্ষর অনুযায়ী)",
    recent: "সাম্প্রতিক",
    heroTitle: "সিএসসিপিও সাউথ এশিয়ান লিডারশিপ অ্যাওয়ার্ড",
    heroSubtitle: "দক্ষিণ এশিয়ার সাপ্লাই চেইন ও লজিস্টিকস খাতের রূপান্তরমূলক নেতৃত্ব ও উদ্ভাবনের স্বীকৃতি",
    officialHost: "কাউন্সিল অব সাপ্লাই চেইন প্রফেশনালস অর্গানাইজেশন (CSCPO) কর্তৃক আয়োজিত",
    embedNotice: "সকল যাচাইকৃত দক্ষিণ এশীয় ও বৈশ্বিক পেশাদারদের জন্য ভোট উন্মুক্ত।",
  },
};

const LanguageContext = createContext<LanguageContextType>({
  lang: "en",
  setLang: () => {},
  t: (key: string) => key,
});

export function LanguageProvider({ children }: { children: React.ReactNode }) {
  const [lang, setLangState] = useState<Language>("en");

  useEffect(() => {
    const saved = localStorage.getItem("cscpo_lang") as Language;
    if (saved && (saved === "en" || saved === "bn")) {
      setLangState(saved);
    }
  }, []);

  const setLang = (newLang: Language) => {
    setLangState(newLang);
    localStorage.setItem("cscpo_lang", newLang);
  };

  const t = (key: string): string => {
    return translations[lang]?.[key] || translations["en"]?.[key] || key;
  };

  return (
    <LanguageContext.Provider value={{ lang, setLang, t }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  return useContext(LanguageContext);
}
