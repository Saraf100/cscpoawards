"use client";

import React, { useState, useEffect } from "react";
import { LanguageProvider } from "./LanguageContext";
import { VoterAuthProvider } from "./VoterAuthContext";
import Navbar from "./Navbar";
import Footer from "./Footer";

export default function ClientLayoutShell({ children }: { children: React.ReactNode }) {
  const [isEmbed, setIsEmbed] = useState(false);

  useEffect(() => {
    if (typeof window !== "undefined") {
      const params = new URLSearchParams(window.location.search);
      setIsEmbed(params.get("embed") === "true");
    }
  }, []);

  return (
    <LanguageProvider>
      <VoterAuthProvider>
        <div className="min-h-screen flex flex-col bg-slate-950 text-slate-100 font-sans selection:bg-amber-500 selection:text-slate-950">
          {!isEmbed && <Navbar />}
          <main className="flex-1">{children}</main>
          {!isEmbed && <Footer />}
        </div>
      </VoterAuthProvider>
    </LanguageProvider>
  );
}
