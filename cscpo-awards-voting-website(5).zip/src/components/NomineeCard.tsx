"use client";

import React, { useState } from "react";
import Link from "next/link";
import { Nominee } from "@/lib/types";
import { CheckCircle, Share2, Award, ChevronRight, Vote, Heart } from "lucide-react";
import VotingModal from "./VotingModal";
import ShareModal from "./ShareModal";

interface NomineeCardProps {
  nominee: Nominee;
  onVoteSuccess?: (nomineeId: number, newCount: number) => void;
}

export default function NomineeCard({
  nominee,
  onVoteSuccess,
}: NomineeCardProps) {
  const [isVotingOpen, setIsVotingOpen] = useState(false);
  const [isShareOpen, setIsShareOpen] = useState(false);
  const [currentVoteCount, setCurrentVoteCount] = useState(nominee.voteCount);

  const formattedVotes = currentVoteCount.toLocaleString();

  const handleVoteUpdated = (id: number, newCount: number) => {
    setCurrentVoteCount(newCount);
    if (onVoteSuccess) {
      onVoteSuccess(id, newCount);
    }
  };

  return (
    <>
      <div className="group relative bg-gradient-to-b from-slate-900 to-slate-950 border border-slate-800 hover:border-amber-500/50 rounded-2xl overflow-hidden shadow-lg hover:shadow-2xl hover:shadow-amber-500/10 transition-all duration-300 flex flex-col">
        {/* Top photo container */}
        <div className="relative h-64 w-full overflow-hidden bg-slate-950">
          <img
            src={nominee.photoUrl}
            alt={nominee.name}
            className="w-full h-full object-cover object-top transition-transform duration-500 group-hover:scale-105"
            loading="lazy"
            onError={(e) => {
              // fallback
              (e.target as HTMLImageElement).src =
                "https://images.pexels.com/photos/28442318/pexels-photo-28442318.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940";
            }}
          />

          {/* Gradient Overlay */}
          <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/20 to-transparent" />

          {/* Approved Badge */}
          <div className="absolute top-3 left-3 flex items-center space-x-1.5 px-2.5 py-1 rounded-full bg-slate-950/80 backdrop-blur-md border border-emerald-500/40 text-[11px] font-semibold text-emerald-400 shadow-md">
            <CheckCircle className="w-3.5 h-3.5 text-emerald-400" />
            <span>Approved Nominee</span>
          </div>

          {/* Country Pill */}
          <div className="absolute top-3 right-3 px-2.5 py-1 rounded-full bg-slate-950/80 backdrop-blur-md border border-slate-700 text-[11px] font-medium text-slate-300 shadow-md">
            {nominee.country}
          </div>

          {/* Category Tag on bottom of photo */}
          <div className="absolute bottom-3 left-3 right-3">
            <div className="inline-flex items-center space-x-1 px-2.5 py-1 rounded-md bg-amber-500/20 backdrop-blur-md border border-amber-500/30 text-[11px] font-semibold text-amber-300 max-w-full">
              <Award className="w-3 h-3 text-amber-400 shrink-0" />
              <span className="truncate">Category: {nominee.categoryName || "Supply Chain Leadership"}</span>
            </div>
          </div>
        </div>

        {/* Card Body */}
        <div className="p-5 flex-1 flex flex-col justify-between space-y-4">
          <div className="space-y-1.5">
            <h3 className="text-xl font-bold text-white group-hover:text-amber-400 transition-colors line-clamp-1">
              <Link href={`/nominee/${nominee.slug}`}>{nominee.name}</Link>
            </h3>
            <p className="text-sm font-medium text-slate-300 line-clamp-1">{nominee.designation}</p>
            <p className="text-xs text-slate-400 line-clamp-1">
              {nominee.organization} · {nominee.country}
            </p>

            {/* Achievement snippet */}
            <p className="text-xs text-slate-400 line-clamp-2 pt-2 leading-relaxed border-t border-slate-800/80">
              {nominee.achievementSummary}
            </p>
          </div>

          {/* Total Votes and Honored Distinction Blocks */}
          <div className="grid grid-cols-2 gap-2 pt-2 border-t border-slate-800">
            {/* Total Votes Box */}
            <div className="p-2.5 rounded-xl bg-slate-950/70 border border-slate-800/80 text-center">
              <div className="text-base font-extrabold text-amber-400 tracking-tight">
                # {formattedVotes}
              </div>
              <div className="text-[10px] uppercase font-semibold tracking-wider text-slate-400 mt-0.5">
                Total Votes
              </div>
            </div>

            {/* Honored Nominee Distinction Box */}
            <div className="p-2.5 rounded-xl bg-slate-950/70 border border-slate-800/80 text-center flex flex-col items-center justify-center">
              <div className="text-base font-extrabold text-emerald-400 tracking-tight flex items-center justify-center space-x-1">
                <span className="text-amber-400">★</span>
                <span>Finalist</span>
              </div>
              <div className="text-[10px] uppercase font-semibold tracking-wider text-slate-400 mt-0.5">
                Honored Nominee
              </div>
            </div>
          </div>

          {/* Action Buttons: View Profile | Vote Now | Share */}
          <div className="space-y-2 pt-1">
            <div className="grid grid-cols-2 gap-2">
              <Link
                href={`/nominee/${nominee.slug}`}
                className="py-2.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold text-center transition flex items-center justify-center space-x-1 border border-slate-700"
              >
                <span>View Profile</span>
                <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
              </Link>

              <button
                onClick={() => setIsVotingOpen(true)}
                className="py-2.5 px-3 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 text-xs font-bold text-center transition shadow-md shadow-amber-500/20 flex items-center justify-center space-x-1.5 cursor-pointer"
              >
                <Vote className="w-3.5 h-3.5" />
                <span>Vote Now</span>
              </button>
            </div>

            <button
              onClick={() => setIsShareOpen(true)}
              className="w-full py-2 px-3 rounded-xl bg-slate-950 hover:bg-slate-900 border border-slate-800 hover:border-slate-700 text-slate-400 hover:text-white text-xs font-medium transition flex items-center justify-center space-x-1.5 cursor-pointer"
            >
              <Share2 className="w-3.5 h-3.5 text-amber-400" />
              <span>Share Voting Link</span>
            </button>
          </div>
        </div>
      </div>

      {/* Voting Modal */}
      <VotingModal
        nominee={nominee}
        isOpen={isVotingOpen}
        onClose={() => setIsVotingOpen(false)}
        onVoteSuccess={handleVoteUpdated}
      />

      {/* Share Modal */}
      <ShareModal
        nominee={nominee}
        isOpen={isShareOpen}
        onClose={() => setIsShareOpen(false)}
      />
    </>
  );
}
