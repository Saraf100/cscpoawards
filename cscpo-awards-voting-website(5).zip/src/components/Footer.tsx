"use client";

import React, { useState } from "react";
import Link from "next/link";
import { ShieldCheck, Lock, Award, Code, Check, Copy, ExternalLink, Mail, MapPin } from "lucide-react";

export default function Footer() {
  const [showEmbedCode, setShowEmbedCode] = useState(false);
  const [copied, setCopied] = useState(false);
  const [footerLogo, setFooterLogo] = useState("/images/cscpo-award-logo.png");

  React.useEffect(() => {
    fetch("/api/admin/settings")
      .then((res) => res.json())
      .then((data) => {
        if (data.success && data.data?.logoUrl) {
          setFooterLogo(data.data.logoUrl);
        }
      })
      .catch(() => {});
  }, []);

  const embedSnippet = `<iframe 
  src="${typeof window !== "undefined" ? window.location.origin : "https://cscpo.org"}/voting?embed=true" 
  width="100%" 
  height="900" 
  frameborder="0" 
  style="border:none; border-radius:16px; overflow:hidden;"
  title="CSCPO South Asian Leadership Awards - Public Voting">
</iframe>`;

  const copyEmbed = () => {
    navigator.clipboard.writeText(embedSnippet);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <footer className="bg-slate-950 border-t border-slate-800 text-slate-400 text-xs">
      {/* 5 Core Principles Ribbon */}
      <div className="border-b border-slate-800/80 bg-slate-900/60 py-6">
        <div className="container mx-auto px-4">
          <div className="text-center mb-4">
            <span className="text-[10px] uppercase font-bold tracking-widest text-amber-400">
              Institutional Credibility & Integrity
            </span>
            <h4 className="text-sm font-bold text-white mt-0.5">
              5 Pillars of CSCPO Awards Voting Architecture
            </h4>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-5 gap-3 text-center">
            <div className="p-3 bg-slate-950/80 rounded-xl border border-slate-800/80 space-y-1">
              <div className="text-amber-400 font-bold text-xs">1. Verified Voters</div>
              <p className="text-[10px] text-slate-400">Strict Google, Facebook or Email OTP authentication.</p>
            </div>
            <div className="p-3 bg-slate-950/80 rounded-xl border border-slate-800/80 space-y-1">
              <div className="text-amber-400 font-bold text-xs">2. Live Transparency</div>
              <p className="text-[10px] text-slate-400">Real-time vote counts and audit trail verification.</p>
            </div>
            <div className="p-3 bg-slate-950/80 rounded-xl border border-slate-800/80 space-y-1">
              <div className="text-amber-400 font-bold text-xs">3. Fair Voting Policy</div>
              <p className="text-[10px] text-slate-400">One vote per category enforced at the database level.</p>
            </div>
            <div className="p-3 bg-slate-950/80 rounded-xl border border-slate-800/80 space-y-1">
              <div className="text-amber-400 font-bold text-xs">4. Anti-Fraud Shield</div>
              <p className="text-[10px] text-slate-400">IP velocity limits, CAPTCHA, and anomaly heuristics.</p>
            </div>
            <div className="p-3 bg-slate-950/80 rounded-xl border border-slate-800/80 space-y-1 col-span-2 md:col-span-1">
              <div className="text-amber-400 font-bold text-xs">5. Certified Results</div>
              <p className="text-[10px] text-slate-400">Independent jury validation and cryptographic ledger.</p>
            </div>
          </div>
        </div>
      </div>

      {/* Main Footer Links */}
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Brand Col */}
          <div className="space-y-4">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 rounded-full bg-gradient-to-br from-amber-400 to-amber-600 p-0.5">
                <div className="w-full h-full rounded-full bg-slate-950 flex items-center justify-center overflow-hidden">
                  <img
                    src={footerLogo}
                    alt="CSCPO Awards Crest"
                    className="w-9 h-9 object-contain"
                    onError={(e) => {
                      (e.target as HTMLImageElement).src = "/images/cscpo-award-logo.png";
                    }}
                  />
                </div>
              </div>
              <div>
                <h4 className="text-sm font-extrabold text-white">CSCPO Awards</h4>
                <p className="text-[10px] text-amber-400">chartered supply chain professionals</p>
              </div>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed">
              The premier platform celebrating benchmark leadership, operational resilience, and transformative supply
              chain impact across South Asia.
            </p>
            <div className="text-[11px] text-slate-500 space-y-1">
              <div className="flex items-center space-x-1.5">
                <MapPin className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                <span>CSCPO Regional Advisory Secretariat</span>
              </div>
              <div className="flex items-center space-x-1.5">
                <Mail className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                <span>secretariat@cscpo.org · awards@cscpo.org</span>
              </div>
            </div>
          </div>

          {/* Quick Links */}
          <div className="space-y-3">
            <h5 className="text-white font-bold text-xs uppercase tracking-wider">Navigation</h5>
            <ul className="space-y-2 text-xs">
              <li>
                <Link href="/" className="hover:text-amber-400 transition">
                  Awards Homepage
                </Link>
              </li>
              <li>
                <Link href="/voting" className="hover:text-amber-400 transition">
                  Public Voting Gallery
                </Link>
              </li>
              <li>
                <Link href="/nominate" className="hover:text-amber-400 transition">
                  Submit Online Nomination
                </Link>
              </li>
              <li>
                <Link href="/results" className="hover:text-amber-400 transition">
                  Live Voting Results & Leaderboard
                </Link>
              </li>
              <li>
                <Link href="/winners" className="hover:text-amber-400 transition">
                  Previous Award Winners Hall of Fame
                </Link>
              </li>
            </ul>
          </div>

          {/* Developer & Integration */}
          <div className="space-y-3">
            <h5 className="text-white font-bold text-xs uppercase tracking-wider">Specifications & Tech</h5>
            <ul className="space-y-2 text-xs">
              <li>
                <Link href="/srs" className="text-amber-400 font-semibold hover:underline flex items-center space-x-1">
                  <span>Software Requirements (SRS)</span>
                  <Code className="w-3 h-3" />
                </Link>
              </li>
              <li>
                <Link href="/admin" className="hover:text-amber-400 transition">
                  Organizer Admin Portal
                </Link>
              </li>
              <li>
                <Link href="/access" className="text-amber-400 hover:underline flex items-center space-x-1 font-semibold">
                  <span>Access Keys & Credentials Hub</span>
                </Link>
              </li>
              <li>
                <button
                  onClick={() => setShowEmbedCode(!showEmbedCode)}
                  className="hover:text-amber-400 transition text-left cursor-pointer flex items-center space-x-1"
                >
                  <span>Website Embed Snippet</span>
                  <ExternalLink className="w-3 h-3" />
                </button>
              </li>
              <li>
                <a
                  href="https://cscpo.org/cscpobdawards2026/"
                  target="_blank"
                  rel="noreferrer"
                  className="hover:text-amber-400 transition"
                >
                  Official Event Page (cscpo.org)
                </a>
              </li>
            </ul>
          </div>

          {/* Embed Mode Widget Preview */}
          <div className="space-y-3">
            <h5 className="text-white font-bold text-xs uppercase tracking-wider">Embed in cscpo.org</h5>
            <p className="text-xs text-slate-400 leading-relaxed">
              Integrate this verified voting gallery directly into <code>cscpo.org/cscpobdawards2026/</code> with full responsive support.
            </p>
            <button
              onClick={() => setShowEmbedCode(true)}
              className="py-2 px-3 rounded-xl bg-slate-900 hover:bg-slate-800 border border-amber-500/30 text-amber-300 font-semibold text-xs flex items-center space-x-2 transition cursor-pointer"
            >
              <Code className="w-3.5 h-3.5" />
              <span>Get Iframe Embed Code</span>
            </button>
          </div>
        </div>

        {/* Embed code modal popup */}
        {showEmbedCode && (
          <div className="mt-8 p-5 bg-slate-900 border border-amber-500/40 rounded-2xl animate-fade-in space-y-3">
            <div className="flex items-center justify-between">
              <h5 className="text-sm font-bold text-white flex items-center space-x-2">
                <Code className="w-4 h-4 text-amber-400" />
                <span>Responsive Embed Code for cscpo.org/cscpobdawards2026/</span>
              </h5>
              <button
                onClick={() => setShowEmbedCode(false)}
                className="text-xs text-slate-400 hover:text-white"
              >
                Close
              </button>
            </div>
            <pre className="p-3 bg-slate-950 rounded-xl text-slate-300 font-mono text-[11px] overflow-x-auto border border-slate-800">
              {embedSnippet}
            </pre>
            <div className="flex items-center justify-between">
              <span className="text-[11px] text-slate-400">
                Supports any CMS (WordPress, Drupal, custom HTML) and auto-adapts to mobile screen widths.
              </span>
              <button
                onClick={copyEmbed}
                className="px-3 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold text-xs flex items-center space-x-1 cursor-pointer"
              >
                {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? "Copied Snippet" : "Copy Code"}</span>
              </button>
            </div>
          </div>
        )}

        {/* Bottom copyright */}
        <div className="mt-12 pt-6 border-t border-slate-800/80 flex flex-col md:flex-row items-center justify-between text-[11px] text-slate-500 space-y-2 md:space-y-0">
          <div>
            © Chartered Supply Chain Professionals Organization (CSCPO). All rights reserved.
          </div>
          <div className="flex items-center space-x-4">
            <Link href="/srs" className="hover:text-slate-400">
              Developer SRS
            </Link>
            <span>·</span>
            <Link href="/results" className="hover:text-slate-400">
              Transparency
            </Link>
            <span>·</span>
            <Link href="/admin" className="hover:text-slate-400">
              Admin Access
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
