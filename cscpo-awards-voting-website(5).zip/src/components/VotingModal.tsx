"use client";

import React, { useState, useEffect } from "react";
import Image from "next/image";
import confetti from "canvas-confetti";
import { Nominee } from "@/lib/types";
import { useVoterAuth } from "./VoterAuthContext";
import {
  X,
  CheckCircle2,
  AlertCircle,
  ShieldCheck,
  Lock,
  Mail,
  Smartphone,
  Share2,
  Copy,
  Check,
  ExternalLink,
  Crown,
} from "lucide-react";

interface VotingModalProps {
  nominee: Nominee | null;
  isOpen: boolean;
  onClose: () => void;
  onVoteSuccess?: (nomineeId: number, newCount: number) => void;
  authOnly?: boolean;
}

export default function VotingModal({
  nominee,
  isOpen,
  onClose,
  onVoteSuccess,
  authOnly = false,
}: VotingModalProps) {
  const { voter, loginWithEmailOtp, recordLocalVote, isLoading: isVoterLoading } = useVoterAuth();

  const [authStep, setAuthStep] = useState<"SELECT_METHOD" | "EMAIL_OTP" | "CAPTCHA_CONFIRM" | "SUCCESS" | "AUTHENTICATED">("SELECT_METHOD");
  const [emailInput, setEmailInput] = useState("");
  const [nameInput, setNameInput] = useState("");
  const [otpCode, setOtpCode] = useState("");
  const [demoOtp, setDemoOtp] = useState("");
  const [isSendingOtp, setIsSendingOtp] = useState(false);
  const [isStartingSocialLogin, setIsStartingSocialLogin] = useState(false);
  const [otpSent, setOtpSent] = useState(false);

  // Server-signed anti-bot challenge
  const [captchaNum1, setCaptchaNum1] = useState(4);
  const [captchaNum2, setCaptchaNum2] = useState(7);
  const [captchaToken, setCaptchaToken] = useState("");
  const [isCaptchaLoading, setIsCaptchaLoading] = useState(false);
  const [userCaptcha, setUserCaptcha] = useState("");

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [eligibilityMessage, setEligibilityMessage] = useState<string | null>(null);
  const [alreadyVotedInCategory, setAlreadyVotedInCategory] = useState(false);
  const [receiptData, setReceiptData] = useState<{ receiptCode: string; timestamp: string; newVoteCount: number } | null>(
    null
  );
  const [copiedReceipt, setCopiedReceipt] = useState(false);

  // Reset the modal only when it opens (not whenever voter state changes).
  useEffect(() => {
    if (isOpen) {
      const n1 = Math.floor(Math.random() * 8) + 2;
      const n2 = Math.floor(Math.random() * 8) + 2;
      setCaptchaNum1(n1);
      setCaptchaNum2(n2);
      setCaptchaToken("");
      setUserCaptcha("");
      setErrorMessage(null);
      setEligibilityMessage(null);
      setAlreadyVotedInCategory(false);
      setReceiptData(null);
      setOtpSent(false);
      setOtpCode("");
      setDemoOtp("");
      setAuthStep("SELECT_METHOD");
    }
  }, [isOpen]);

  // Existing server-authenticated voters skip the method-selection step.
  useEffect(() => {
    if (isOpen && voter && authStep === "SELECT_METHOD") {
      setAuthStep(authOnly ? "AUTHENTICATED" : "CAPTCHA_CONFIRM");
    }
  }, [isOpen, voter?.id, authStep, authOnly]);

  const loadVoteChallenge = async () => {
    if (!voter) return;
    setIsCaptchaLoading(true);
    setCaptchaToken("");
    try {
      const response = await fetch("/api/votes/challenge", { cache: "no-store", credentials: "same-origin" });
      const result = await response.json();
      if (!response.ok || !result.success) {
        throw new Error(result.error || "Could not load the vote security challenge.");
      }
      setCaptchaNum1(result.data.first);
      setCaptchaNum2(result.data.second);
      setCaptchaToken(result.data.token);
      setUserCaptcha("");
      setErrorMessage(null);
    } catch (error) {
      setErrorMessage(error instanceof Error ? error.message : "Could not load the vote security challenge.");
    } finally {
      setIsCaptchaLoading(false);
    }
  };

  useEffect(() => {
    if (isOpen && voter && !authOnly && authStep === "CAPTCHA_CONFIRM") {
      void loadVoteChallenge();
    }
  }, [isOpen, voter?.id, authStep, authOnly]);

  useEffect(() => {
    let active = true;
    if (!isOpen || !voter || !nominee) {
      setAlreadyVotedInCategory(false);
      setEligibilityMessage(null);
      return () => { active = false; };
    }
    fetch(`/api/votes/check?nomineeId=${nominee.id}`, { cache: "no-store", credentials: "same-origin" })
      .then(async (response) => {
        const result = await response.json();
        if (!active) return;
        setAlreadyVotedInCategory(response.ok && result.success && result.eligible === false);
        setEligibilityMessage(result.reason || null);
      })
      .catch(() => {
        if (!active) return;
        setAlreadyVotedInCategory(false);
        setEligibilityMessage(null);
      });
    return () => { active = false; };
  }, [isOpen, voter?.id, nominee?.id]);

  if (!isOpen || !nominee) return null;

  const handleSendOtp = async () => {
    const normalizedEmail = emailInput.trim();
    const atIndex = normalizedEmail.indexOf("@");
    if (
      atIndex < 1 ||
      atIndex === normalizedEmail.length - 1 ||
      !normalizedEmail.slice(atIndex + 1).includes(".") ||
      normalizedEmail.split("").some((character) => character.trim().length === 0)
    ) {
      setErrorMessage("Please enter a valid work or personal email address.");
      return;
    }
    setIsSendingOtp(true);
    setErrorMessage(null);
    setDemoOtp("");
    try {
      const response = await fetch("/api/auth/email-otp", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "same-origin",
        body: JSON.stringify({ action: "send", email: emailInput, name: nameInput }),
      });
      const result = await response.json();
      if (!response.ok || !result.success) {
        setErrorMessage(result.error || "Could not send the verification code. Please try again.");
        return;
      }
      setDemoOtp(result.demoCode || "");
      setOtpSent(true);
    } catch (error) {
      console.error("Email OTP send failed:", error);
      setErrorMessage("Unable to reach the verification service. Please try again.");
    } finally {
      setIsSendingOtp(false);
    }
  };

  const handleVerifyOtp = async () => {
    if (otpCode.trim().length !== 6 || Number.isNaN(Number(otpCode.trim()))) {
      setErrorMessage("Enter the six-digit code sent to your email.");
      return;
    }
    setIsSubmitting(true);
    setErrorMessage(null);
    try {
      await loginWithEmailOtp(emailInput, otpCode, nameInput || emailInput.split("@")[0]);
      setAuthStep(authOnly ? "AUTHENTICATED" : "CAPTCHA_CONFIRM");
    } catch (error) {
      setErrorMessage(error instanceof Error ? error.message : "Email verification failed. Request a new code.");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleSocialLogin = async (provider: "google" | "facebook") => {
    setIsStartingSocialLogin(true);
    setErrorMessage(null);
    try {
      const returnTo = typeof window !== "undefined"
        ? `${window.location.pathname}${window.location.search}`
        : "/voting";
      const response = await fetch(`/api/auth/oauth/${provider}/start?returnTo=${encodeURIComponent(returnTo)}`, {
        method: "GET",
        cache: "no-store",
        credentials: "same-origin",
      });
      const result = await response.json();
      if (!response.ok || !result.success || !result.authorizationUrl) {
        setErrorMessage(result.error || `${provider} sign-in is not configured. Please use email verification.`);
        return;
      }
      window.location.assign(result.authorizationUrl);
    } catch (error) {
      console.error(`${provider} sign-in failed:`, error);
      setErrorMessage("Could not start social sign-in. Check the deployment's OAuth setup or use email OTP.");
    } finally {
      setIsStartingSocialLogin(false);
    }
  };

  const handleCastVote = async () => {
    if (!voter) {
      setAuthStep("SELECT_METHOD");
      return;
    }

    if (!captchaToken || isCaptchaLoading) {
      setErrorMessage("The security challenge is still loading. Please wait or request a new challenge.");
      return;
    }
    if (parseInt(userCaptcha.trim(), 10) !== captchaNum1 + captchaNum2) {
      setErrorMessage(`Anti-bot challenge incorrect. Please calculate: ${captchaNum1} + ${captchaNum2}`);
      return;
    }

    setIsSubmitting(true);
    setErrorMessage(null);

    try {
      const res = await fetch("/api/votes/cast", {
        method: "POST",
        credentials: "same-origin",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          nomineeId: nominee.id,
          captchaAnswer: userCaptcha,
          captchaToken,
          deviceFingerprint: typeof window !== "undefined" ? window.navigator.userAgent.slice(0, 50) : "web",
        }),
      });

      const result = await res.json();

      if (!res.ok || !result.success) {
        setErrorMessage(result.error || "Unable to cast vote. You may have already voted in this category.");
        setIsSubmitting(false);
        return;
      }

      // Record in local state
      recordLocalVote(nominee.categoryId || 1, nominee.id);

      setReceiptData({
        receiptCode: result.data.receiptCode,
        timestamp: result.data.timestamp,
        newVoteCount: result.data.newVoteCount,
      });

      if (onVoteSuccess) {
        onVoteSuccess(nominee.id, result.data.newVoteCount);
      }

      setAuthStep("SUCCESS");

      // Trigger Confetti!
      try {
        confetti({
          particleCount: 80,
          spread: 70,
          origin: { y: 0.6 },
          colors: ["#D4AF37", "#0ea5e9", "#10b981", "#f59e0b"],
        });
      } catch (err) {
        console.error(err);
      }
    } catch (err) {
      console.error(err);
      setErrorMessage("Network error casting vote. Please check your connection.");
    } finally {
      setIsSubmitting(false);
    }
  };

  const copyReceiptCode = () => {
    if (receiptData) {
      navigator.clipboard.writeText(receiptData.receiptCode);
      setCopiedReceipt(true);
      setTimeout(() => setCopiedReceipt(false), 2000);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-fade-in">
      <div className="relative w-full max-w-lg bg-slate-900 border border-amber-500/30 rounded-2xl shadow-2xl text-slate-100 overflow-hidden max-h-[92vh] flex flex-col">
        {/* Header Ribbon */}
        <div className="bg-gradient-to-r from-slate-950 via-slate-900 to-amber-950/40 p-5 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-full bg-amber-500/20 border border-amber-400/40 flex items-center justify-center text-amber-400">
              <Crown className="w-5 h-5" />
            </div>
            <div>
              <div className="text-xs uppercase font-semibold tracking-wider text-amber-400">
                CSCPO South Asian Leadership Awards
              </div>
              <h3 className="text-lg font-bold text-white leading-tight">Cast Verified Vote</h3>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Nominee Summary Card Preview */}
        <div className="p-4 bg-slate-950/60 border-b border-slate-800 flex items-center space-x-4">
          <img
            src={nominee.photoUrl}
            alt={nominee.name}
            className="w-16 h-16 rounded-xl object-cover border border-amber-400/40 shadow-md shrink-0"
          />
          <div className="min-w-0 flex-1">
            <span className="inline-block px-2 py-0.5 rounded text-[10px] font-semibold tracking-wide uppercase bg-amber-500/10 text-amber-300 border border-amber-500/20 mb-1">
              {nominee.categoryName || "Leadership Excellence"}
            </span>
            <h4 className="font-bold text-white text-base truncate">{nominee.name}</h4>
            <p className="text-xs text-slate-300 truncate">
              {nominee.designation} · {nominee.organization}
            </p>
            <p className="text-[11px] text-amber-400/90 font-medium mt-0.5">
              Current Live Votes: {nominee.voteCount.toLocaleString()}
            </p>
          </div>
        </div>

        {/* Content Area */}
        <div className="p-6 overflow-y-auto space-y-5 flex-1">
          {errorMessage && (
            <div className="p-3 bg-red-950/60 border border-red-500/40 rounded-xl text-red-200 text-xs flex items-start space-x-2">
              <AlertCircle className="w-4 h-4 shrink-0 text-red-400 mt-0.5" />
              <span>{errorMessage}</span>
            </div>
          )}

          {/* STEP 1: SELECT METHOD */}
          {authStep === "SELECT_METHOD" && (
            <div className="space-y-4">
              <div className="text-center space-y-1">
                 <h4 className="font-semibold text-white text-base">Voter Authentication</h4>
                <p className="text-xs text-slate-400">
                  Sign in with a configured Google/Facebook account or verify control of your email address. Social login verifies account access, not real-world identity.
                </p>
              </div>

              <div className="space-y-2.5">
                {/* Google Button */}
                <button
                  onClick={() => handleSocialLogin("google")}
                  disabled={isStartingSocialLogin}
                  className="w-full py-3 px-4 rounded-xl bg-white hover:bg-slate-100 text-slate-900 font-semibold text-sm flex items-center justify-center space-x-3 transition shadow-md cursor-pointer disabled:opacity-60 disabled:cursor-wait"
                >
                  <svg className="w-4 h-4" viewBox="0 0 24 24">
                    <path
                      fill="#4285F4"
                      d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                    />
                    <path
                      fill="#34A853"
                      d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                    />
                    <path
                      fill="#FBBC05"
                      d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                    />
                    <path
                      fill="#EA4335"
                      d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                    />
                  </svg>
                   <span>{isStartingSocialLogin ? "Opening Google sign-in..." : "Continue with Google"}</span>
                </button>

                {/* Facebook Button */}
                <button
                  onClick={() => handleSocialLogin("facebook")}
                  disabled={isStartingSocialLogin}
                  className="w-full py-3 px-4 rounded-xl bg-[#1877F2] hover:bg-[#166fe5] text-white font-semibold text-sm flex items-center justify-center space-x-3 transition shadow-md cursor-pointer disabled:opacity-60 disabled:cursor-wait"
                >
                  <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24">
                    <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" />
                  </svg>
                   <span>{isStartingSocialLogin ? "Opening Facebook sign-in..." : "Continue with Facebook"}</span>
                </button>

                {/* Email OTP Button */}
                <button
                  onClick={() => setAuthStep("EMAIL_OTP")}
                  className="w-full py-3 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 font-semibold text-sm flex items-center justify-center space-x-3 transition cursor-pointer"
                >
                  <Mail className="w-4 h-4 text-amber-400" />
                  <span>Verify with Work / Personal Email OTP</span>
                </button>
              </div>

              <div className="pt-2 text-[11px] text-slate-500 text-center flex items-center justify-center space-x-1">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                <span>Your voting record is cryptographically logged & private.</span>
              </div>
            </div>
          )}

          {/* STEP 2: EMAIL OTP VERIFICATION */}
          {authStep === "EMAIL_OTP" && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h4 className="font-semibold text-white text-sm">Email OTP Verification</h4>
                <button
                  onClick={() => setAuthStep("SELECT_METHOD")}
                  className="text-xs text-amber-400 hover:underline"
                >
                  Change method
                </button>
              </div>

              {!otpSent ? (
                <div className="space-y-3">
                  <div>
                    <label className="block text-xs text-slate-400 mb-1">Your Full Name</label>
                    <input
                      type="text"
                      placeholder="e.g. Arif Hossain"
                      value={nameInput}
                      onChange={(e) => setNameInput(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2.5 text-sm text-white focus:outline-none focus:border-amber-500"
                    />
                  </div>
                  <div>
                    <label className="block text-xs text-slate-400 mb-1">Email Address (OTP will be sent)</label>
                    <input
                      type="email"
                      placeholder="arif@company.com"
                      value={emailInput}
                      onChange={(e) => setEmailInput(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2.5 text-sm text-white focus:outline-none focus:border-amber-500"
                    />
                  </div>
                  <button
                    onClick={handleSendOtp}
                    disabled={isSendingOtp}
                    className="w-full py-3 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold text-sm transition flex items-center justify-center space-x-2"
                  >
                    {isSendingOtp ? "Sending verification email..." : "Send Verification Code"}
                  </button>
                </div>
              ) : (
                <div className="space-y-3">
                  <div className="p-3 bg-emerald-950/40 border border-emerald-500/40 rounded-xl text-emerald-300 text-xs space-y-1">
                    <p className="font-semibold">Check your email</p>
                    <p>A six-digit code was sent to <strong>{emailInput}</strong>. It expires in 10 minutes.</p>
                    {demoOtp && (
                      <div className="pt-1 text-amber-300">
                        <p className="font-semibold">Local development test code only:</p>
                        <p className="font-mono text-base tracking-widest">{demoOtp}</p>
                      </div>
                    )}
                  </div>

                  <div>
                    <label className="block text-xs text-slate-400 mb-1">Enter 6-Digit OTP</label>
                    <input
                      type="text"
                      maxLength={6}
                      placeholder="e.g. 123456"
                      value={otpCode}
                      onChange={(e) => setOtpCode(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2.5 text-center text-lg font-mono tracking-widest text-white focus:outline-none focus:border-amber-500"
                    />
                  </div>

                  <button
                    onClick={handleVerifyOtp}
                    className="w-full py-3 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold text-sm transition"
                  >
                    Verify & Continue to Vote
                  </button>
                </div>
              )}
            </div>
          )}

          {authStep === "AUTHENTICATED" && authOnly && (
            <div className="py-5 text-center space-y-4">
              <div className="w-14 h-14 rounded-full bg-emerald-500/20 border border-emerald-400 flex items-center justify-center mx-auto text-emerald-400">
                <ShieldCheck className="w-7 h-7" />
              </div>
              <h4 className="text-lg font-bold text-white">Voter Account Authenticated</h4>
              <p className="text-xs text-slate-400">
                Signed in as <strong className="text-emerald-300">{voter?.email}</strong>. This step does not cast a vote; open a nominee and press Vote Now to cast one.
              </p>
              <button
                onClick={onClose}
                className="w-full py-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-sm"
              >
                Done
              </button>
            </div>
          )}

          {/* STEP 3: CAPTCHA & FINAL CONFIRM */}
          {authStep === "CAPTCHA_CONFIRM" && (
            <div className="space-y-4">
              <div className="p-3 bg-slate-950/80 border border-slate-800 rounded-xl flex items-center justify-between">
                <div className="flex items-center space-x-2 text-xs">
                  <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                   <span className="text-slate-400">Authenticated Account:</span>
                  <span className="text-emerald-300 font-medium">{voter?.email}</span>
                </div>
                <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                  {voter?.authProvider}
                </span>
              </div>

              {alreadyVotedInCategory ? (
                <div className="p-4 bg-amber-950/40 border border-amber-500/40 rounded-xl text-amber-200 text-xs space-y-2">
                  <div className="flex items-center space-x-2 font-bold text-amber-400">
                    <AlertCircle className="w-4 h-4" />
                    <span>Already Voted In This Category</span>
                  </div>
                  <p>
                    {eligibilityMessage || `Your account has already cast a vote under the current ${nominee.categoryName} voting policy.`}
                  </p>
                  <p className="text-slate-400">
                    You can still cast votes for outstanding leaders in other award categories!
                  </p>
                </div>
              ) : (
                <>
                  {/* Anti-Bot Challenge */}
                  <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2">
                    <div className="flex items-center justify-between">
                      <label className="text-xs font-semibold text-slate-300 flex items-center space-x-1.5">
                        <Lock className="w-3.5 h-3.5 text-amber-400" />
                        <span>Server-Signed Security Challenge</span>
                      </label>
                      <button
                        type="button"
                        onClick={loadVoteChallenge}
                        disabled={isCaptchaLoading}
                        className="text-[11px] text-amber-400 hover:underline disabled:opacity-50"
                      >
                        {isCaptchaLoading ? "Loading..." : "Refresh challenge"}
                      </button>
                    </div>
                    <div className="flex items-center space-x-3">
                      <div className="bg-slate-900 border border-slate-700 px-3.5 py-2 rounded-lg font-mono text-sm text-amber-300 font-bold select-none min-w-[100px] text-center">
                        {isCaptchaLoading ? "Loading…" : `${captchaNum1} + ${captchaNum2} = ?`}
                      </div>
                      <input
                        type="number"
                        placeholder="Answer"
                        value={userCaptcha}
                        onChange={(e) => setUserCaptcha(e.target.value)}
                        disabled={isCaptchaLoading || !captchaToken}
                        className="flex-1 bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-amber-500 text-center font-bold disabled:opacity-50"
                      />
                    </div>
                  </div>

                  <div className="text-[11px] text-slate-400 leading-relaxed bg-slate-950/40 p-3 rounded-lg border border-slate-800">
                    By clicking Confirm Vote, you attest that you are casting your own independent professional vote. Each
                    vote is recorded with IP hash and audit timestamp into the CSCPO transparency system.
                  </div>

                  <button
                    onClick={handleCastVote}
                    disabled={isSubmitting || isCaptchaLoading || !captchaToken}
                    className="w-full py-3.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-bold text-sm tracking-wide shadow-lg shadow-amber-500/20 transition flex items-center justify-center space-x-2 cursor-pointer disabled:opacity-60 disabled:cursor-wait"
                  >
                    {isSubmitting ? (
                      <span className="flex items-center space-x-2">
                        <div className="w-4 h-4 border-2 border-slate-950 border-t-transparent rounded-full animate-spin" />
                        <span>Verifying & Recording Vote...</span>
                      </span>
                    ) : (
                      <>
                        <ShieldCheck className="w-4 h-4" />
                        <span>Confirm Vote for {nominee.name}</span>
                      </>
                    )}
                  </button>
                </>
              )}
            </div>
          )}

          {/* STEP 4: SUCCESS CERTIFICATE RECEIPT */}
          {authStep === "SUCCESS" && receiptData && (
            <div className="space-y-5 text-center py-2 animate-scale-up">
              <div className="w-16 h-16 rounded-full bg-emerald-500/20 border-2 border-emerald-400 flex items-center justify-center text-emerald-400 mx-auto shadow-lg shadow-emerald-500/20">
                <CheckCircle2 className="w-8 h-8" />
              </div>

              <div>
                <h4 className="text-xl font-bold text-white">Vote Certified & Recorded!</h4>
                <p className="text-xs text-slate-400 mt-1">
                  Thank you for participating in the CSCPO South Asian Leadership Awards.
                </p>
              </div>

              {/* Official Receipt Box */}
              <div className="bg-slate-950 border border-amber-500/30 rounded-xl p-4 text-left space-y-2.5 font-mono text-xs">
                <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                  <span className="text-slate-400 font-sans">Nominee:</span>
                  <span className="text-white font-bold">{nominee.name}</span>
                </div>
                <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                  <span className="text-slate-400 font-sans">Category:</span>
                  <span className="text-amber-300 truncate max-w-[200px]">{nominee.categoryName}</span>
                </div>
                <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                  <span className="text-slate-400 font-sans">Updated Vote Count:</span>
                  <span className="text-emerald-400 font-bold">#{receiptData.newVoteCount}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-400 font-sans">Receipt Ref:</span>
                  <button
                    onClick={copyReceiptCode}
                    className="flex items-center space-x-1 text-amber-400 hover:text-amber-300 text-[11px]"
                  >
                    <span>{receiptData.receiptCode.slice(0, 18)}...</span>
                    {copiedReceipt ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  </button>
                </div>
              </div>

              {/* Share prompt */}
              <div className="space-y-2 pt-2">
                <p className="text-xs text-slate-300 font-medium">Help your nominee win! Share their voting card:</p>
                <div className="flex items-center justify-center space-x-2">
                  <a
                    href={`https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(
                      typeof window !== "undefined" ? `${window.location.origin}/nominee/${nominee.slug}` : ""
                    )}`}
                    target="_blank"
                    rel="noreferrer"
                    className="px-3.5 py-2 rounded-lg bg-[#0077b5] text-white text-xs font-semibold flex items-center space-x-1.5 hover:opacity-90"
                  >
                    <span>Share on LinkedIn</span>
                  </a>
                  <a
                    href={`https://api.whatsapp.com/send?text=${encodeURIComponent(
                      `I just voted for ${nominee.name} in CSCPO South Asian Leadership Awards! Support leadership excellence here: ${
                        typeof window !== "undefined" ? `${window.location.origin}/nominee/${nominee.slug}` : ""
                      }`
                    )}`}
                    target="_blank"
                    rel="noreferrer"
                    className="px-3.5 py-2 rounded-lg bg-[#25D366] text-white text-xs font-semibold flex items-center space-x-1.5 hover:opacity-90"
                  >
                    <span>WhatsApp</span>
                  </a>
                </div>
              </div>

              <button
                onClick={onClose}
                className="w-full py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold"
              >
                Done
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
