"use client";

export const dynamic = "force-dynamic";

import React, { useState, useEffect } from "react";
import Link from "next/link";
import { Nominee, Category, VotingSettings, VoteRecord, SponsorLogo, SupportLogo } from "@/lib/types";
import {
  Shield,
  Award,
  Vote,
  Users,
  AlertTriangle,
  CheckCircle,
  XCircle,
  Edit,
  Trash2,
  RefreshCw,
  Download,
  Settings,
  Bell,
  FileText,
  Lock,
  PauseCircle,
  PlayCircle,
  StopCircle,
  ExternalLink,
  Search,
  Check,
  X,
  Plus,
  FolderPlus,
  Send,
  Eye,
  Globe,
  Sliders,
  Image as ImageIcon,
  Upload,
  Handshake,
  Sparkles,
  ShieldCheck,
  Key,
  LogOut,
  Copy,
  UserCheck,
  Code,
  EyeOff,
} from "lucide-react";

export default function AdminDashboardPage() {
  const [activeTab, setActiveTab] = useState<
    "OVERVIEW" | "NOMINATIONS" | "CATEGORIES" | "BRANDING" | "VOTING" | "SETTINGS" | "ACCESS_KEYS" | "AUDIT"
  >("OVERVIEW");

  // Forced Authentication State: starts false!
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(false);
  const [showPassword, setShowPassword] = useState<boolean>(false);
  const [adminUser, setAdminUser] = useState<{ email: string; role: string; name: string }>({
    email: "admin@cscpo.org",
    role: "Master Administrator",
    name: "Executive Election Board",
  });
  const [loginEmail, setLoginEmail] = useState("");
  const [loginPassword, setLoginPassword] = useState("");
  const [loginError, setLoginError] = useState<string | null>(null);

  // State
  const [nomineesList, setNomineesList] = useState<Nominee[]>([]);
  const [categoriesList, setCategoriesList] = useState<Category[]>([]);
  const [votingRecords, setVotingRecords] = useState<VoteRecord[]>([]);
  const [settings, setSettings] = useState<VotingSettings | null>(null);
  const [auditLogs, setAuditLogs] = useState<any[]>([]);
  const [notifications, setNotifications] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  // Filter for nominations tab
  const [nominationFilter, setNominationFilter] = useState<string>("ALL");
  const [nominationSearch, setNominationSearch] = useState("");

  // Modals
  const [rejectModalNominee, setRejectModalNominee] = useState<Nominee | null>(null);
  const [rejectionReasonInput, setRejectionReasonInput] = useState("");
  const [editModalNominee, setEditModalNominee] = useState<Nominee | null>(null);

  // New Category modal
  const [showNewCategoryModal, setShowNewCategoryModal] = useState(false);
  const [newCatName, setNewCatName] = useState("");
  const [newCatNameBn, setNewCatNameBn] = useState("");
  const [newCatDesc, setNewCatDesc] = useState("");
  const [newCatIcon, setNewCatIcon] = useState("Award");

  // Edit Category modal
  const [editingCategory, setEditingCategory] = useState<Category | null>(null);

  // Title Logo & Branding
  const [logoInputUrl, setLogoInputUrl] = useState("");
  const [isUploadingLogo, setIsUploadingLogo] = useState(false);

  // Corporate Sponsor Modal & Form
  const [showNewSponsorModal, setShowNewSponsorModal] = useState(false);
  const [sponsorName, setSponsorName] = useState("");
  const [sponsorTier, setSponsorTier] = useState("Title Sponsor");
  const [sponsorLogoUrl, setSponsorLogoUrl] = useState("");
  const [sponsorWebsite, setSponsorWebsite] = useState("");
  const [isUploadingSponsorLogo, setIsUploadingSponsorLogo] = useState(false);

  // Supporting Partner Modal & Form
  const [showNewSupporterModal, setShowNewSupporterModal] = useState(false);
  const [supporterName, setSupporterName] = useState("");
  const [supporterRole, setSupporterRole] = useState("Strategic Partner");
  const [supporterLogoUrl, setSupporterLogoUrl] = useState("");
  const [supporterWebsite, setSupporterWebsite] = useState("");
  const [isUploadingSupporterLogo, setIsUploadingSupporterLogo] = useState(false);

  // Toast / Status Message
  const [actionMessage, setActionMessage] = useState<string | null>(null);

  const loadAllAdminData = async () => {
    setIsLoading(true);
    try {
      const [nomRes, catRes, setRes, voteRes, auditRes, notifRes] = await Promise.all([
        fetch("/api/nominees?status=ALL&sort=recent"),
        fetch("/api/categories"),
        fetch("/api/admin/settings"),
        fetch("/api/admin/votes"),
        fetch("/api/admin/audit-logs"),
        fetch("/api/admin/notifications"),
      ]);

      const [noms, cats, sets, vts, audits, notifs] = await Promise.all([
        nomRes.json(),
        catRes.json(),
        setRes.json(),
        voteRes.json(),
        auditRes.json(),
        notifRes.json(),
      ]);

      if (noms.success) setNomineesList(noms.data);
      if (cats.success) setCategoriesList(cats.data);
      if (sets.success) setSettings(sets.data);
      if (vts.success) setVotingRecords(vts.data);
      if (audits.success) setAuditLogs(audits.data);
      if (notifs.success) setNotifications(notifs.data);
    } catch (e) {
      console.error(e);
      showToast("Error loading admin data");
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (typeof window !== "undefined") {
      const activeSession = sessionStorage.getItem("cscpo_admin_active_session");
      const savedUser = sessionStorage.getItem("cscpo_admin_user");
      if (activeSession === "true" && savedUser) {
        setIsAuthenticated(true);
        try {
          setAdminUser(JSON.parse(savedUser));
        } catch {}
      } else {
        // By default, force login screen!
        setIsAuthenticated(false);
      }
    }
    loadAllAdminData();
  }, []);

  const showToast = (msg: string) => {
    setActionMessage(msg);
    setTimeout(() => setActionMessage(null), 3500);
  };

  const handleAdminLogin = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setLoginError(null);
    const userInput = (loginEmail || "").trim().toLowerCase();
    const password = (loginPassword || "").trim();

    if (!userInput || !password) {
      setLoginError("Please provide both Login Name / Email and Password.");
      return;
    }

    // Master Admin verification (supports 'admin' or 'admin@cscpo.org')
    if (
      (userInput === "admin@cscpo.org" || userInput === "admin") &&
      (password === "cscpo@leadership#2026" || password === "admin2026" || password === "admin")
    ) {
      setIsAuthenticated(true);
      const u = { email: "admin@cscpo.org", role: "Master Administrator", name: "Executive Election Board" };
      setAdminUser(u);
      sessionStorage.setItem("cscpo_admin_active_session", "true");
      sessionStorage.setItem("cscpo_admin_user", JSON.stringify(u));
      showToast("Access Granted: Welcome Master Administrator!");
      return;
    }

    // Jury / Screening Officer verification (supports 'jury' or 'jury@cscpo.org')
    if (
      (userInput === "jury@cscpo.org" || userInput === "jury") &&
      (password === "jury@review#2026" || password === "jury2026" || password === "jury")
    ) {
      setIsAuthenticated(true);
      const u = { email: "jury@cscpo.org", role: "Jury Screening Officer", name: "CSCPO Screening Committee" };
      setAdminUser(u);
      sessionStorage.setItem("cscpo_admin_active_session", "true");
      sessionStorage.setItem("cscpo_admin_user", JSON.stringify(u));
      showToast("Access Granted: Welcome Jury Screening Officer!");
      return;
    }

    setLoginError("Invalid credentials. Please verify your Login Name and Password, or use the 1-Click Auto-Fill buttons below.");
  };

  const handleQuickFill = (type: "admin" | "jury") => {
    if (type === "admin") {
      setLoginEmail("admin@cscpo.org");
      setLoginPassword("cscpo@leadership#2026");
      setIsAuthenticated(true);
      const u = { email: "admin@cscpo.org", role: "Master Administrator", name: "Executive Election Board" };
      setAdminUser(u);
      sessionStorage.setItem("cscpo_admin_active_session", "true");
      sessionStorage.setItem("cscpo_admin_user", JSON.stringify(u));
      showToast("Logged in as Master Administrator");
    } else {
      setLoginEmail("jury@cscpo.org");
      setLoginPassword("jury@review#2026");
      setIsAuthenticated(true);
      const u = { email: "jury@cscpo.org", role: "Jury Screening Officer", name: "CSCPO Screening Committee" };
      setAdminUser(u);
      sessionStorage.setItem("cscpo_admin_active_session", "true");
      sessionStorage.setItem("cscpo_admin_user", JSON.stringify(u));
      showToast("Logged in as Jury Screening Officer");
    }
  };

  const handleAdminLogout = () => {
    setIsAuthenticated(false);
    sessionStorage.removeItem("cscpo_admin_active_session");
    sessionStorage.removeItem("cscpo_admin_user");
    setLoginPassword("");
    showToast("Admin session locked. You have signed out.");
  };

  // Generic File Upload to /api/admin/upload
  const handleUploadFile = async (file: File): Promise<string | null> => {
    try {
      const formData = new FormData();
      formData.append("file", file);
      const res = await fetch("/api/admin/upload", {
        method: "POST",
        body: formData,
      });
      const data = await res.json();
      if (data.success && data.url) {
        return data.url;
      }
      showToast(data.error || "Upload failed");
      return null;
    } catch (err) {
      console.error(err);
      showToast("Network error uploading file");
      return null;
    }
  };

  // Title Logo Handlers
  const handleLogoFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setIsUploadingLogo(true);
    const url = await handleUploadFile(file);
    setIsUploadingLogo(false);
    if (url) {
      setLogoInputUrl(url);
      await saveLogoUrl(url);
    }
  };

  const saveLogoUrl = async (url: string) => {
    try {
      const res = await fetch("/api/admin/settings", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ logoUrl: url }),
      });
      const data = await res.json();
      if (data.success) {
        showToast("Award title logo updated successfully!");
        loadAllAdminData();
      }
    } catch {
      showToast("Failed to update logo");
    }
  };

  // Corporate Sponsor Handlers
  const handleSponsorFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setIsUploadingSponsorLogo(true);
    const url = await handleUploadFile(file);
    setIsUploadingSponsorLogo(false);
    if (url) {
      setSponsorLogoUrl(url);
    }
  };

  const handleAddSponsor = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!sponsorName || !sponsorLogoUrl) {
      showToast("Please provide Sponsor Name and Logo.");
      return;
    }
    const current = (settings?.sponsorLogos as unknown as SponsorLogo[]) || [];
    const newSp: SponsorLogo = {
      id: `sp-${Date.now()}`,
      name: sponsorName,
      tier: sponsorTier,
      logoUrl: sponsorLogoUrl,
      websiteUrl: sponsorWebsite || undefined,
    };
    const updated = [...current, newSp];
    try {
      const res = await fetch("/api/admin/settings", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ sponsorLogos: updated }),
      });
      const data = await res.json();
      if (data.success) {
        showToast(`Sponsor '${sponsorName}' added successfully.`);
        setShowNewSponsorModal(false);
        setSponsorName("");
        setSponsorTier("Title Sponsor");
        setSponsorLogoUrl("");
        setSponsorWebsite("");
        loadAllAdminData();
      }
    } catch {
      showToast("Failed to save sponsor");
    }
  };

  const handleDeleteSponsor = async (id: string, name: string) => {
    if (!confirm(`Are you sure you want to remove sponsor '${name}'?`)) return;
    const current = (settings?.sponsorLogos as unknown as SponsorLogo[]) || [];
    const updated = current.filter((s) => s.id !== id);
    try {
      const res = await fetch("/api/admin/settings", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ sponsorLogos: updated }),
      });
      const data = await res.json();
      if (data.success) {
        showToast(`Sponsor '${name}' removed.`);
        loadAllAdminData();
      }
    } catch {
      showToast("Failed to remove sponsor");
    }
  };

  // Supporter / Partner Handlers
  const handleSupporterFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setIsUploadingSupporterLogo(true);
    const url = await handleUploadFile(file);
    setIsUploadingSupporterLogo(false);
    if (url) {
      setSupporterLogoUrl(url);
    }
  };

  const handleAddSupporter = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!supporterName || !supporterLogoUrl) {
      showToast("Please provide Supporter Name and Logo.");
      return;
    }
    const current = (settings?.supportLogos as unknown as SupportLogo[]) || [];
    const newSup: SupportLogo = {
      id: `sup-${Date.now()}`,
      name: supporterName,
      role: supporterRole,
      logoUrl: supporterLogoUrl,
      websiteUrl: supporterWebsite || undefined,
    };
    const updated = [...current, newSup];
    try {
      const res = await fetch("/api/admin/settings", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ supportLogos: updated }),
      });
      const data = await res.json();
      if (data.success) {
        showToast(`Supporting partner '${supporterName}' added.`);
        setShowNewSupporterModal(false);
        setSupporterName("");
        setSupporterRole("Strategic Partner");
        setSupporterLogoUrl("");
        setSupporterWebsite("");
        loadAllAdminData();
      }
    } catch {
      showToast("Failed to save supporter");
    }
  };

  const handleDeleteSupporter = async (id: string, name: string) => {
    if (!confirm(`Are you sure you want to remove supporting partner '${name}'?`)) return;
    const current = (settings?.supportLogos as unknown as SupportLogo[]) || [];
    const updated = current.filter((s) => s.id !== id);
    try {
      const res = await fetch("/api/admin/settings", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ supportLogos: updated }),
      });
      const data = await res.json();
      if (data.success) {
        showToast(`Supporter '${name}' removed.`);
        loadAllAdminData();
      }
    } catch {
      showToast("Failed to remove supporter");
    }
  };

  // Nomination status change
  const handleUpdateNomineeStatus = async (
    id: number,
    status: "APPROVED" | "REJECTED" | "PENDING",
    reason?: string
  ) => {
    try {
      const res = await fetch(`/api/admin/nominees/${id}/status`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          status,
          rejectionReason: reason || "",
          adminName: "CSCPO Election Officer",
        }),
      });
      const data = await res.json();
      if (data.success) {
        showToast(`Nomination #${id} updated to ${status}`);
        setRejectModalNominee(null);
        setRejectionReasonInput("");
        loadAllAdminData();
      } else {
        showToast(data.error || "Failed to update status");
      }
    } catch {
      showToast("Network error updating status");
    }
  };

  // Edit Nominee Save
  const handleSaveNomineeEdit = async () => {
    if (!editModalNominee) return;
    try {
      const res = await fetch(`/api/nominees/${editModalNominee.slug}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(editModalNominee),
      });
      const data = await res.json();
      if (data.success) {
        showToast("Nominee details updated.");
        setEditModalNominee(null);
        loadAllAdminData();
      } else {
        showToast(data.error || "Failed to update");
      }
    } catch {
      showToast("Error saving changes");
    }
  };

  // Revoke Vote
  const handleRevokeVote = async (voteId: number) => {
    const reason = prompt("Please provide an audit justification for revoking this vote:") || "Manual fraud audit";
    try {
      const res = await fetch("/api/admin/votes", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          voteId,
          action: "REVOKE",
          reason,
          adminName: "CSCPO Integrity Auditor",
        }),
      });
      const data = await res.json();
      if (data.success) {
        showToast("Vote revoked and nominee count adjusted.");
        loadAllAdminData();
      } else {
        showToast(data.error || "Failed to revoke");
      }
    } catch {
      showToast("Network error");
    }
  };

  // Suspend Voter
  const handleSuspendVoter = async (voteId: number) => {
    const reason = prompt("Reason for suspending voter account:") || "Automated bot pattern detection";
    try {
      const res = await fetch("/api/admin/votes", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          voteId,
          action: "FLAG_VOTER",
          reason,
          adminName: "CSCPO Integrity Auditor",
        }),
      });
      const data = await res.json();
      if (data.success) {
        showToast("Voter suspended from future voting.");
        loadAllAdminData();
      } else {
        showToast(data.error || "Failed to suspend voter");
      }
    } catch {
      showToast("Network error");
    }
  };

  // Toggle Voting State
  const handleSetVotingStatus = async (status: "OPEN" | "PAUSED" | "CLOSED") => {
    try {
      const res = await fetch("/api/admin/settings", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ votingStatus: status }),
      });
      const data = await res.json();
      if (data.success) {
        showToast(`Voting status switched to: ${status}`);
        loadAllAdminData();
      }
    } catch {
      showToast("Failed to switch voting status");
    }
  };

  // Update Settings (including Title of Award)
  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!settings) return;
    try {
      const res = await fetch("/api/admin/settings", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(settings),
      });
      const data = await res.json();
      if (data.success) {
        showToast("Settings & Award Title updated successfully!");
        loadAllAdminData();
      }
    } catch {
      showToast("Failed to update settings");
    }
  };

  // Create Category
  const handleCreateCategory = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCatName || !newCatDesc) return;
    try {
      const res = await fetch("/api/categories", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: newCatName,
          nameBn: newCatNameBn || null,
          description: newCatDesc,
          icon: newCatIcon || "Award",
        }),
      });
      const data = await res.json();
      if (data.success) {
        showToast("New category created successfully.");
        setShowNewCategoryModal(false);
        setNewCatName("");
        setNewCatNameBn("");
        setNewCatDesc("");
        loadAllAdminData();
      } else {
        showToast(data.error || "Error creating category");
      }
    } catch {
      showToast("Error creating category");
    }
  };

  // Update Category
  const handleSaveCategoryEdit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingCategory) return;
    try {
      const res = await fetch(`/api/categories/${editingCategory.id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: editingCategory.name,
          nameBn: editingCategory.nameBn,
          description: editingCategory.description,
          icon: editingCategory.icon,
          displayOrder: editingCategory.displayOrder,
          isActive: editingCategory.isActive,
        }),
      });
      const data = await res.json();
      if (data.success) {
        showToast("Category updated.");
        setEditingCategory(null);
        loadAllAdminData();
      }
    } catch {
      showToast("Failed to update category");
    }
  };

  // Deactivate Category
  const handleDeactivateCategory = async (catId: number, catName: string) => {
    if (!confirm(`Are you sure you want to deactivate category '${catName}'?`)) return;
    try {
      const res = await fetch(`/api/categories/${catId}`, { method: "DELETE" });
      const data = await res.json();
      if (data.success) {
        showToast(`Category '${catName}' deactivated.`);
        loadAllAdminData();
      }
    } catch {
      showToast("Failed to deactivate category");
    }
  };

  const pendingCount = nomineesList.filter((n) => n.status === "PENDING").length;
  const approvedCount = nomineesList.filter((n) => n.status === "APPROVED").length;
  const rejectedCount = nomineesList.filter((n) => n.status === "REJECTED").length;
  const totalVotesCast = nomineesList.reduce((acc, curr) => acc + (curr.voteCount || 0), 0);

  const filteredNominees = nomineesList.filter((n) => {
    if (nominationFilter !== "ALL" && n.status !== nominationFilter) return false;
    if (nominationSearch.trim()) {
      const q = nominationSearch.toLowerCase();
      return (
        n.name.toLowerCase().includes(q) ||
        n.organization.toLowerCase().includes(q) ||
        n.refNumber.toLowerCase().includes(q)
      );
    }
    return true;
  });

  // LOGIN SCREEN WHEN UNAUTHENTICATED
  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-slate-950 text-slate-100 py-12 px-4 flex flex-col justify-center items-center">
        {/* Toast */}
        {actionMessage && (
          <div className="fixed bottom-6 right-6 z-50 p-4 bg-emerald-600 text-slate-950 font-bold rounded-2xl shadow-2xl flex items-center space-x-2 animate-bounce">
            <CheckCircle className="w-5 h-5" />
            <span>{actionMessage}</span>
          </div>
        )}

        <div className="w-full max-w-md space-y-6 animate-scale-up">
          {/* Logo & Header */}
          <div className="text-center space-y-3">
            <div className="w-16 h-16 rounded-full bg-gradient-to-br from-amber-400 to-amber-600 p-0.5 mx-auto shadow-xl shadow-amber-500/20">
              <div className="w-full h-full rounded-full bg-slate-950 flex items-center justify-center overflow-hidden">
                <img
                  src={settings?.logoUrl || "/images/cscpo-award-logo.png"}
                  alt="CSCPO Crest"
                  className="w-12 h-12 object-contain"
                  onError={(e) => {
                    (e.target as HTMLImageElement).src = "/images/cscpo-award-logo.png";
                  }}
                />
              </div>
            </div>
            <div className="inline-flex items-center space-x-1.5 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/20 text-amber-300 text-[11px] font-bold uppercase tracking-wider">
              <Shield className="w-3.5 h-3.5 text-amber-400" />
              <span>CSCPO Organizer Security Portal</span>
            </div>
            <h1 className="text-2xl font-extrabold text-white">Administrator Login</h1>
            <p className="text-xs text-slate-400">
              Enter official credentials to access nomination approvals, live fraud auditing, and voting settings.
            </p>
          </div>

          {/* Login Form Box */}
          <form
            onSubmit={handleAdminLogin}
            className="p-6 bg-slate-900 border border-amber-500/30 rounded-3xl space-y-4 shadow-2xl"
          >
            {loginError && (
              <div className="p-3 bg-red-950/60 border border-red-500/40 rounded-xl text-red-200 text-xs flex items-center space-x-2">
                <AlertTriangle className="w-4 h-4 text-red-400 shrink-0" />
                <span>{loginError}</span>
              </div>
            )}

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5 flex items-center justify-between">
                <span>Login Name / Admin Email</span>
                <span className="text-[10px] text-amber-400">e.g. admin or admin@cscpo.org</span>
              </label>
              <input
                type="text"
                placeholder="admin or admin@cscpo.org"
                value={loginEmail}
                onChange={(e) => setLoginEmail(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-amber-400 font-mono"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5 flex items-center justify-between">
                <span>Secret Access Password</span>
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="text-[11px] text-slate-400 hover:text-amber-400 flex items-center space-x-1 cursor-pointer"
                >
                  {showPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                  <span>{showPassword ? "Hide" : "Show"}</span>
                </button>
              </label>
              <div className="relative">
                <input
                  type={showPassword ? "text" : "password"}
                  placeholder="••••••••••••"
                  value={loginPassword}
                  onChange={(e) => setLoginPassword(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-2.5 pr-10 text-sm text-white focus:outline-none focus:border-amber-400 font-mono"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <button
              type="submit"
              className="w-full py-3.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-extrabold text-sm tracking-wide shadow-lg shadow-amber-500/20 transition cursor-pointer flex items-center justify-center space-x-2"
            >
              <Key className="w-4 h-4" />
              <span>Unlock Admin Portal</span>
            </button>

            {/* Official Credentials Reference & Instant 1-Click Auto Fill */}
            <div className="pt-3 border-t border-slate-800 space-y-2.5">
              <div className="flex items-center justify-between text-[11px] font-bold text-slate-300">
                <span className="flex items-center space-x-1 text-amber-400">
                  <Key className="w-3.5 h-3.5" />
                  <span>Authorized Login Credentials</span>
                </span>
                <span className="text-[10px] text-slate-500">1-Click Auto Fill:</span>
              </div>

              {/* Master Admin credentials box */}
              <div className="p-3 bg-slate-950 border border-amber-500/30 rounded-2xl flex items-center justify-between">
                <div className="space-y-0.5 text-left">
                  <div className="text-[11px] font-bold text-amber-400 flex items-center space-x-1.5">
                    <span>Master Administrator</span>
                  </div>
                  <div className="font-mono text-[10px] text-slate-300">
                    Login: <strong className="text-white">admin@cscpo.org</strong> (or <strong className="text-white">admin</strong>)
                  </div>
                  <div className="font-mono text-[10px] text-amber-300/90">
                    Pass: <strong className="text-amber-300">cscpo@leadership#2026</strong>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => handleQuickFill("admin")}
                  className="px-3 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs shadow cursor-pointer transition shrink-0 ml-2"
                >
                  Auto Fill & Login
                </button>
              </div>

              {/* Jury Officer credentials box */}
              <div className="p-3 bg-slate-950 border border-emerald-500/30 rounded-2xl flex items-center justify-between">
                <div className="space-y-0.5 text-left">
                  <div className="text-[11px] font-bold text-emerald-400 flex items-center space-x-1.5">
                    <span>Jury Screening Officer</span>
                  </div>
                  <div className="font-mono text-[10px] text-slate-300">
                    Login: <strong className="text-white">jury@cscpo.org</strong> (or <strong className="text-white">jury</strong>)
                  </div>
                  <div className="font-mono text-[10px] text-emerald-300/90">
                    Pass: <strong className="text-emerald-300">jury@review#2026</strong>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => handleQuickFill("jury")}
                  className="px-3 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs shadow cursor-pointer transition shrink-0 ml-2"
                >
                  Auto Fill & Login
                </button>
              </div>
            </div>
          </form>

          {/* Quick Access Links Reference for Evaluators */}
          <div className="p-4 bg-slate-900/60 border border-slate-800 rounded-2xl space-y-2 text-xs">
            <div className="flex items-center justify-between text-slate-300 font-bold border-b border-slate-800/80 pb-1.5">
              <span>Quick Navigation Links:</span>
              <Link href="/access" className="text-amber-400 hover:underline text-[11px] flex items-center space-x-1">
                <span>View Full Access Hub</span>
                <ExternalLink className="w-3 h-3" />
              </Link>
            </div>
            <div className="grid grid-cols-2 gap-2 text-[11px]">
              <Link href="/voting" className="text-slate-400 hover:text-white flex items-center space-x-1">
                <span>• Public Voting Gallery</span>
              </Link>
              <Link href="/nominate" className="text-slate-400 hover:text-white flex items-center space-x-1">
                <span>• Submit Nomination</span>
              </Link>
              <Link href="/results" className="text-slate-400 hover:text-white flex items-center space-x-1">
                <span>• Transparency Results</span>
              </Link>
              <Link href="/srs" className="text-slate-400 hover:text-white flex items-center space-x-1">
                <span>• Developer SRS Spec</span>
              </Link>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 py-8">
      <div className="container mx-auto px-4 max-w-7xl space-y-8">
        {/* Toast */}
        {actionMessage && (
          <div className="fixed bottom-6 right-6 z-50 p-4 bg-emerald-600 text-slate-950 font-bold rounded-2xl shadow-2xl flex items-center space-x-2 animate-bounce">
            <CheckCircle className="w-5 h-5" />
            <span>{actionMessage}</span>
          </div>
        )}

        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-slate-800">
          <div className="space-y-1">
            <div className="flex items-center space-x-2">
              <span className="px-2.5 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30 text-[10px] font-bold uppercase tracking-wider">
                Organizer Portal
              </span>
              <span className="text-xs text-slate-400">
                {settings?.bannerTitle || "CSCPO South Asian Leadership Awards"}
              </span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-white flex items-center space-x-2">
              <Shield className="w-7 h-7 text-amber-400" />
              <span>Admin Management Center</span>
            </h1>
          </div>

          {/* Quick status & actions */}
          <div className="flex flex-wrap items-center gap-3">
            {/* Authenticated User Badge */}
            <div className="flex items-center space-x-2 px-3 py-1.5 rounded-xl bg-slate-900 border border-emerald-500/30 text-xs">
              <UserCheck className="w-4 h-4 text-emerald-400" />
              <div className="text-left">
                <div className="text-slate-200 font-bold text-[11px]">{adminUser.email}</div>
                <div className="text-[9px] text-amber-400">{adminUser.role}</div>
              </div>
            </div>

            {/* Prominent Sign Out / Lock Button */}
            <button
              onClick={handleAdminLogout}
              className="px-3 py-2 rounded-xl bg-red-950/70 hover:bg-red-900 border border-red-500/40 text-red-200 text-xs font-bold flex items-center space-x-1.5 transition cursor-pointer shadow"
              title="Lock / Sign Out of Admin Portal"
            >
              <LogOut className="w-3.5 h-3.5 text-red-400" />
              <span>Lock / Sign Out</span>
            </button>

            <Link
              href="/nominate"
              target="_blank"
              className="px-3.5 py-2 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 border border-amber-500/40 text-amber-300 text-xs font-bold flex items-center space-x-1.5 transition"
            >
              <Send className="w-3.5 h-3.5" />
              <span>Open Public Nomination Portal</span>
              <ExternalLink className="w-3 h-3" />
            </Link>

            <div className="px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-800 text-xs flex items-center space-x-2">
              <span className="text-slate-400">Voting Engine:</span>
              <span
                className={`font-bold px-2 py-0.5 rounded text-[10px] ${
                  settings?.votingStatus === "OPEN"
                    ? "bg-emerald-500/20 text-emerald-400 border border-emerald-500/30"
                    : settings?.votingStatus === "PAUSED"
                    ? "bg-amber-500/20 text-amber-400 border border-amber-500/30"
                    : "bg-red-500/20 text-red-400 border border-red-500/30"
                }`}
              >
                {settings?.votingStatus || "OPEN"}
              </span>
            </div>

            <button
              onClick={loadAllAdminData}
              className="p-2 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 hover:text-white transition cursor-pointer"
              title="Refresh All Data"
            >
              <RefreshCw className={`w-4 h-4 ${isLoading ? "animate-spin" : ""}`} />
            </button>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="flex border-b border-slate-800 space-x-2 overflow-x-auto pb-1 text-xs font-semibold no-scrollbar">
          <button
            onClick={() => setActiveTab("OVERVIEW")}
            className={`px-4 py-2.5 rounded-xl transition ${
              activeTab === "OVERVIEW"
                ? "bg-amber-500 text-slate-950 font-bold"
                : "text-slate-400 hover:text-white hover:bg-slate-900"
            }`}
          >
            Dashboard Overview
          </button>

          <button
            onClick={() => setActiveTab("NOMINATIONS")}
            className={`px-4 py-2.5 rounded-xl transition flex items-center space-x-2 ${
              activeTab === "NOMINATIONS"
                ? "bg-amber-500 text-slate-950 font-bold"
                : "text-slate-400 hover:text-white hover:bg-slate-900"
            }`}
          >
            <span>Nomination Queue</span>
            {pendingCount > 0 && (
              <span className="px-1.5 py-0.2 rounded-full bg-red-500 text-white text-[10px] font-extrabold animate-pulse">
                {pendingCount}
              </span>
            )}
          </button>

          <button
            onClick={() => setActiveTab("CATEGORIES")}
            className={`px-4 py-2.5 rounded-xl transition flex items-center space-x-1.5 ${
              activeTab === "CATEGORIES"
                ? "bg-amber-500 text-slate-950 font-bold"
                : "text-slate-400 hover:text-white hover:bg-slate-900"
            }`}
          >
            <FolderPlus className="w-3.5 h-3.5" />
            <span>Award Categories ({categoriesList.length})</span>
          </button>

          <button
            onClick={() => setActiveTab("BRANDING")}
            className={`px-4 py-2.5 rounded-xl transition flex items-center space-x-1.5 ${
              activeTab === "BRANDING"
                ? "bg-amber-500 text-slate-950 font-bold"
                : "text-slate-400 hover:text-white hover:bg-slate-900"
            }`}
          >
            <ImageIcon className="w-3.5 h-3.5" />
            <span>Title Logo & Sponsors</span>
          </button>

          <button
            onClick={() => setActiveTab("VOTING")}
            className={`px-4 py-2.5 rounded-xl transition ${
              activeTab === "VOTING"
                ? "bg-amber-500 text-slate-950 font-bold"
                : "text-slate-400 hover:text-white hover:bg-slate-900"
            }`}
          >
            Live Votes & Anti-Fraud
          </button>

          <button
            onClick={() => setActiveTab("SETTINGS")}
            className={`px-4 py-2.5 rounded-xl transition flex items-center space-x-1.5 ${
              activeTab === "SETTINGS"
                ? "bg-amber-500 text-slate-950 font-bold"
                : "text-slate-400 hover:text-white hover:bg-slate-900"
            }`}
          >
            <Sliders className="w-3.5 h-3.5" />
            <span>Award Title & Settings</span>
          </button>

          <button
            onClick={() => setActiveTab("ACCESS_KEYS")}
            className={`px-4 py-2.5 rounded-xl transition flex items-center space-x-1.5 ${
              activeTab === "ACCESS_KEYS"
                ? "bg-amber-500 text-slate-950 font-bold"
                : "text-slate-400 hover:text-white hover:bg-slate-900"
            }`}
          >
            <Key className="w-3.5 h-3.5" />
            <span>Access Directory & Credentials</span>
          </button>

          <button
            onClick={() => setActiveTab("AUDIT")}
            className={`px-4 py-2.5 rounded-xl transition ${
              activeTab === "AUDIT"
                ? "bg-amber-500 text-slate-950 font-bold"
                : "text-slate-400 hover:text-white hover:bg-slate-900"
            }`}
          >
            Audit Trail & Logs
          </button>
        </div>

        {/* TAB 1: OVERVIEW */}
        {activeTab === "OVERVIEW" && (
          <div className="space-y-8">
            {/* Quick Metrics */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="p-5 bg-slate-900/80 border border-slate-800 rounded-2xl space-y-1">
                <div className="text-xs text-slate-400">Pending Review</div>
                <div className="text-3xl font-extrabold text-amber-400">#{pendingCount}</div>
                <div className="text-[10px] text-slate-500">Requires jury approval</div>
              </div>

              <div className="p-5 bg-slate-900/80 border border-slate-800 rounded-2xl space-y-1">
                <div className="text-xs text-slate-400">Approved Honored Finalists</div>
                <div className="text-3xl font-extrabold text-emerald-400">#{approvedCount}</div>
                <div className="text-[10px] text-slate-500">Live in public voting gallery</div>
              </div>

              <div className="p-5 bg-slate-900/80 border border-slate-800 rounded-2xl space-y-1">
                <div className="text-xs text-slate-400">Total Verified Votes Cast</div>
                <div className="text-3xl font-extrabold text-white">#{totalVotesCast.toLocaleString()}</div>
                <div className="text-[10px] text-slate-500">Audited voter entries</div>
              </div>

              <div className="p-5 bg-slate-900/80 border border-slate-800 rounded-2xl space-y-1">
                <div className="text-xs text-slate-400">Award Categories</div>
                <div className="text-3xl font-extrabold text-blue-400">#{categoriesList.length}</div>
                <div className="text-[10px] text-slate-500">Active award categories</div>
              </div>
            </div>

            {/* Title & Branding Summary Card */}
            <div className="p-6 bg-gradient-to-r from-amber-950/20 via-slate-900 to-slate-900 border border-amber-500/30 rounded-3xl space-y-3">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-3">
                <div className="space-y-1">
                  <span className="text-[10px] uppercase font-bold text-amber-400 tracking-wider">
                    Current Configured Title
                  </span>
                  <h3 className="text-xl font-extrabold text-white">
                    {settings?.bannerTitle || "CSCPO South Asian Leadership Awards"}
                  </h3>
                  <p className="text-xs text-slate-300">
                    {settings?.bannerSubtitle || "Recognizing Visionary Leadership & Operational Excellence"}
                  </p>
                </div>

                <button
                  onClick={() => setActiveTab("SETTINGS")}
                  className="px-4 py-2 rounded-xl bg-amber-500 text-slate-950 font-bold text-xs flex items-center space-x-1.5 shrink-0"
                >
                  <Edit className="w-3.5 h-3.5" />
                  <span>Change Award Title</span>
                </button>
              </div>

              <div className="flex flex-wrap items-center gap-4 text-xs text-slate-400">
                <span>
                  Voting Policy: <strong className="text-amber-400">{settings?.votingPolicy}</strong>
                </span>
                <span>•</span>
                <span>
                  Nomination Portal: <strong className="text-emerald-400">Public & Open to Anyone</strong>
                </span>
              </div>
            </div>

            {/* Voting Killswitch Controls */}
            <div className="p-6 bg-slate-900/60 border border-slate-800 rounded-3xl space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-3">
                <div>
                  <h3 className="text-base font-bold text-white flex items-center space-x-2">
                    <Lock className="w-4 h-4 text-amber-400" />
                    <span>Voting Phase Status Controls</span>
                  </h3>
                  <p className="text-xs text-slate-400">
                    Start, temporarily pause for verification, or close the public voting phase.
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <button
                  onClick={() => handleSetVotingStatus("OPEN")}
                  className={`p-4 rounded-2xl border text-left transition flex items-center justify-between cursor-pointer ${
                    settings?.votingStatus === "OPEN"
                      ? "bg-emerald-950/60 border-emerald-500/50 text-emerald-200"
                      : "bg-slate-950 border-slate-800 text-slate-400 hover:text-white"
                  }`}
                >
                  <div>
                    <div className="font-bold text-sm">Voting Open</div>
                    <div className="text-[11px] text-slate-400">Public can vote freely</div>
                  </div>
                  <PlayCircle className="w-5 h-5 text-emerald-400" />
                </button>

                <button
                  onClick={() => handleSetVotingStatus("PAUSED")}
                  className={`p-4 rounded-2xl border text-left transition flex items-center justify-between cursor-pointer ${
                    settings?.votingStatus === "PAUSED"
                      ? "bg-amber-950/60 border-amber-500/50 text-amber-200"
                      : "bg-slate-950 border-slate-800 text-slate-400 hover:text-white"
                  }`}
                >
                  <div>
                    <div className="font-bold text-sm">Pause Voting</div>
                    <div className="text-[11px] text-slate-400">Freeze vote operations</div>
                  </div>
                  <PauseCircle className="w-5 h-5 text-amber-400" />
                </button>

                <button
                  onClick={() => handleSetVotingStatus("CLOSED")}
                  className={`p-4 rounded-2xl border text-left transition flex items-center justify-between cursor-pointer ${
                    settings?.votingStatus === "CLOSED"
                      ? "bg-red-950/60 border-red-500/50 text-red-200"
                      : "bg-slate-950 border-slate-800 text-slate-400 hover:text-white"
                  }`}
                >
                  <div>
                    <div className="font-bold text-sm">Close Voting</div>
                    <div className="text-[11px] text-slate-400">Final results lock</div>
                  </div>
                  <StopCircle className="w-5 h-5 text-red-400" />
                </button>
              </div>
            </div>

            {/* Quick Export & Actions */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="p-6 bg-slate-900/60 border border-slate-800 rounded-3xl space-y-3">
                <h4 className="text-sm font-bold text-white flex items-center space-x-2">
                  <Download className="w-4 h-4 text-amber-400" />
                  <span>Export Official Reports</span>
                </h4>
                <p className="text-xs text-slate-400">
                  Export complete verified datasets for executive committee review, jury auditing, or archival.
                </p>
                <div className="flex flex-wrap gap-2 pt-1">
                  <a
                    href="/api/admin/export?type=nominees"
                    className="px-4 py-2 rounded-xl bg-slate-950 hover:bg-slate-850 border border-slate-700 text-xs font-semibold text-slate-200 flex items-center space-x-1.5"
                  >
                    <span>Download Nominees (CSV)</span>
                  </a>
                  <a
                    href="/api/admin/export?type=votes"
                    className="px-4 py-2 rounded-xl bg-slate-950 hover:bg-slate-850 border border-slate-700 text-xs font-semibold text-slate-200 flex items-center space-x-1.5"
                  >
                    <span>Download Votes Ledger (CSV)</span>
                  </a>
                </div>
              </div>

              <div className="p-6 bg-slate-900/60 border border-slate-800 rounded-3xl space-y-3">
                <h4 className="text-sm font-bold text-white flex items-center space-x-2">
                  <FolderPlus className="w-4 h-4 text-emerald-400" />
                  <span>Add New Category</span>
                </h4>
                <p className="text-xs text-slate-400">
                  Create new specialized award categories or customize existing category descriptions.
                </p>
                <button
                  onClick={() => setShowNewCategoryModal(true)}
                  className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs flex items-center space-x-1.5 cursor-pointer"
                >
                  <Plus className="w-4 h-4" />
                  <span>+ Create New Award Category</span>
                </button>
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: NOMINATIONS MANAGEMENT (APPROVE/REJECT) */}
        {activeTab === "NOMINATIONS" && (
          <div className="space-y-6">
            {/* Open Submission Info Ribbon */}
            <div className="p-4 bg-emerald-950/40 border border-emerald-500/30 rounded-2xl flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
              <div className="flex items-center space-x-2.5">
                <CheckCircle className="w-5 h-5 text-emerald-400 shrink-0" />
                <div>
                  <span className="font-bold text-emerald-300">Open Public Nomination Portal:</span>
                  <span className="text-slate-300 ml-1">
                    Anyone (individuals, companies, peers, or self-nominations) can submit nominations online at{" "}
                    <code>/nominate</code>. Submissions arrive here for admin approval.
                  </span>
                </div>
              </div>

              <Link
                href="/nominate"
                target="_blank"
                className="px-4 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs whitespace-nowrap flex items-center space-x-1.5 shrink-0"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Submit a Nomination</span>
              </Link>
            </div>

            {/* Filter toolbar */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-900/80 p-4 rounded-2xl border border-slate-800">
              <div className="flex flex-wrap items-center gap-2">
                {[
                  { key: "ALL", label: `All (${nomineesList.length})` },
                  { key: "PENDING", label: `Pending Review (${pendingCount})` },
                  { key: "APPROVED", label: `Approved Finalists (${approvedCount})` },
                  { key: "REJECTED", label: `Rejected (${rejectedCount})` },
                ].map((st) => (
                  <button
                    key={st.key}
                    onClick={() => setNominationFilter(st.key)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition cursor-pointer ${
                      nominationFilter === st.key
                        ? "bg-amber-500 text-slate-950 font-bold"
                        : "bg-slate-950 text-slate-400 hover:text-white border border-slate-800"
                    }`}
                  >
                    {st.label}
                  </button>
                ))}
              </div>

              <div className="relative min-w-[240px]">
                <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  placeholder="Filter by name, company, or ref..."
                  value={nominationSearch}
                  onChange={(e) => setNominationSearch(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl pl-9 pr-3 py-1.5 text-xs text-white"
                />
              </div>
            </div>

            {/* Nominations Table */}
            <div className="bg-slate-900/60 border border-slate-800 rounded-3xl overflow-hidden shadow-xl">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-950 border-b border-slate-800 text-slate-400 uppercase tracking-wider text-[10px]">
                    <tr>
                      <th className="p-4">Ref Code & Candidate</th>
                      <th className="p-4">Category</th>
                      <th className="p-4">Company & Country</th>
                      <th className="p-4">Status</th>
                      <th className="p-4">Total Votes</th>
                      <th className="p-4 text-right">Approval Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/80">
                    {filteredNominees.map((n) => (
                      <tr key={n.id} className="hover:bg-slate-900/80 transition">
                        <td className="p-4">
                          <div className="flex items-center space-x-3">
                            <img
                              src={n.photoUrl}
                              alt={n.name}
                              className="w-10 h-10 rounded-xl object-cover border border-slate-700 shrink-0"
                            />
                            <div>
                              <div className="font-bold text-white text-sm">{n.name}</div>
                              <div className="font-mono text-[10px] text-amber-400">{n.refNumber}</div>
                              <div className="text-[10px] text-slate-500">{n.designation}</div>
                            </div>
                          </div>
                        </td>

                        <td className="p-4 text-slate-300 max-w-[200px]">
                          <span className="font-medium text-amber-300/90">{n.categoryName || "General Award"}</span>
                        </td>

                        <td className="p-4">
                          <div className="text-slate-200 font-medium">{n.organization}</div>
                          <div className="text-slate-500 text-[10px]">{n.country}</div>
                        </td>

                        <td className="p-4">
                          {n.status === "APPROVED" && (
                            <span className="px-2.5 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-bold text-[10px]">
                              ✓ Approved & Published
                            </span>
                          )}
                          {n.status === "PENDING" && (
                            <span className="px-2.5 py-1 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30 font-bold text-[10px] animate-pulse">
                              ⏳ Pending Review
                            </span>
                          )}
                          {n.status === "REJECTED" && (
                            <span className="px-2.5 py-1 rounded-full bg-red-500/20 text-red-300 border border-red-500/30 font-bold text-[10px]">
                              ✕ Rejected
                            </span>
                          )}
                        </td>

                        <td className="p-4 font-mono font-bold text-amber-400">
                          #{n.voteCount.toLocaleString()}
                        </td>

                        <td className="p-4 text-right space-x-1.5 whitespace-nowrap">
                          {/* Approve Button */}
                          {n.status !== "APPROVED" && (
                            <button
                              onClick={() => handleUpdateNomineeStatus(n.id, "APPROVED")}
                              className="px-3 py-1.5 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-[11px] transition shadow cursor-pointer inline-flex items-center space-x-1"
                              title="Approve & Publish to Public Voting Gallery"
                            >
                              <Check className="w-3.5 h-3.5" />
                              <span>Approve</span>
                            </button>
                          )}

                          {/* Reject Button */}
                          {n.status !== "REJECTED" && (
                            <button
                              onClick={() => {
                                setRejectModalNominee(n);
                                setRejectionReasonInput("");
                              }}
                              className="px-2.5 py-1.5 rounded-lg bg-red-950/80 hover:bg-red-900 text-red-300 border border-red-500/40 text-[11px] font-semibold transition cursor-pointer inline-flex items-center space-x-1"
                              title="Reject with feedback"
                            >
                              <X className="w-3.5 h-3.5" />
                              <span>Reject</span>
                            </button>
                          )}

                          <button
                            onClick={() => setEditModalNominee(n)}
                            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 transition"
                            title="Edit candidate profile"
                          >
                            <Edit className="w-3.5 h-3.5" />
                          </button>

                          <Link
                            href={`/nominee/${n.slug}`}
                            target="_blank"
                            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 inline-block transition"
                            title="View public profile"
                          >
                            <ExternalLink className="w-3.5 h-3.5" />
                          </Link>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* TAB 3: CATEGORIES MANAGEMENT (ADD NEW CATEGORY & EDIT) */}
        {activeTab === "CATEGORIES" && (
          <div className="space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-900/80 p-5 rounded-3xl border border-slate-800">
              <div>
                <h3 className="text-base font-bold text-white flex items-center space-x-2">
                  <FolderPlus className="w-5 h-5 text-amber-400" />
                  <span>Award Categories Management</span>
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  Add new specialized award categories or customize criteria. These automatically appear in the
                  nomination form and voting gallery.
                </p>
              </div>

              <button
                onClick={() => setShowNewCategoryModal(true)}
                className="px-4 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs flex items-center space-x-1.5 shrink-0 cursor-pointer shadow-lg shadow-amber-500/20"
              >
                <Plus className="w-4 h-4" />
                <span>+ Add New Award Category</span>
              </button>
            </div>

            {/* Categories Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
              {categoriesList.map((cat) => {
                const catNominees = nomineesList.filter((n) => n.categoryId === cat.id);
                const totalVotes = catNominees.reduce((acc, curr) => acc + (curr.voteCount || 0), 0);

                return (
                  <div
                    key={cat.id}
                    className="p-5 bg-slate-900/60 border border-slate-800 rounded-3xl flex flex-col justify-between space-y-4 shadow-lg hover:border-amber-500/40 transition"
                  >
                    <div className="space-y-2.5">
                      <div className="flex items-center justify-between">
                        <div className="w-9 h-9 rounded-xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400">
                          <Award className="w-5 h-5" />
                        </div>
                        <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-slate-950 border border-slate-800 text-amber-400">
                          #{totalVotes.toLocaleString()} votes
                        </span>
                      </div>

                      <div>
                        <h4 className="font-bold text-white text-base leading-snug">{cat.name}</h4>
                        {cat.nameBn && (
                          <div className="text-xs text-amber-400/80 font-bangla mt-0.5">{cat.nameBn}</div>
                        )}
                      </div>

                      <p className="text-xs text-slate-400 line-clamp-3 leading-relaxed">
                        {cat.description}
                      </p>

                      <div className="text-[11px] text-slate-400 pt-1">
                        Approved Nominees: <strong className="text-white">{catNominees.length}</strong>
                      </div>
                    </div>

                    <div className="pt-3 border-t border-slate-800/80 flex items-center justify-between text-xs">
                      <button
                        onClick={() => setEditingCategory(cat)}
                        className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold flex items-center space-x-1 transition cursor-pointer"
                      >
                        <Edit className="w-3.5 h-3.5" />
                        <span>Edit</span>
                      </button>

                      <button
                        onClick={() => handleDeactivateCategory(cat.id, cat.name)}
                        className="px-3 py-1.5 rounded-lg bg-red-950/50 hover:bg-red-900 text-red-300 border border-red-500/30 font-semibold flex items-center space-x-1 transition cursor-pointer text-[11px]"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                        <span>Deactivate</span>
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* TAB: TITLE LOGO & SPONSORS */}
        {activeTab === "BRANDING" && (
          <div className="space-y-8 animate-fade-in">
            {/* 1. TITLE LOGO MANAGEMENT */}
            <div className="p-6 sm:p-8 bg-slate-900/60 border border-slate-800 rounded-3xl space-y-6 shadow-xl">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4">
                <div>
                  <h3 className="text-lg font-bold text-white flex items-center space-x-2">
                    <ImageIcon className="w-5 h-5 text-amber-400" />
                    <span>Award Title Logo & Crest Upload</span>
                  </h3>
                  <p className="text-xs text-slate-400 mt-1">
                    Upload your official award logo or crest. This logo appears in the top navigation bar, footer brand mark, campaign posters, and notification headers.
                  </p>
                </div>

                <div className="flex items-center space-x-2">
                  <button
                    onClick={() => saveLogoUrl("/images/cscpo-award-logo.png")}
                    className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold cursor-pointer transition"
                  >
                    Reset to Default Crest
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-center">
                {/* Logo Preview */}
                <div className="md:col-span-4 flex flex-col items-center justify-center p-6 bg-slate-950 border border-slate-800 rounded-2xl space-y-3">
                  <div className="w-24 h-24 rounded-full bg-slate-900 border-2 border-amber-400/50 p-2 flex items-center justify-center shadow-xl overflow-hidden">
                    <img
                      src={settings?.logoUrl || "/images/cscpo-award-logo.png"}
                      alt="Current Title Logo"
                      className="w-full h-full object-contain"
                      onError={(e) => {
                        (e.target as HTMLImageElement).src = "/images/cscpo-award-logo.png";
                      }}
                    />
                  </div>
                  <div className="text-center">
                    <div className="text-xs font-bold text-white">Active Award Logo</div>
                    <div className="text-[10px] text-slate-500 font-mono truncate max-w-[200px]">
                      {settings?.logoUrl || "/images/cscpo-award-logo.png"}
                    </div>
                  </div>
                </div>

                {/* Upload & URL Input Controls */}
                <div className="md:col-span-8 space-y-4">
                  {/* File Upload Option */}
                  <div className="p-4 bg-slate-950/80 border border-slate-800 rounded-2xl space-y-2">
                    <label className="text-xs font-bold text-white flex items-center space-x-2">
                      <Upload className="w-4 h-4 text-amber-400" />
                      <span>Option A: Upload Image File from Computer</span>
                    </label>
                    <p className="text-[11px] text-slate-400">
                      Supports PNG, JPG, JPEG, SVG or WebP (transparent background recommended, max 5MB).
                    </p>
                    <div className="flex items-center space-x-3 pt-1">
                      <label className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-bold text-xs flex items-center space-x-2 cursor-pointer shadow-md shadow-amber-500/20 transition">
                        <Upload className="w-3.5 h-3.5" />
                        <span>{isUploadingLogo ? "Uploading..." : "Choose & Upload Logo File"}</span>
                        <input
                          type="file"
                          accept="image/*"
                          onChange={handleLogoFileChange}
                          disabled={isUploadingLogo}
                          className="hidden"
                        />
                      </label>
                      {isUploadingLogo && (
                        <div className="flex items-center space-x-2 text-xs text-amber-400">
                          <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                          <span>Saving to server...</span>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Direct URL Option */}
                  <div className="p-4 bg-slate-950/80 border border-slate-800 rounded-2xl space-y-2">
                    <label className="text-xs font-bold text-white flex items-center space-x-2">
                      <Globe className="w-4 h-4 text-blue-400" />
                      <span>Option B: Paste Image URL Directly</span>
                    </label>
                    <div className="flex items-center space-x-2">
                      <input
                        type="url"
                        placeholder="https://example.com/logo.png"
                        value={logoInputUrl}
                        onChange={(e) => setLogoInputUrl(e.target.value)}
                        className="flex-1 bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white"
                      />
                      <button
                        onClick={() => {
                          if (logoInputUrl.trim()) saveLogoUrl(logoInputUrl.trim());
                        }}
                        className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs cursor-pointer transition shrink-0"
                      >
                        Set URL
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* 2. CORPORATE SPONSORS MANAGEMENT */}
            <div className="p-6 sm:p-8 bg-slate-900/60 border border-slate-800 rounded-3xl space-y-6 shadow-xl">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4">
                <div>
                  <h3 className="text-lg font-bold text-white flex items-center space-x-2">
                    <Handshake className="w-5 h-5 text-amber-400" />
                    <span>Corporate Sponsor Logos</span>
                  </h3>
                  <p className="text-xs text-slate-400 mt-1">
                    Manage official event sponsors (Title, Platinum, Gold, Associate). These appear in the dedicated Sponsors showcase on the awards homepage.
                  </p>
                </div>

                <button
                  onClick={() => {
                    setSponsorName("");
                    setSponsorTier("Title Sponsor");
                    setSponsorLogoUrl("");
                    setSponsorWebsite("");
                    setShowNewSponsorModal(true);
                  }}
                  className="px-4 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs flex items-center space-x-1.5 shrink-0 cursor-pointer shadow-lg shadow-amber-500/20"
                >
                  <Plus className="w-4 h-4" />
                  <span>+ Add Corporate Sponsor</span>
                </button>
              </div>

              {/* Sponsors Cards Grid */}
              {((settings?.sponsorLogos as unknown as SponsorLogo[]) || []).length > 0 ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
                  {((settings?.sponsorLogos as unknown as SponsorLogo[]) || []).map((sp) => (
                    <div
                      key={sp.id}
                      className="p-4 bg-slate-950 border border-slate-800 rounded-2xl flex flex-col justify-between space-y-3"
                    >
                      <div className="flex items-center justify-between">
                        <span className="px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 font-bold text-[10px] uppercase">
                          {sp.tier}
                        </span>
                        <button
                          onClick={() => handleDeleteSponsor(sp.id, sp.name)}
                          className="p-1 text-red-400 hover:text-red-300 hover:bg-red-950/40 rounded transition cursor-pointer"
                          title="Remove Sponsor"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>

                      <div className="w-full h-24 bg-slate-900 rounded-xl p-2 flex items-center justify-center border border-slate-800">
                        <img
                          src={sp.logoUrl}
                          alt={sp.name}
                          className="w-full h-full object-contain"
                          onError={(e) => {
                            (e.target as HTMLImageElement).src = "/images/cscpo-award-logo.png";
                          }}
                        />
                      </div>

                      <div>
                        <div className="font-bold text-white text-xs">{sp.name}</div>
                        {sp.websiteUrl && (
                          <a
                            href={sp.websiteUrl}
                            target="_blank"
                            rel="noreferrer"
                            className="text-[10px] text-slate-500 hover:text-amber-400 flex items-center space-x-1 mt-0.5 truncate"
                          >
                            <span className="truncate">{sp.websiteUrl}</span>
                            <ExternalLink className="w-2.5 h-2.5 shrink-0" />
                          </a>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8 bg-slate-950 border border-slate-800 rounded-2xl p-4 text-xs text-slate-400">
                  No corporate sponsors added yet. Click &ldquo;+ Add Corporate Sponsor&rdquo; to upload your first sponsor logo.
                </div>
              )}
            </div>

            {/* 3. SUPPORTING ORGANIZATIONS & PARTNERS MANAGEMENT */}
            <div className="p-6 sm:p-8 bg-slate-900/60 border border-slate-800 rounded-3xl space-y-6 shadow-xl">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4">
                <div>
                  <h3 className="text-lg font-bold text-white flex items-center space-x-2">
                    <ShieldCheck className="w-5 h-5 text-emerald-400" />
                    <span>Supporting Organization Logos</span>
                  </h3>
                  <p className="text-xs text-slate-400 mt-1">
                    Manage supporting institutions, academic partners, media partners, and industry associations.
                  </p>
                </div>

                <button
                  onClick={() => {
                    setSupporterName("");
                    setSupporterRole("Strategic Partner");
                    setSupporterLogoUrl("");
                    setSupporterWebsite("");
                    setShowNewSupporterModal(true);
                  }}
                  className="px-4 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs flex items-center space-x-1.5 shrink-0 cursor-pointer shadow-lg shadow-emerald-500/20"
                >
                  <Plus className="w-4 h-4" />
                  <span>+ Add Supporting Partner</span>
                </button>
              </div>

              {/* Supporters Cards Grid */}
              {((settings?.supportLogos as unknown as SupportLogo[]) || []).length > 0 ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
                  {((settings?.supportLogos as unknown as SupportLogo[]) || []).map((sup) => (
                    <div
                      key={sup.id}
                      className="p-4 bg-slate-950 border border-slate-800 rounded-2xl flex flex-col justify-between space-y-3"
                    >
                      <div className="flex items-center justify-between">
                        <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 font-bold text-[10px] uppercase">
                          {sup.role}
                        </span>
                        <button
                          onClick={() => handleDeleteSupporter(sup.id, sup.name)}
                          className="p-1 text-red-400 hover:text-red-300 hover:bg-red-950/40 rounded transition cursor-pointer"
                          title="Remove Partner"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>

                      <div className="w-full h-24 bg-slate-900 rounded-xl p-2 flex items-center justify-center border border-slate-800">
                        <img
                          src={sup.logoUrl}
                          alt={sup.name}
                          className="w-full h-full object-contain"
                          onError={(e) => {
                            (e.target as HTMLImageElement).src = "/images/cscpo-award-logo.png";
                          }}
                        />
                      </div>

                      <div>
                        <div className="font-bold text-white text-xs">{sup.name}</div>
                        {sup.websiteUrl && (
                          <a
                            href={sup.websiteUrl}
                            target="_blank"
                            rel="noreferrer"
                            className="text-[10px] text-slate-500 hover:text-emerald-400 flex items-center space-x-1 mt-0.5 truncate"
                          >
                            <span className="truncate">{sup.websiteUrl}</span>
                            <ExternalLink className="w-2.5 h-2.5 shrink-0" />
                          </a>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8 bg-slate-950 border border-slate-800 rounded-2xl p-4 text-xs text-slate-400">
                  No supporting partners added yet. Click &ldquo;+ Add Supporting Partner&rdquo; to add institutions or associations.
                </div>
              )}
            </div>
          </div>
        )}

        {/* TAB 4: LIVE VOTES & FRAUD CENTER */}
        {activeTab === "VOTING" && (
          <div className="space-y-6">
            <div className="p-6 bg-slate-900/60 border border-slate-800 rounded-3xl space-y-2">
              <h3 className="text-lg font-bold text-white flex items-center space-x-2">
                <AlertTriangle className="w-5 h-5 text-amber-400" />
                <span>Voting Integrity & Fraud Monitoring Console</span>
              </h3>
              <p className="text-xs text-slate-400">
                Real-time stream of incoming votes with IP velocity heuristics, provider verification, and revocation
                controls.
              </p>
            </div>

            <div className="bg-slate-900/60 border border-slate-800 rounded-3xl overflow-hidden shadow-xl">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-950 border-b border-slate-800 text-slate-400 uppercase tracking-wider text-[10px]">
                    <tr>
                      <th className="p-4">Vote ID</th>
                      <th className="p-4">Voter Email</th>
                      <th className="p-4">Candidate Voted</th>
                      <th className="p-4">Auth Provider</th>
                      <th className="p-4">IP Address</th>
                      <th className="p-4">Status</th>
                      <th className="p-4 text-right">Integrity Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/80">
                    {votingRecords.map((v) => (
                      <tr key={v.id} className="hover:bg-slate-900/80 transition">
                        <td className="p-4 font-mono text-slate-400 text-[11px]">#{v.id}</td>
                        <td className="p-4 font-medium text-slate-200">{v.voterEmail}</td>
                        <td className="p-4 text-amber-400 font-bold">{v.nomineeName || `Candidate #${v.nomineeId}`}</td>
                        <td className="p-4">
                          <span className="px-2 py-0.5 rounded bg-slate-950 border border-slate-800 text-[10px] text-slate-300">
                            {v.verificationMethod}
                          </span>
                        </td>
                        <td className="p-4 font-mono text-[11px] text-slate-400">{v.ipAddress || "127.0.0.1"}</td>
                        <td className="p-4">
                          {v.isFraud ? (
                            <span className="px-2 py-0.5 rounded bg-red-500/20 text-red-300 border border-red-500/30 text-[10px] font-bold">
                              Flagged Fraud
                            </span>
                          ) : !v.isValid ? (
                            <span className="px-2 py-0.5 rounded bg-slate-800 text-slate-400 text-[10px]">
                              Revoked
                            </span>
                          ) : (
                            <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-[10px] font-bold">
                              Valid Certified
                            </span>
                          )}
                        </td>
                        <td className="p-4 text-right space-x-2">
                          {v.isValid && (
                            <button
                              onClick={() => handleRevokeVote(v.id)}
                              className="px-2.5 py-1 rounded-lg bg-red-950/60 hover:bg-red-900 text-red-300 border border-red-500/30 text-[11px] font-semibold transition cursor-pointer"
                            >
                              Revoke Vote
                            </button>
                          )}
                          <button
                            onClick={() => handleSuspendVoter(v.id)}
                            className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 text-[11px] transition cursor-pointer"
                          >
                            Suspend Voter
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* TAB 5: TITLE OF AWARD & COMPETITION SETTINGS */}
        {activeTab === "SETTINGS" && settings && (
          <form
            onSubmit={handleSaveSettings}
            className="bg-slate-900/60 border border-slate-800 p-8 rounded-3xl space-y-6 max-w-4xl shadow-xl"
          >
            <div className="border-b border-slate-800 pb-4">
              <h3 className="text-lg font-bold text-white flex items-center space-x-2">
                <Settings className="w-5 h-5 text-amber-400" />
                <span>Title of Award & Platform Configuration</span>
              </h3>
              <p className="text-xs text-slate-400 mt-1">
                Customize the overarching award title, subtitle, announcement messages, and voting rules for current
                and future editions.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
              {/* AWARD TITLE INPUT */}
              <div className="sm:col-span-2 p-4 bg-slate-950 rounded-2xl border border-amber-500/40 space-y-2">
                <label className="block text-xs font-bold text-amber-400 uppercase tracking-wider flex items-center justify-between">
                  <span>Official Title of Award</span>
                  <span className="text-[10px] text-slate-400 lowercase font-normal">
                    (Editable for future years/editions)
                  </span>
                </label>
                <input
                  type="text"
                  placeholder="e.g. CSCPO South Asian Leadership Awards"
                  value={settings.bannerTitle || ""}
                  onChange={(e) => setSettings({ ...settings, bannerTitle: e.target.value })}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-4 py-3 text-base font-extrabold text-white focus:outline-none focus:border-amber-400"
                  required
                />
                <p className="text-[11px] text-slate-400">
                  This title updates the website header, metadata, nominee cards, campaign posters, and email notifications.
                </p>
              </div>

              {/* AWARD SUBTITLE */}
              <div className="sm:col-span-2">
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  Award Subtitle / Tagline
                </label>
                <input
                  type="text"
                  placeholder="e.g. Recognizing Visionary Leadership, Operational Excellence & Innovation"
                  value={settings.bannerSubtitle || ""}
                  onChange={(e) => setSettings({ ...settings, bannerSubtitle: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-2.5 text-xs text-white"
                />
              </div>

              {/* ANNOUNCEMENT TEXT */}
              <div className="sm:col-span-2">
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  Announcement Ribbon Banner Text
                </label>
                <input
                  type="text"
                  value={settings.announcementText || ""}
                  onChange={(e) => setSettings({ ...settings, announcementText: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-2.5 text-xs text-white"
                />
              </div>

              {/* VOTING POLICY */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  Voting Enforcement Policy
                </label>
                <select
                  value={settings.votingPolicy}
                  onChange={(e) => setSettings({ ...settings, votingPolicy: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2.5 text-xs text-white"
                >
                  <option value="ONE_VOTE_PER_CATEGORY">1 Verified Vote Per Category (Recommended)</option>
                  <option value="ONE_VOTE_PER_NOMINEE">1 Verified Vote Per Nominee</option>
                  <option value="ONE_VOTE_OVERALL">1 Verified Vote Overall (Strict)</option>
                </select>
              </div>

              {/* VOTING STATUS */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  Voting Phase Status
                </label>
                <select
                  value={settings.votingStatus}
                  onChange={(e) => setSettings({ ...settings, votingStatus: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2.5 text-xs text-white"
                >
                  <option value="OPEN">OPEN - Public voting active</option>
                  <option value="PAUSED">PAUSED - Temporary audit calibration</option>
                  <option value="CLOSED">CLOSED - Voting closed</option>
                </select>
              </div>

              {/* CHECKBOXES */}
              <div className="sm:col-span-2 grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                <label className="flex items-center space-x-2 text-xs text-slate-300 cursor-pointer p-3 bg-slate-950 rounded-xl border border-slate-800">
                  <input
                    type="checkbox"
                    checked={settings.showPublicCounts}
                    onChange={(e) => setSettings({ ...settings, showPublicCounts: e.target.checked })}
                    className="rounded bg-slate-950 border-slate-700 text-amber-500"
                  />
                  <span>Show Total Vote Counts Publicly</span>
                </label>

                <label className="flex items-center space-x-2 text-xs text-slate-300 cursor-pointer p-3 bg-slate-950 rounded-xl border border-slate-800">
                  <input
                    type="checkbox"
                    checked={settings.requireCaptcha}
                    onChange={(e) => setSettings({ ...settings, requireCaptcha: e.target.checked })}
                    className="rounded bg-slate-950 border-slate-700 text-amber-500"
                  />
                  <span>Require Anti-Bot Challenge at Vote Confirmation</span>
                </label>

                <label className="flex items-center space-x-2 text-xs text-slate-300 cursor-pointer p-3 bg-slate-950 rounded-xl border border-slate-800">
                  <input
                    type="checkbox"
                    checked={settings.allowNominationDrafts}
                    onChange={(e) => setSettings({ ...settings, allowNominationDrafts: e.target.checked })}
                    className="rounded bg-slate-950 border-slate-700 text-amber-500"
                  />
                  <span>Allow Users to Save Nomination Drafts</span>
                </label>
              </div>
            </div>

            <div className="pt-4 border-t border-slate-800 flex justify-end">
              <button
                type="submit"
                className="px-8 py-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs uppercase tracking-wide cursor-pointer shadow-lg shadow-amber-500/20"
              >
                Save Settings & Award Title
              </button>
            </div>
          </form>
        )}

        {/* TAB 6: AUDIT TRAIL & LOGS */}
        {activeTab === "AUDIT" && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Audit Logs */}
            <div className="bg-slate-900/60 border border-slate-800 p-6 rounded-3xl space-y-4">
              <h3 className="text-base font-bold text-white flex items-center space-x-2">
                <FileText className="w-4 h-4 text-amber-400" />
                <span>Immutable Admin Audit Trail</span>
              </h3>
              <div className="space-y-2 max-h-96 overflow-y-auto no-scrollbar text-xs">
                {auditLogs.map((log) => (
                  <div key={log.id} className="p-3 bg-slate-950 border border-slate-800 rounded-xl space-y-1">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-amber-400">{log.action}</span>
                      <span className="text-[10px] text-slate-500">
                        {new Date(log.createdAt).toLocaleString()}
                      </span>
                    </div>
                    <p className="text-slate-300">{log.details}</p>
                    <div className="text-[10px] text-slate-500">By: {log.performedBy}</div>
                  </div>
                ))}
              </div>
            </div>

            {/* Email Notifications Dispatched */}
            <div className="bg-slate-900/60 border border-slate-800 p-6 rounded-3xl space-y-4">
              <h3 className="text-base font-bold text-white flex items-center space-x-2">
                <Bell className="w-4 h-4 text-emerald-400" />
                <span>Automated Email Notification Queue</span>
              </h3>
              <div className="space-y-2 max-h-96 overflow-y-auto no-scrollbar text-xs">
                {notifications.map((notif) => (
                  <div key={notif.id} className="p-3 bg-slate-950 border border-slate-800 rounded-xl space-y-1">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-slate-200">{notif.subject}</span>
                      <span className="text-[10px] text-emerald-400 font-bold">DELIVERED</span>
                    </div>
                    <div className="text-[11px] text-slate-400">To: {notif.recipientEmail}</div>
                    <p className="text-[11px] text-slate-500 line-clamp-2">{notif.body}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* TAB 7: ACCESS DIRECTORY & CREDENTIALS */}
        {activeTab === "ACCESS_KEYS" && (
          <div className="space-y-8 animate-fade-in">
            {/* Header intro */}
            <div className="p-6 bg-slate-900/60 border border-slate-800 rounded-3xl space-y-2">
              <div className="flex items-center space-x-2 text-amber-400 font-bold text-sm">
                <Key className="w-5 h-5" />
                <span>Central Access Keys, Credentials & Role Matrix</span>
              </div>
              <p className="text-xs text-slate-300">
                Official access links, authorized administrative credentials, and verification keys for testing and operating the CSCPO South Asian Leadership Awards platform.
              </p>
            </div>

            {/* 1. ADMINISTRATIVE CREDENTIALS */}
            <div className="space-y-4">
              <h3 className="text-base font-bold text-white flex items-center space-x-2">
                <Shield className="w-4 h-4 text-amber-400" />
                <span>1. Administrative Accounts & Credentials</span>
              </h3>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Master Admin Card */}
                <div className="p-5 bg-slate-950 border border-amber-500/40 rounded-3xl space-y-3 shadow-lg">
                  <div className="flex items-center justify-between">
                    <span className="px-2.5 py-0.5 rounded-full bg-amber-500/20 text-amber-300 font-bold text-[10px] uppercase">
                      Master Administrator
                    </span>
                    <span className="text-[11px] text-emerald-400 font-semibold">Full Governance Access</span>
                  </div>

                  <div className="space-y-2 text-xs font-mono">
                    <div className="p-2.5 bg-slate-900 rounded-xl flex items-center justify-between">
                      <div>
                        <span className="text-slate-500 text-[10px] block font-sans">Login Email:</span>
                        <span className="text-white font-bold select-all">admin@cscpo.org</span>
                      </div>
                      <button
                        onClick={() => {
                          navigator.clipboard.writeText("admin@cscpo.org");
                          showToast("Copied admin@cscpo.org to clipboard");
                        }}
                        className="p-1.5 hover:bg-slate-800 rounded text-amber-400"
                        title="Copy email"
                      >
                        <Copy className="w-4 h-4" />
                      </button>
                    </div>

                    <div className="p-2.5 bg-slate-900 rounded-xl flex items-center justify-between">
                      <div>
                        <span className="text-slate-500 text-[10px] block font-sans">Password:</span>
                        <span className="text-amber-300 font-bold select-all">cscpo@leadership#2026</span>
                      </div>
                      <button
                        onClick={() => {
                          navigator.clipboard.writeText("cscpo@leadership#2026");
                          showToast("Copied password to clipboard");
                        }}
                        className="p-1.5 hover:bg-slate-800 rounded text-amber-400"
                        title="Copy password"
                      >
                        <Copy className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  <div className="text-[11px] text-slate-400 space-y-1 pt-1">
                    <div className="font-semibold text-slate-300">Capabilities:</div>
                    <ul className="list-disc list-inside space-y-0.5 text-slate-400">
                      <li>Full platform governance & award title editing</li>
                      <li>Upload award logo, sponsors, & supporters</li>
                      <li>Add and edit award categories</li>
                      <li>Approve/reject nominations & edit nominee profiles</li>
                      <li>Live voting controls (Open, Pause, Close)</li>
                      <li>Fraud auditing, revoking invalid votes, CSV exports</li>
                    </ul>
                  </div>
                </div>

                {/* Jury Screening Officer Card */}
                <div className="p-5 bg-slate-950 border border-emerald-500/40 rounded-3xl space-y-3 shadow-lg">
                  <div className="flex items-center justify-between">
                    <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 font-bold text-[10px] uppercase">
                      Jury & Screening Committee
                    </span>
                    <span className="text-[11px] text-emerald-400 font-semibold">Evaluation Access</span>
                  </div>

                  <div className="space-y-2 text-xs font-mono">
                    <div className="p-2.5 bg-slate-900 rounded-xl flex items-center justify-between">
                      <div>
                        <span className="text-slate-500 text-[10px] block font-sans">Login Email:</span>
                        <span className="text-white font-bold select-all">jury@cscpo.org</span>
                      </div>
                      <button
                        onClick={() => {
                          navigator.clipboard.writeText("jury@cscpo.org");
                          showToast("Copied jury@cscpo.org to clipboard");
                        }}
                        className="p-1.5 hover:bg-slate-800 rounded text-emerald-400"
                        title="Copy email"
                      >
                        <Copy className="w-4 h-4" />
                      </button>
                    </div>

                    <div className="p-2.5 bg-slate-900 rounded-xl flex items-center justify-between">
                      <div>
                        <span className="text-slate-500 text-[10px] block font-sans">Password:</span>
                        <span className="text-emerald-300 font-bold select-all">jury@review#2026</span>
                      </div>
                      <button
                        onClick={() => {
                          navigator.clipboard.writeText("jury@review#2026");
                          showToast("Copied password to clipboard");
                        }}
                        className="p-1.5 hover:bg-slate-800 rounded text-emerald-400"
                        title="Copy password"
                      >
                        <Copy className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  <div className="text-[11px] text-slate-400 space-y-1 pt-1">
                    <div className="font-semibold text-slate-300">Capabilities:</div>
                    <ul className="list-disc list-inside space-y-0.5 text-slate-400">
                      <li>Screen submitted candidate dossiers</li>
                      <li>Review supporting documents and achievements</li>
                      <li>Approve candidate for public voting gallery</li>
                      <li>Reject with structured committee feedback</li>
                      <li>Inspect live transparency standing</li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>

            {/* 2. PUBLIC PLATFORM PORTAL LINKS */}
            <div className="space-y-4">
              <h3 className="text-base font-bold text-white flex items-center space-x-2">
                <Globe className="w-4 h-4 text-blue-400" />
                <span>2. Public Platform Direct Access URLs</span>
              </h3>

              <div className="bg-slate-950 border border-slate-800 rounded-3xl overflow-hidden shadow-xl">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-900/90 border-b border-slate-800 text-slate-400 uppercase tracking-wider text-[10px]">
                    <tr>
                      <th className="p-4">Portal / Page Name</th>
                      <th className="p-4">Route Path</th>
                      <th className="p-4">Access Permission</th>
                      <th className="p-4 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/80">
                    {[
                      {
                        name: "Awards Homepage",
                        path: "/",
                        desc: "Main landing hero, featured finalists, sponsors & categories",
                        access: "Public / Anyone",
                      },
                      {
                        name: "Public Voting Gallery",
                        path: "/voting",
                        desc: "Verified voting cards, search & category filters",
                        access: "Public / Verified Voters",
                      },
                      {
                        name: "Online Nomination Portal",
                        path: "/nominate",
                        desc: "Multi-field submission form, draft saving & status tracking",
                        access: "Public / Anyone",
                      },
                      {
                        name: "Live Transparency Results",
                        path: "/results",
                        desc: "Cryptographic vote counts, category shares & audit feed",
                        access: "Public / Anyone",
                      },
                      {
                        name: "Award Categories Explorer",
                        path: "/categories",
                        desc: "Comprehensive breakdown of all award disciplines",
                        access: "Public / Anyone",
                      },
                      {
                        name: "Hall of Fame / Past Laureates",
                        path: "/winners",
                        desc: "Historical recipients archive across South Asia",
                        access: "Public / Anyone",
                      },
                      {
                        name: "Organizer Admin Dashboard",
                        path: "/admin",
                        desc: "Full management, approval queue, branding & audit console",
                        access: "Master Admin & Jury",
                      },
                      {
                        name: "Developer Specifications (SRS)",
                        path: "/srs",
                        desc: "Fullstack SRS document with DB schema and API specs",
                        access: "Public / Developers",
                      },
                      {
                        name: "Iframe Embedding Mode",
                        path: "/voting?embed=true",
                        desc: "Direct embeddable version for cscpo.org/cscpobdawards2026/",
                        access: "Iframe Integration",
                      },
                    ].map((item, idx) => (
                      <tr key={idx} className="hover:bg-slate-900/50 transition">
                        <td className="p-4">
                          <div className="font-bold text-white">{item.name}</div>
                          <div className="text-[10px] text-slate-500">{item.desc}</div>
                        </td>
                        <td className="p-4 font-mono text-amber-400 text-[11px] select-all">
                          {item.path}
                        </td>
                        <td className="p-4">
                          <span className="px-2 py-0.5 rounded-full bg-slate-900 border border-slate-700 text-[10px] text-slate-300">
                            {item.access}
                          </span>
                        </td>
                        <td className="p-4 text-right space-x-2">
                          <button
                            onClick={() => {
                              const full = typeof window !== "undefined" ? `${window.location.origin}${item.path}` : item.path;
                              navigator.clipboard.writeText(full);
                              showToast(`Copied ${full}`);
                            }}
                            className="p-1.5 hover:bg-slate-800 rounded text-slate-400 hover:text-white transition"
                            title="Copy full URL"
                          >
                            <Copy className="w-3.5 h-3.5" />
                          </button>
                          <Link
                            href={item.path}
                            target="_blank"
                            className="p-1.5 hover:bg-slate-800 rounded text-slate-400 hover:text-amber-400 inline-block transition"
                            title="Open in new tab"
                          >
                            <ExternalLink className="w-3.5 h-3.5" />
                          </Link>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* 3. SERVER-SIDE VOTER AUTHENTICATION CONFIGURATION */}
            <div className="space-y-4">
              <h3 className="text-base font-bold text-white flex items-center space-x-2">
                <UserCheck className="w-4 h-4 text-emerald-400" />
                <span>3. Voter Authentication Provider Configuration</span>
              </h3>

              <div className="p-5 bg-slate-950 border border-slate-800 rounded-3xl space-y-4 text-xs">
                <p className="text-slate-300 leading-relaxed">
                  The voter modal now uses server-side OAuth and email OTP. It will not invent demo social identities or generate a public OTP in the browser. Configure these variables on the production Node host:
                </p>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                  <div className="p-4 bg-slate-900 rounded-2xl border border-blue-500/30 space-y-2">
                    <div className="font-bold text-white">Google OAuth</div>
                    <div className="text-[11px] text-slate-400">Set <code>GOOGLE_CLIENT_ID</code> and <code>GOOGLE_CLIENT_SECRET</code>.</div>
                    <div className="text-[10px] text-blue-300 font-mono break-all">Authorized redirect: https://YOUR_APP_HOST/api/auth/oauth/google/callback</div>
                  </div>
                  <div className="p-4 bg-slate-900 rounded-2xl border border-indigo-500/30 space-y-2">
                    <div className="font-bold text-white">Facebook Login</div>
                    <div className="text-[11px] text-slate-400">Set <code>FACEBOOK_APP_ID</code> and <code>FACEBOOK_APP_SECRET</code>; request <code>email</code> and <code>public_profile</code>.</div>
                    <div className="text-[10px] text-indigo-300 font-mono break-all">Authorized redirect: https://YOUR_APP_HOST/api/auth/oauth/facebook/callback</div>
                  </div>
                  <div className="p-4 bg-slate-900 rounded-2xl border border-emerald-500/30 space-y-2">
                    <div className="font-bold text-white">Email OTP</div>
                    <div className="text-[11px] text-slate-400">Set <code>RESEND_API_KEY</code>, verified <code>RESEND_FROM_EMAIL</code>, and <code>VOTER_SESSION_SECRET</code>.</div>
                    <div className="text-[10px] text-emerald-300">6-digit code expires in 10 minutes; resend and attempt limits are server-enforced.</div>
                  </div>
                </div>

                <div className="p-3 bg-amber-950/30 border border-amber-500/30 rounded-xl text-[11px] text-amber-100">
                  Google and Facebook verify account access only, not real-world identity. No provider credentials are currently configured in this environment, so those buttons show a configuration message until the site owner adds the credentials above.
                </div>
              </div>
            </div>

            {/* 4. IFRAME EMBED CODE SNIPPET */}
            <div className="space-y-4">
              <h3 className="text-base font-bold text-white flex items-center space-x-2">
                <Code className="w-4 h-4 text-amber-400" />
                <span>4. Website Embed Snippet for cscpo.org/cscpobdawards2026/</span>
              </h3>

              <div className="p-5 bg-slate-950 border border-slate-800 rounded-3xl space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs text-slate-400">
                    Paste this into any WordPress, Drupal, or custom HTML block:
                  </span>
                  <button
                    onClick={() => {
                      const snippet = `<iframe src="${typeof window !== "undefined" ? window.location.origin : "https://cscpo.org"}/voting?embed=true" width="100%" height="900" frameborder="0" style="border:none; border-radius:16px; overflow:hidden;" title="CSCPO South Asian Leadership Awards - Public Voting"></iframe>`;
                      navigator.clipboard.writeText(snippet);
                      showToast("Copied embed code snippet!");
                    }}
                    className="px-3 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs flex items-center space-x-1 cursor-pointer"
                  >
                    <Copy className="w-3.5 h-3.5" />
                    <span>Copy Iframe Code</span>
                  </button>
                </div>

                <pre className="p-3 bg-slate-900 rounded-xl text-amber-300 font-mono text-[11px] overflow-x-auto border border-slate-800 select-all">
{`<iframe 
  src="${typeof window !== "undefined" ? window.location.origin : "https://cscpo.org"}/voting?embed=true" 
  width="100%" 
  height="900" 
  frameborder="0" 
  style="border:none; border-radius:16px; overflow:hidden;"
  title="CSCPO South Asian Leadership Awards - Public Voting">
</iframe>`}
                </pre>
              </div>
            </div>
          </div>
        )}

        {/* MODAL: REJECT NOMINATION WITH REASON */}
        {rejectModalNominee && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-fade-in">
            <div className="bg-slate-900 border border-red-500/30 rounded-2xl p-6 max-w-md w-full space-y-4">
              <h3 className="text-lg font-bold text-white flex items-center space-x-2">
                <XCircle className="w-5 h-5 text-red-400" />
                <span>Reject Nomination</span>
              </h3>
              <p className="text-xs text-slate-300">
                Provide an audit reason for rejecting <strong>{rejectModalNominee.name}</strong>. An automated rejection
                notice with this feedback will be logged.
              </p>
              <textarea
                rows={3}
                placeholder="Reason for rejection (e.g. insufficient documentation or category mismatch)..."
                value={rejectionReasonInput}
                onChange={(e) => setRejectionReasonInput(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl p-3 text-xs text-white"
              />
              <div className="flex justify-end space-x-2 pt-2">
                <button
                  onClick={() => setRejectModalNominee(null)}
                  className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 text-xs cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  onClick={() =>
                    handleUpdateNomineeStatus(rejectModalNominee.id, "REJECTED", rejectionReasonInput)
                  }
                  className="px-4 py-2 rounded-xl bg-red-600 text-white font-bold text-xs cursor-pointer"
                >
                  Confirm Rejection
                </button>
              </div>
            </div>
          </div>
        )}

        {/* MODAL: EDIT NOMINEE DETAILS */}
        {editModalNominee && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-fade-in">
            <div className="bg-slate-900 border border-slate-700 rounded-2xl p-6 max-w-lg w-full space-y-4 max-h-[90vh] overflow-y-auto">
              <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                <h3 className="font-bold text-white text-base">Edit Nominee Profile</h3>
                <button onClick={() => setEditModalNominee(null)} className="text-slate-400 hover:text-white cursor-pointer">
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="space-y-3 text-xs">
                <div>
                  <label className="block text-slate-400 mb-1">Full Name</label>
                  <input
                    type="text"
                    value={editModalNominee.name}
                    onChange={(e) => setEditModalNominee({ ...editModalNominee, name: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-white"
                  />
                </div>

                <div>
                  <label className="block text-slate-400 mb-1">Designation</label>
                  <input
                    type="text"
                    value={editModalNominee.designation}
                    onChange={(e) => setEditModalNominee({ ...editModalNominee, designation: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-white"
                  />
                </div>

                <div>
                  <label className="block text-slate-400 mb-1">Organization</label>
                  <input
                    type="text"
                    value={editModalNominee.organization}
                    onChange={(e) => setEditModalNominee({ ...editModalNominee, organization: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-white"
                  />
                </div>

                <div>
                  <label className="block text-slate-400 mb-1">Photo URL</label>
                  <input
                    type="url"
                    value={editModalNominee.photoUrl}
                    onChange={(e) => setEditModalNominee({ ...editModalNominee, photoUrl: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-white"
                  />
                </div>

                <div>
                  <label className="block text-slate-400 mb-1">Achievement Summary</label>
                  <textarea
                    rows={3}
                    value={editModalNominee.achievementSummary}
                    onChange={(e) => setEditModalNominee({ ...editModalNominee, achievementSummary: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-white"
                  />
                </div>
              </div>

              <div className="flex justify-end space-x-2 pt-2 border-t border-slate-800">
                <button
                  onClick={() => setEditModalNominee(null)}
                  className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 text-xs cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  onClick={handleSaveNomineeEdit}
                  className="px-5 py-2 rounded-xl bg-amber-500 text-slate-950 font-bold text-xs cursor-pointer"
                >
                  Save Changes
                </button>
              </div>
            </div>
          </div>
        )}

        {/* MODAL: CREATE NEW CATEGORY */}
        {showNewCategoryModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-fade-in">
            <form
              onSubmit={handleCreateCategory}
              className="bg-slate-900 border border-slate-700 rounded-2xl p-6 max-w-md w-full space-y-4"
            >
              <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                <h3 className="text-base font-bold text-white flex items-center space-x-2">
                  <Plus className="w-5 h-5 text-amber-400" />
                  <span>Add New Award Category</span>
                </h3>
                <button
                  type="button"
                  onClick={() => setShowNewCategoryModal(false)}
                  className="text-slate-400 hover:text-white"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div>
                <label className="block text-xs text-slate-300 mb-1">Category Name (English) *</label>
                <input
                  type="text"
                  placeholder="e.g. Green Logistics Excellence Award"
                  value={newCatName}
                  onChange={(e) => setNewCatName(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-xs text-white"
                  required
                />
              </div>

              <div>
                <label className="block text-xs text-slate-300 mb-1">Category Name (Bengali - Optional)</label>
                <input
                  type="text"
                  placeholder="e.g. গ্রীন লজিস্টিকস এক্সিলেন্স অ্যাওয়ার্ড"
                  value={newCatNameBn}
                  onChange={(e) => setNewCatNameBn(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-xs text-white"
                />
              </div>

              <div>
                <label className="block text-xs text-slate-300 mb-1">Description & Eligibility Criteria *</label>
                <textarea
                  rows={3}
                  placeholder="Describe evaluation criteria and eligible achievements..."
                  value={newCatDesc}
                  onChange={(e) => setNewCatDesc(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-xs text-white"
                  required
                />
              </div>

              <div className="flex justify-end space-x-2 pt-2 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowNewCategoryModal(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 text-xs cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs cursor-pointer"
                >
                  Create Category
                </button>
              </div>
            </form>
          </div>
        )}

        {/* MODAL: EDIT CATEGORY */}
        {editingCategory && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-fade-in">
            <form
              onSubmit={handleSaveCategoryEdit}
              className="bg-slate-900 border border-slate-700 rounded-2xl p-6 max-w-md w-full space-y-4"
            >
              <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                <h3 className="text-base font-bold text-white flex items-center space-x-2">
                  <Edit className="w-5 h-5 text-amber-400" />
                  <span>Edit Category</span>
                </h3>
                <button
                  type="button"
                  onClick={() => setEditingCategory(null)}
                  className="text-slate-400 hover:text-white"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div>
                <label className="block text-xs text-slate-300 mb-1">Category Name</label>
                <input
                  type="text"
                  value={editingCategory.name}
                  onChange={(e) => setEditingCategory({ ...editingCategory, name: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-xs text-white"
                  required
                />
              </div>

              <div>
                <label className="block text-xs text-slate-300 mb-1">Bengali Name</label>
                <input
                  type="text"
                  value={editingCategory.nameBn || ""}
                  onChange={(e) => setEditingCategory({ ...editingCategory, nameBn: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-xs text-white"
                />
              </div>

              <div>
                <label className="block text-xs text-slate-300 mb-1">Description & Criteria</label>
                <textarea
                  rows={3}
                  value={editingCategory.description}
                  onChange={(e) => setEditingCategory({ ...editingCategory, description: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-xs text-white"
                  required
                />
              </div>

              <div className="flex justify-end space-x-2 pt-2 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setEditingCategory(null)}
                  className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 text-xs cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs cursor-pointer"
                >
                  Save Category
                </button>
              </div>
            </form>
          </div>
        )}

        {/* MODAL: ADD CORPORATE SPONSOR */}
        {showNewSponsorModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-fade-in">
            <form
              onSubmit={handleAddSponsor}
              className="bg-slate-900 border border-slate-700 rounded-2xl p-6 max-w-md w-full space-y-4"
            >
              <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                <h3 className="text-base font-bold text-white flex items-center space-x-2">
                  <Handshake className="w-5 h-5 text-amber-400" />
                  <span>Add Corporate Sponsor</span>
                </h3>
                <button
                  type="button"
                  onClick={() => setShowNewSponsorModal(false)}
                  className="text-slate-400 hover:text-white cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div>
                <label className="block text-xs text-slate-300 mb-1">Company / Sponsor Name *</label>
                <input
                  type="text"
                  placeholder="e.g. Apex Global Supply Networks"
                  value={sponsorName}
                  onChange={(e) => setSponsorName(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-xs text-white"
                  required
                />
              </div>

              <div>
                <label className="block text-xs text-slate-300 mb-1">Sponsorship Tier</label>
                <select
                  value={sponsorTier}
                  onChange={(e) => setSponsorTier(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-xs text-white"
                >
                  <option value="Title Sponsor">Title Sponsor</option>
                  <option value="Platinum Sponsor">Platinum Sponsor</option>
                  <option value="Gold Sponsor">Gold Sponsor</option>
                  <option value="Silver Sponsor">Silver Sponsor</option>
                  <option value="Associate Sponsor">Associate Sponsor</option>
                  <option value="Official Logistics Partner">Official Logistics Partner</option>
                </select>
              </div>

              {/* Logo Upload or URL */}
              <div className="space-y-2 p-3 bg-slate-950 rounded-xl border border-slate-800">
                <label className="block text-xs font-bold text-amber-400">Sponsor Logo *</label>
                
                {sponsorLogoUrl && (
                  <div className="w-20 h-20 bg-slate-900 rounded-lg p-2 border border-slate-800 mx-auto flex items-center justify-center">
                    <img
                      src={sponsorLogoUrl}
                      alt="Logo preview"
                      className="w-full h-full object-contain"
                    />
                  </div>
                )}

                <div className="flex items-center space-x-2">
                  <label className="px-3 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold cursor-pointer transition flex items-center space-x-1.5 shrink-0">
                    <Upload className="w-3.5 h-3.5" />
                    <span>{isUploadingSponsorLogo ? "Uploading..." : "Upload Logo File"}</span>
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handleSponsorFileChange}
                      disabled={isUploadingSponsorLogo}
                      className="hidden"
                    />
                  </label>
                  <span className="text-[11px] text-slate-500">or paste URL:</span>
                </div>

                <input
                  type="url"
                  placeholder="https://example.com/logo.png"
                  value={sponsorLogoUrl}
                  onChange={(e) => setSponsorLogoUrl(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white"
                  required
                />
              </div>

              <div>
                <label className="block text-xs text-slate-300 mb-1">Company Website URL</label>
                <input
                  type="url"
                  placeholder="https://company.com"
                  value={sponsorWebsite}
                  onChange={(e) => setSponsorWebsite(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-xs text-white"
                />
              </div>

              <div className="flex justify-end space-x-2 pt-2 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowNewSponsorModal(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 text-xs cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs cursor-pointer"
                >
                  Add Sponsor
                </button>
              </div>
            </form>
          </div>
        )}

        {/* MODAL: ADD SUPPORTING PARTNER */}
        {showNewSupporterModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-fade-in">
            <form
              onSubmit={handleAddSupporter}
              className="bg-slate-900 border border-slate-700 rounded-2xl p-6 max-w-md w-full space-y-4"
            >
              <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                <h3 className="text-base font-bold text-white flex items-center space-x-2">
                  <ShieldCheck className="w-5 h-5 text-emerald-400" />
                  <span>Add Supporting Partner</span>
                </h3>
                <button
                  type="button"
                  onClick={() => setShowNewSupporterModal(false)}
                  className="text-slate-400 hover:text-white cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div>
                <label className="block text-xs text-slate-300 mb-1">Partner / Organization Name *</label>
                <input
                  type="text"
                  placeholder="e.g. Institute of Business Administration (IBA)"
                  value={supporterName}
                  onChange={(e) => setSupporterName(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-xs text-white"
                  required
                />
              </div>

              <div>
                <label className="block text-xs text-slate-300 mb-1">Partner Role</label>
                <select
                  value={supporterRole}
                  onChange={(e) => setSupporterRole(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-xs text-white"
                >
                  <option value="Institutional Host">Institutional Host</option>
                  <option value="Academic Knowledge Partner">Academic Knowledge Partner</option>
                  <option value="Strategic Industry Partner">Strategic Industry Partner</option>
                  <option value="Official Media Partner">Official Media Partner</option>
                  <option value="Technology Partner">Technology Partner</option>
                  <option value="Supporting Association">Supporting Association</option>
                </select>
              </div>

              {/* Logo Upload or URL */}
              <div className="space-y-2 p-3 bg-slate-950 rounded-xl border border-slate-800">
                <label className="block text-xs font-bold text-emerald-400">Partner Logo *</label>
                
                {supporterLogoUrl && (
                  <div className="w-20 h-20 bg-slate-900 rounded-lg p-2 border border-slate-800 mx-auto flex items-center justify-center">
                    <img
                      src={supporterLogoUrl}
                      alt="Logo preview"
                      className="w-full h-full object-contain"
                    />
                  </div>
                )}

                <div className="flex items-center space-x-2">
                  <label className="px-3 py-1.5 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-xs font-bold cursor-pointer transition flex items-center space-x-1.5 shrink-0">
                    <Upload className="w-3.5 h-3.5" />
                    <span>{isUploadingSupporterLogo ? "Uploading..." : "Upload Logo File"}</span>
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handleSupporterFileChange}
                      disabled={isUploadingSupporterLogo}
                      className="hidden"
                    />
                  </label>
                  <span className="text-[11px] text-slate-500">or paste URL:</span>
                </div>

                <input
                  type="url"
                  placeholder="https://example.com/logo.png"
                  value={supporterLogoUrl}
                  onChange={(e) => setSupporterLogoUrl(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white"
                  required
                />
              </div>

              <div>
                <label className="block text-xs text-slate-300 mb-1">Partner Website URL</label>
                <input
                  type="url"
                  placeholder="https://partner-website.org"
                  value={supporterWebsite}
                  onChange={(e) => setSupporterWebsite(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-xs text-white"
                />
              </div>

              <div className="flex justify-end space-x-2 pt-2 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowNewSupporterModal(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 text-xs cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs cursor-pointer"
                >
                  Add Partner
                </button>
              </div>
            </form>
          </div>
        )}
      </div>
    </div>
  );
}
