import Link from "next/link";
import { db } from "@/db";
import { previousWinners } from "@/db/schema";
import { desc } from "drizzle-orm";
import { ensureSeeded } from "@/lib/seed";
import { Trophy, Award, Globe, ArrowRight, Sparkles } from "lucide-react";

export const dynamic = "force-dynamic";

export default async function WinnersPage() {
  await ensureSeeded();
  const winners = await db.select().from(previousWinners).orderBy(desc(previousWinners.year));

  const years = Array.from(new Set(winners.map((w) => w.year)));

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 py-10">
      <div className="container mx-auto px-4 max-w-6xl space-y-10">
        {/* Header */}
        <div className="text-center space-y-3 max-w-2xl mx-auto">
          <div className="inline-flex items-center space-x-2 px-3.5 py-1 rounded-full bg-amber-500/10 border border-amber-500/20 text-amber-300 text-xs font-semibold">
            <Trophy className="w-3.5 h-3.5 text-amber-400" />
            <span>CSCPO Hall of Fame</span>
          </div>
          <h1 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
            Previous Award Recipients
          </h1>
          <p className="text-sm text-slate-400">
            Honoring the visionary supply chain leaders, procurement heads, and logistics architects who received the
            prestigious CSCPO South Asian Leadership Award in past editions.
          </p>
        </div>

        {/* Winners by Year */}
        {years.map((year) => {
          const yearWinners = winners.filter((w) => w.year === year);
          return (
            <div key={year} className="space-y-6">
              <div className="flex items-center space-x-3 border-b border-slate-800 pb-3">
                <div className="w-9 h-9 rounded-xl bg-amber-500/20 border border-amber-400/40 flex items-center justify-center text-amber-400 font-extrabold text-sm">
                  {year}
                </div>
                <h2 className="text-xl font-bold text-white">Award Class of {year}</h2>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {yearWinners.map((winner) => (
                  <div
                    key={winner.id}
                    className="group bg-slate-900/70 border border-slate-800 hover:border-amber-500/40 rounded-3xl p-6 transition-all duration-300 flex flex-col justify-between space-y-4"
                  >
                    <div className="space-y-4">
                      {/* Photo & Country */}
                      <div className="flex items-start justify-between">
                        <img
                          src={winner.photoUrl}
                          alt={winner.winnerName}
                          className="w-16 h-16 rounded-2xl object-cover border-2 border-amber-400/40 shadow-lg"
                        />
                        <span className="px-3 py-1 rounded-full bg-slate-950 border border-slate-800 text-xs font-medium text-slate-300">
                          {winner.country}
                        </span>
                      </div>

                      <div>
                        <div className="text-[11px] font-bold uppercase tracking-wider text-amber-400 mb-1">
                          {winner.categoryName}
                        </div>
                        <h3 className="text-lg font-bold text-white group-hover:text-amber-400 transition-colors">
                          {winner.winnerName}
                        </h3>
                        <p className="text-xs font-medium text-slate-300">{winner.designation}</p>
                        <p className="text-xs text-slate-400">{winner.organization}</p>
                      </div>

                      <p className="text-xs text-slate-300 leading-relaxed border-t border-slate-800/80 pt-3">
                        {winner.achievement}
                      </p>
                    </div>

                    <div className="pt-2 flex items-center justify-between text-[11px] text-slate-400 border-t border-slate-800">
                      <span>CSCPO Certified Laureate</span>
                      <span className="text-amber-400 font-bold">{year}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          );
        })}

        {/* CTA Banner */}
        <div className="p-8 bg-gradient-to-r from-amber-600/20 via-slate-900 to-amber-950/20 border border-amber-500/30 rounded-3xl text-center space-y-4">
          <h3 className="text-xl font-bold text-white">Join the Ranks of South Asia&rsquo;s Supply Chain Elite</h3>
          <p className="text-xs text-slate-300 max-w-xl mx-auto">
            Submit your nomination or cast your verified vote for this year&rsquo;s finalists.
          </p>
          <div className="flex items-center justify-center space-x-3 pt-2">
            <Link
              href="/voting"
              className="px-6 py-2.5 rounded-xl bg-amber-500 text-slate-950 font-bold text-xs"
            >
              Public Voting Gallery
            </Link>
            <Link
              href="/nominate"
              className="px-6 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white font-semibold text-xs"
            >
              Submit Nomination
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
