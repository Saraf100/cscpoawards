"use client";

import React, { useState, useEffect } from "react";
import Link from "next/link";
import {
  Key,
  Shield,
  Copy,
  Check,
  ExternalLink,
  Globe,
  UserCheck,
  Code,
  FileText,
  Award,
  Vote,
  Send,
  Lock,
  ArrowRight,
  Database,
} from "lucide-react";

export default function AccessDirectoryPage() {
  const [copiedKey, setCopiedKey] = useState<string | null>(null);
  const [settings, setSettings] = useState<{ bannerTitle?: string; logoUrl?: string } | null>(null);

  useEffect(() => {
    fetch("/api/admin/settings")
      .then((res) => res.json())
      .then((data) => {
        if (data.success && data.data) {
          setSettings(data.data);
        }
      })
      .catch(() => {});
  }, []);

  const copyToClipboard = (text: string, keyName: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(keyName);
    setTimeout(() => setCopiedKey(null), 2500);
  };

  const portalLinks = [
    {
      name: "Awards Homepage",
      path: "/",
      desc: "Hero presentation, honored finalists, official sponsors & categories",
      role: "Public / Anyone",
    },
    {
      name: "Public Voting Gallery",
      path: "/voting",
      desc: "Verified voting cards, live search, and category-wise filtering",
      role: "Verified Voters",
    },
    {
      name: "Online Nomination Portal",
      path: "/nominate",
      desc: "Multi-field candidate submission form, draft saving & application tracking",
      role: "Open to Anyone",
    },
    {
      name: "Live Results & Transparency",
      path: "/results",
      desc: "Real-time vote counts, category distributions & cryptographic audit ledger",
      role: "Public / Audited",
    },
    {
      name: "Award Categories Explorer",
      path: "/categories",
      desc: "Comprehensive view of all supply chain & logistics competitive categories",
      role: "Public / Anyone",
    },
    {
      name: "Past Laureates Hall of Fame",
      path: "/winners",
      desc: "Historical recipients archive across South Asia",
      role: "Public / Anyone",
    },
    {
      name: "Organizer Admin Dashboard",
      path: "/admin",
      desc: "Jury approval queue, live fraud auditing, title & logo management, CSV exports",
      role: "Master Admin & Jury",
    },
    {
      name: "Developer Specifications (SRS)",
      path: "/srs",
      desc: "Complete Software Requirements Specification with DB schema & architecture",
      role: "Technical Team",
    },
    {
      name: "Website Iframe Embedding",
      path: "/voting?embed=true",
      desc: "Clean embeddable version for cscpo.org/cscpobdawards2026/",
      role: "CMS Embedding",
    },
  ];

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 py-10">
      <div className="container mx-auto px-4 max-w-5xl space-y-10">
        {/* Header */}
        <div className="text-center space-y-3">
          <div className="inline-flex items-center space-x-2 px-3.5 py-1 rounded-full bg-amber-500/10 border border-amber-500/20 text-amber-300 text-xs font-semibold">
            <Key className="w-3.5 h-3.5 text-amber-400" />
            <span>Official Access Directory & Credentials Hub</span>
          </div>
          <h1 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
            System Access Links & Credentials
          </h1>
          <p className="text-sm text-slate-400 max-w-2xl mx-auto">
            Comprehensive guide to all administrative access portals, evaluator credentials, public platform links,
            and voter test accounts for the CSCPO South Asian Leadership Awards platform.
          </p>
        </div>

        {/* 1. ADMINISTRATIVE ACCESS & CREDENTIALS */}
        <div className="space-y-4">
          <div className="flex items-center space-x-2 border-b border-slate-800 pb-2">
            <Shield className="w-5 h-5 text-amber-400" />
            <h2 className="text-lg font-bold text-white">1. Organizer & Admin Portal Credentials</h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Master Administrator */}
            <div className="p-6 bg-slate-900 border border-amber-500/40 rounded-3xl space-y-4 shadow-xl">
              <div className="flex items-center justify-between">
                <span className="px-3 py-1 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30 font-bold text-xs">
                  Master Administrator
                </span>
                <span className="text-xs text-emerald-400 font-semibold">Full Permissions</span>
              </div>

              <div className="space-y-2 font-mono text-xs">
                <div className="p-3 bg-slate-950 rounded-xl flex items-center justify-between border border-slate-800">
                  <div>
                    <span className="text-slate-500 text-[10px] block font-sans">Login Portal URL:</span>
                    <span className="text-white font-bold select-all">/admin</span>
                  </div>
                  <Link
                    href="/admin"
                    className="p-1.5 hover:bg-slate-800 rounded text-amber-400 flex items-center space-x-1 font-sans text-xs"
                  >
                    <span>Open</span>
                    <ExternalLink className="w-3.5 h-3.5" />
                  </Link>
                </div>

                <div className="p-3 bg-slate-950 rounded-xl flex items-center justify-between border border-slate-800">
                  <div>
                    <span className="text-slate-500 text-[10px] block font-sans">Login Name / Email:</span>
                    <span className="text-white font-bold select-all">admin@cscpo.org <span className="text-slate-400 font-normal font-sans">(or &quot;admin&quot;)</span></span>
                  </div>
                  <button
                    onClick={() => copyToClipboard("admin@cscpo.org", "adminEmail")}
                    className="p-1.5 hover:bg-slate-800 rounded text-amber-400"
                    title="Copy"
                  >
                    {copiedKey === "adminEmail" ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                  </button>
                </div>

                <div className="p-3 bg-slate-950 rounded-xl flex items-center justify-between border border-slate-800">
                  <div>
                    <span className="text-slate-500 text-[10px] block font-sans">Password:</span>
                    <span className="text-amber-300 font-bold select-all">cscpo@leadership#2026</span>
                  </div>
                  <button
                    onClick={() => copyToClipboard("cscpo@leadership#2026", "adminPass")}
                    className="p-1.5 hover:bg-slate-800 rounded text-amber-400"
                    title="Copy"
                  >
                    {copiedKey === "adminPass" ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <div className="text-xs text-slate-400 pt-1 leading-relaxed">
                <strong className="text-slate-300">Authority:</strong> Configure award title & tagline, upload official logos, sponsors & supporters, add new award categories, manage nomination approval queue, pause/open/close voting, and export CSV audit reports.
              </div>
            </div>

            {/* Jury & Screening Committee */}
            <div className="p-6 bg-slate-900 border border-emerald-500/40 rounded-3xl space-y-4 shadow-xl">
              <div className="flex items-center justify-between">
                <span className="px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-bold text-xs">
                  Jury Screening Officer
                </span>
                <span className="text-xs text-emerald-400 font-semibold">Evaluation & Approvals</span>
              </div>

              <div className="space-y-2 font-mono text-xs">
                <div className="p-3 bg-slate-950 rounded-xl flex items-center justify-between border border-slate-800">
                  <div>
                    <span className="text-slate-500 text-[10px] block font-sans">Login Portal URL:</span>
                    <span className="text-white font-bold select-all">/admin</span>
                  </div>
                  <Link
                    href="/admin"
                    className="p-1.5 hover:bg-slate-800 rounded text-emerald-400 flex items-center space-x-1 font-sans text-xs"
                  >
                    <span>Open</span>
                    <ExternalLink className="w-3.5 h-3.5" />
                  </Link>
                </div>

                <div className="p-3 bg-slate-950 rounded-xl flex items-center justify-between border border-slate-800">
                  <div>
                    <span className="text-slate-500 text-[10px] block font-sans">Login Name / Email:</span>
                    <span className="text-white font-bold select-all">jury@cscpo.org <span className="text-slate-400 font-normal font-sans">(or &quot;jury&quot;)</span></span>
                  </div>
                  <button
                    onClick={() => copyToClipboard("jury@cscpo.org", "juryEmail")}
                    className="p-1.5 hover:bg-slate-800 rounded text-emerald-400"
                    title="Copy"
                  >
                    {copiedKey === "juryEmail" ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                  </button>
                </div>

                <div className="p-3 bg-slate-950 rounded-xl flex items-center justify-between border border-slate-800">
                  <div>
                    <span className="text-slate-500 text-[10px] block font-sans">Password:</span>
                    <span className="text-emerald-300 font-bold select-all">jury@review#2026</span>
                  </div>
                  <button
                    onClick={() => copyToClipboard("jury@review#2026", "juryPass")}
                    className="p-1.5 hover:bg-slate-800 rounded text-emerald-400"
                    title="Copy"
                  >
                    {copiedKey === "juryPass" ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <div className="text-xs text-slate-400 pt-1 leading-relaxed">
                <strong className="text-slate-300">Authority:</strong> Screen submitted applicant dossiers, review supporting certificates, approve candidates to publish their voting card, or reject with reason.
              </div>
            </div>
          </div>
        </div>

        {/* 2. COMPLETE PLATFORM DIRECTORY */}
        <div className="space-y-4">
          <div className="flex items-center space-x-2 border-b border-slate-800 pb-2">
            <Globe className="w-5 h-5 text-blue-400" />
            <h2 className="text-lg font-bold text-white">2. All Website Routes & Direct Links</h2>
          </div>

          <div className="bg-slate-900 border border-slate-800 rounded-3xl overflow-hidden shadow-xl">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-950 text-slate-400 uppercase tracking-wider text-[10px]">
                  <tr>
                    <th className="p-4">Page / Function</th>
                    <th className="p-4">Path URL</th>
                    <th className="p-4">Access Level</th>
                    <th className="p-4 text-right">Quick Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/80">
                  {portalLinks.map((p, idx) => (
                    <tr key={idx} className="hover:bg-slate-950/60 transition">
                      <td className="p-4">
                        <div className="font-bold text-white text-sm">{p.name}</div>
                        <div className="text-[11px] text-slate-400">{p.desc}</div>
                      </td>
                      <td className="p-4 font-mono text-amber-400 text-xs font-semibold select-all">
                        {p.path}
                      </td>
                      <td className="p-4">
                        <span className="px-2.5 py-0.5 rounded-full bg-slate-950 border border-slate-700 text-slate-300 text-[10px] font-medium">
                          {p.role}
                        </span>
                      </td>
                      <td className="p-4 text-right space-x-2">
                        <button
                          onClick={() => {
                            const full = typeof window !== "undefined" ? `${window.location.origin}${p.path}` : p.path;
                            copyToClipboard(full, `link-${idx}`);
                          }}
                          className="p-1.5 hover:bg-slate-800 rounded text-slate-400 hover:text-white transition"
                          title="Copy Full URL"
                        >
                          {copiedKey === `link-${idx}` ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                        </button>
                        <Link
                          href={p.path}
                          target="_blank"
                          className="p-1.5 hover:bg-slate-800 rounded text-slate-400 hover:text-amber-400 inline-block transition"
                          title="Open Page"
                        >
                          <ExternalLink className="w-3.5 h-3.5" />
                        </Link>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* 3. VOTER AUTHENTICATION PROVIDER SETUP */}
        <div className="space-y-4">
          <div className="flex items-center space-x-2 border-b border-slate-800 pb-2">
            <UserCheck className="w-5 h-5 text-emerald-400" />
            <h2 className="text-lg font-bold text-white">3. Verified Voter Authentication Setup</h2>
          </div>

          <div className="p-6 bg-slate-900 border border-slate-800 rounded-3xl space-y-4 text-xs">
            <p className="text-slate-300 leading-relaxed">
              Voting now requires a server-verified session. Google and Facebook use their real OAuth consent screens; email OTP is stored, rate-limited, and verified on the server. Social account login is not proof of a person’s real-world identity.
            </p>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
              <div className="p-4 bg-slate-950 rounded-2xl border border-blue-500/30 space-y-2">
                <div className="font-bold text-white">Google OAuth</div>
                <p className="text-[11px] text-slate-400">
                  Configure <code>GOOGLE_CLIENT_ID</code> and <code>GOOGLE_CLIENT_SECRET</code> on the Node host.
                </p>
                <div className="text-[10px] text-blue-300 break-all font-mono">
                  Redirect: /api/auth/oauth/google/callback
                </div>
              </div>

              <div className="p-4 bg-slate-950 rounded-2xl border border-indigo-500/30 space-y-2">
                <div className="font-bold text-white">Facebook OAuth</div>
                <p className="text-[11px] text-slate-400">
                  Configure <code>FACEBOOK_APP_ID</code> and <code>FACEBOOK_APP_SECRET</code> on the Node host. Request the <code>email</code> and <code>public_profile</code> scopes.
                </p>
                <div className="text-[10px] text-indigo-300 break-all font-mono">
                  Redirect: /api/auth/oauth/facebook/callback
                </div>
              </div>

              <div className="p-4 bg-slate-950 rounded-2xl border border-emerald-500/30 space-y-2">
                <div className="font-bold text-white">Email OTP</div>
                <p className="text-[11px] text-slate-400">
                  Configure <code>RESEND_API_KEY</code> and a verified <code>RESEND_FROM_EMAIL</code>. Code expires in 10 minutes; attempts and resend frequency are limited.
                </p>
                <div className="text-[10px] text-emerald-300 font-mono">No client-generated or exposed OTPs</div>
              </div>
            </div>

            <div className="p-3 bg-amber-950/30 border border-amber-500/30 rounded-xl text-[11px] text-amber-100">
              Provider credentials are intentionally not hard-coded. If OAuth or email delivery settings are absent, the sign-in screen now reports the exact provider setup needed instead of silently creating a fake voter.
            </div>
          </div>
        </div>

        {/* 4. IFRAME EMBEDDING IN CSCPO.ORG */}
        <div className="space-y-4">
          <div className="flex items-center space-x-2 border-b border-slate-800 pb-2">
            <Code className="w-5 h-5 text-amber-400" />
            <h2 className="text-lg font-bold text-white">4. Website Embed Snippet for cscpo.org/cscpobdawards2026/</h2>
          </div>

          <div className="p-6 bg-slate-900 border border-slate-800 rounded-3xl space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs text-slate-400">
                Paste this into WordPress, Drupal, or any CMS HTML block on the main event page:
              </span>
              <button
                onClick={() => {
                  const snippet = `<iframe src="${typeof window !== "undefined" ? window.location.origin : "https://cscpo.org"}/voting?embed=true" width="100%" height="900" frameborder="0" style="border:none; border-radius:16px; overflow:hidden;" title="CSCPO South Asian Leadership Awards - Public Voting"></iframe>`;
                  copyToClipboard(snippet, "iframeSnippet");
                }}
                className="px-3.5 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs flex items-center space-x-1.5 cursor-pointer"
              >
                {copiedKey === "iframeSnippet" ? <Check className="w-3.5 h-3.5 text-slate-950" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedKey === "iframeSnippet" ? "Copied!" : "Copy Embed Code"}</span>
              </button>
            </div>

            <pre className="p-3.5 bg-slate-950 rounded-xl text-amber-300 font-mono text-xs overflow-x-auto border border-slate-800 select-all">
{`<iframe 
  src="${typeof window !== "undefined" ? window.location.origin : "https://cscpo.org"}/voting?embed=true" 
  width="100%" 
  height="900" 
  frameborder="0" 
  style="border:none; border-radius:16px; overflow:hidden;"
  title="CSCPO South Asian Leadership Awards - Public Voting">
</iframe>`}
            </pre>
          </div>
        </div>
      </div>
    </div>
  );
}
