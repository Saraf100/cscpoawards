"use client";

import React, { useState, useEffect, useMemo } from "react";
import NomineeCard from "@/components/NomineeCard";
import { Nominee, Category } from "@/lib/types";
import {
  Search,
  Filter,
  Award,
  Vote,
  Sparkles,
  CheckCircle,
  TrendingUp,
  Globe,
  RefreshCw,
  ExternalLink,
  Code,
} from "lucide-react";

export default function VotingGalleryPage() {
  const [nomineesList, setNomineesList] = useState<Nominee[]>([]);
  const [categoriesList, setCategoriesList] = useState<Category[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<string>("all");
  const [selectedCountry, setSelectedCountry] = useState<string>("all");
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [isEmbed, setIsEmbed] = useState<boolean>(false);
  const [authNotice, setAuthNotice] = useState<string | null>(null);
  const [authNoticeIsError, setAuthNoticeIsError] = useState(false);
  const [sortBy, setSortBy] = useState<string>("votes"); // votes, name, recent
  const [isLoading, setIsLoading] = useState(true);
  const [votingSettings, setVotingSettings] = useState<{
    votingStatus: string;
    votingEndDate: string;
    showPublicRankings: boolean;
  } | null>(null);

  useEffect(() => {
    if (typeof window !== "undefined") {
      const sp = new URLSearchParams(window.location.search);
      const cat = sp.get("category");
      if (cat) setSelectedCategory(cat);
      const s = sp.get("search");
      if (s) setSearchQuery(s);
      if (sp.get("embed") === "true") setIsEmbed(true);
      const authError = sp.get("authError");
      if (authError) {
        const messages: Record<string, string> = {
          google_not_configured: "Google sign-in is not configured by the organizer yet. Use email OTP or contact CSCPO.",
          facebook_not_configured: "Facebook sign-in is not configured by the organizer yet. Use email OTP or contact CSCPO.",
          social_login_cancelled: "Sign-in was cancelled. You can choose another authentication method.",
          facebook_email_unavailable: "Facebook did not provide an email address. Please use email OTP or another account.",
          voter_suspended: "This voter account is suspended. Please contact CSCPO.",
        };
        setAuthNotice(messages[authError] || "Social sign-in could not be completed. Please try another method.");
        setAuthNoticeIsError(true);
      } else if (sp.get("auth") === "success") {
        setAuthNotice("Account sign-in succeeded. Select a nominee and click Vote Now to cast your vote.");
        setAuthNoticeIsError(false);
      }
    }
  }, []);

  const fetchNominees = async () => {
    setIsLoading(true);
    try {
      const [nomRes, catRes, statsRes] = await Promise.all([
        fetch("/api/nominees?status=APPROVED&sort=" + sortBy),
        fetch("/api/categories"),
        fetch("/api/votes/stats"),
      ]);

      const nomData = await nomRes.json();
      const catData = await catRes.json();
      const statsData = await statsRes.json();

      if (nomData.success) {
        setNomineesList(nomData.data);
      }
      if (catData.success) {
        setCategoriesList(catData.data);
      }
      if (statsData.success) {
        setVotingSettings({
          votingStatus: statsData.data.votingStatus,
          votingEndDate: statsData.data.votingEndDate,
          showPublicRankings: statsData.data.showPublicRankings,
        });
      }
    } catch (error) {
      console.error("Error fetching gallery data:", error);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchNominees();
  }, [sortBy]);

  // Extract unique countries
  const countries = useMemo(() => {
    const set = new Set<string>();
    nomineesList.forEach((n) => {
      if (n.country) set.add(n.country);
    });
    return Array.from(set).sort();
  }, [nomineesList]);

  // Filtered nominees
  const filteredNominees = useMemo(() => {
    return nomineesList.filter((n) => {
      // Category filter
      if (selectedCategory !== "all") {
        const cat = categoriesList.find((c) => c.slug === selectedCategory);
        if (cat && n.categoryId !== cat.id) return false;
      }

      // Country filter
      if (selectedCountry !== "all") {
        if (n.country.toLowerCase() !== selectedCountry.toLowerCase()) return false;
      }

      // Search filter
      if (searchQuery.trim() !== "") {
        const q = searchQuery.toLowerCase().trim();
        const matchesName = n.name.toLowerCase().includes(q);
        const matchesDesig = n.designation.toLowerCase().includes(q);
        const matchesOrg = n.organization.toLowerCase().includes(q);
        const matchesCat = (n.categoryName || "").toLowerCase().includes(q);
        if (!matchesName && !matchesDesig && !matchesOrg && !matchesCat) {
          return false;
        }
      }

      return true;
    });
  }, [nomineesList, selectedCategory, selectedCountry, searchQuery, categoriesList]);

  const handleVoteSuccess = (nomineeId: number, newCount: number) => {
    setNomineesList((prev) =>
      prev.map((nom) => (nom.id === nomineeId ? { ...nom, voteCount: newCount } : nom))
    );
  };

  return (
    <div className={`min-h-screen bg-slate-950 text-slate-100 ${isEmbed ? "p-3" : "py-8"}`}>
      <div className="container mx-auto px-4 space-y-8">
        {authNotice && (
          <div className={`p-4 rounded-xl border text-sm flex items-start space-x-2 ${authNoticeIsError ? "bg-red-950/50 border-red-500/40 text-red-200" : "bg-emerald-950/40 border-emerald-500/40 text-emerald-200"}`}>
            <span>{authNotice}</span>
            <button onClick={() => setAuthNotice(null)} className="ml-auto text-xs underline">Dismiss</button>
          </div>
        )}

        {/* Gallery Header */}
        {!isEmbed && (
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 pb-6 border-b border-slate-800">
            <div className="space-y-2">
              <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/20 text-amber-300 text-xs font-semibold">
                <Vote className="w-3.5 h-3.5 text-amber-400" />
                <span>Verified Public Voting Portal</span>
              </div>
              <h1 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
                Nominee Voting Gallery
              </h1>
              <p className="text-sm text-slate-400 max-w-2xl">
                Cast your verified vote for outstanding supply chain, procurement, and logistics leaders across South
                Asia. Every vote is encrypted and audited in the CSCPO transparency system.
              </p>
            </div>

            <div className="flex flex-col items-start md:items-end space-y-2">
              <div className="text-[11px] text-slate-400 flex items-center space-x-1">
                <CheckCircle className="w-3.5 h-3.5 text-emerald-400" />
                <span>Showing {filteredNominees.length} approved candidates</span>
              </div>
            </div>
          </div>
        )}

        {/* Filters & Search Toolbar */}
        <div className="bg-slate-900/90 border border-slate-800 p-4 rounded-2xl space-y-4 shadow-xl backdrop-blur-md">
          {/* Top Search & Dropdowns Row */}
          <div className="grid grid-cols-1 md:grid-cols-12 gap-3">
            {/* Search Input */}
            <div className="md:col-span-5 relative">
              <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Search nominee by name, company, or title..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700/80 rounded-xl pl-10 pr-4 py-2.5 text-sm text-white focus:outline-none focus:border-amber-500 transition"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery("")}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-slate-400 hover:text-white"
                >
                  Clear
                </button>
              )}
            </div>

            {/* Country Selector */}
            <div className="md:col-span-3">
              <select
                value={selectedCountry}
                onChange={(e) => setSelectedCountry(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700/80 rounded-xl px-3.5 py-2.5 text-sm text-slate-200 focus:outline-none focus:border-amber-500 transition"
              >
                <option value="all">🌍 All South Asian Countries</option>
                {countries.map((c) => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))}
              </select>
            </div>

            {/* Sort Dropdown */}
            <div className="md:col-span-3">
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700/80 rounded-xl px-3.5 py-2.5 text-sm text-slate-200 focus:outline-none focus:border-amber-500 transition"
              >
                <option value="votes">🔥 Most Votes First</option>
                <option value="name">🔤 Name (A-Z)</option>
                <option value="recent">⏱️ Recently Added</option>
              </select>
            </div>

            {/* Refresh Button */}
            <div className="md:col-span-1 flex items-center justify-center">
              <button
                onClick={fetchNominees}
                title="Refresh Standings"
                className="w-full h-full min-h-[42px] bg-slate-800 hover:bg-slate-700 rounded-xl flex items-center justify-center text-slate-300 hover:text-white transition"
              >
                <RefreshCw className={`w-4 h-4 ${isLoading ? "animate-spin" : ""}`} />
              </button>
            </div>
          </div>

          {/* Category Filter Pills (Horizontal scrollable) */}
          <div className="pt-2 border-t border-slate-800/80">
            <div className="flex items-center space-x-2 overflow-x-auto pb-1 no-scrollbar text-xs">
              <button
                onClick={() => setSelectedCategory("all")}
                className={`px-3.5 py-1.5 rounded-xl font-semibold whitespace-nowrap transition cursor-pointer ${
                  selectedCategory === "all"
                    ? "bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20"
                    : "bg-slate-950 text-slate-400 hover:text-white hover:bg-slate-800 border border-slate-800"
                }`}
              >
                All Categories ({nomineesList.length})
              </button>

              {categoriesList.map((cat) => {
                const isSelected = selectedCategory === cat.slug;
                return (
                  <button
                    key={cat.id}
                    onClick={() => setSelectedCategory(cat.slug)}
                    className={`px-3.5 py-1.5 rounded-xl font-semibold whitespace-nowrap transition cursor-pointer ${
                      isSelected
                        ? "bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20"
                        : "bg-slate-950 text-slate-400 hover:text-white hover:bg-slate-800 border border-slate-800"
                    }`}
                  >
                    {cat.name}
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {/* Results Counter & Active Filter Badge */}
        <div className="flex items-center justify-between text-xs text-slate-400 px-1">
          <div>
            Showing <span className="text-white font-bold">{filteredNominees.length}</span> nominees
            {selectedCategory !== "all" && (
              <span>
                {" "}
                in &ldquo;
                <strong className="text-amber-400">
                  {categoriesList.find((c) => c.slug === selectedCategory)?.name}
                </strong>
                &rdquo;
              </span>
            )}
            {selectedCountry !== "all" && (
              <span>
                {" "}
                from <strong className="text-amber-400">{selectedCountry}</strong>
              </span>
            )}
          </div>

          {(selectedCategory !== "all" || selectedCountry !== "all" || searchQuery) && (
            <button
              onClick={() => {
                setSelectedCategory("all");
                setSelectedCountry("all");
                setSearchQuery("");
              }}
              className="text-amber-400 hover:underline cursor-pointer"
            >
              Reset all filters
            </button>
          )}
        </div>

        {/* Nominee Cards Grid */}
        {isLoading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 py-12">
            {[1, 2, 3, 4, 5, 6, 7, 8].map((i) => (
              <div
                key={i}
                className="h-96 rounded-2xl bg-slate-900/50 border border-slate-800 animate-pulse p-4 space-y-4"
              >
                <div className="h-48 bg-slate-800 rounded-xl" />
                <div className="h-4 bg-slate-800 rounded w-3/4" />
                <div className="h-3 bg-slate-800 rounded w-1/2" />
                <div className="h-10 bg-slate-800 rounded-xl mt-4" />
              </div>
            ))}
          </div>
        ) : filteredNominees.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {filteredNominees.map((nominee) => (
              <NomineeCard
                key={nominee.id}
                nominee={nominee}
                onVoteSuccess={handleVoteSuccess}
              />
            ))}
          </div>
        ) : (
          <div className="text-center py-20 bg-slate-900/40 border border-slate-800 rounded-2xl p-8 space-y-4">
            <div className="w-16 h-16 rounded-full bg-slate-800 flex items-center justify-center mx-auto text-slate-500">
              <Search className="w-8 h-8" />
            </div>
            <h3 className="text-lg font-bold text-white">No Nominees Found</h3>
            <p className="text-xs text-slate-400 max-w-md mx-auto">
              No approved candidates matched your search criteria or category filter. Try clearing the search query or
              selecting another country.
            </p>
            <button
              onClick={() => {
                setSelectedCategory("all");
                setSelectedCountry("all");
                setSearchQuery("");
              }}
              className="px-4 py-2 bg-amber-500 text-slate-950 font-bold rounded-xl text-xs"
            >
              Show All Nominees
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
