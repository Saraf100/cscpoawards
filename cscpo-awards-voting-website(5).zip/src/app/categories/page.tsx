import Link from "next/link";
import { db } from "@/db";
import { categories, nominees } from "@/db/schema";
import { eq, asc, desc } from "drizzle-orm";
import { ensureSeeded } from "@/lib/seed";
import { Award, Vote, ArrowRight, Sparkles, ChevronRight, Users } from "lucide-react";

export const dynamic = "force-dynamic";

export default async function CategoriesPage() {
  await ensureSeeded();

  const allCategories = await db
    .select()
    .from(categories)
    .where(eq(categories.isActive, true))
    .orderBy(asc(categories.displayOrder));

  const allApprovedNominees = await db
    .select()
    .from(nominees)
    .where(eq(nominees.status, "APPROVED"))
    .orderBy(desc(nominees.voteCount));

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 py-10">
      <div className="container mx-auto px-4 max-w-6xl space-y-10">
        {/* Header */}
        <div className="text-center space-y-3 max-w-2xl mx-auto">
          <div className="inline-flex items-center space-x-2 px-3.5 py-1 rounded-full bg-amber-500/10 border border-amber-500/20 text-amber-300 text-xs font-semibold">
            <Award className="w-3.5 h-3.5 text-amber-400" />
            <span>Award Categories Explorer</span>
          </div>
          <h1 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
            Award Categories & Disciplines
          </h1>
          <p className="text-sm text-slate-400">
            Explore the specialized competitive categories honoring excellence, digital transformation, diversity, and
            operational resilience in South Asian supply chain and logistics.
          </p>
        </div>

        {/* Categories Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {allCategories.map((cat) => {
            const catNominees = allApprovedNominees.filter((n) => n.categoryId === cat.id);
            const totalVotes = catNominees.reduce((acc, curr) => acc + (curr.voteCount || 0), 0);

            return (
              <div
                key={cat.id}
                className="group bg-slate-900/70 border border-slate-800 hover:border-amber-500/40 rounded-3xl p-6 transition-all duration-300 flex flex-col justify-between space-y-5"
              >
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="w-11 h-11 rounded-2xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400 group-hover:scale-105 transition-transform">
                      <Award className="w-6 h-6" />
                    </div>
                    <span className="text-xs font-mono font-bold text-amber-400/90 bg-slate-950 px-2.5 py-1 rounded-full border border-slate-800">
                      #{totalVotes.toLocaleString()} votes
                    </span>
                  </div>

                  <div>
                    <h3 className="text-lg font-bold text-white group-hover:text-amber-400 transition-colors">
                      {cat.name}
                    </h3>
                    {cat.nameBn && (
                      <p className="text-xs text-amber-400/80 font-bangla font-medium mt-0.5">
                        {cat.nameBn}
                      </p>
                    )}
                  </div>

                  <p className="text-xs text-slate-400 leading-relaxed">
                    {cat.description}
                  </p>

                  <div className="flex items-center space-x-2 text-xs text-slate-400 pt-1">
                    <Users className="w-3.5 h-3.5 text-slate-500" />
                    <span>{catNominees.length} Approved Nominees</span>
                  </div>
                </div>

                <div className="pt-3 border-t border-slate-800/80 grid grid-cols-2 gap-2">
                  <Link
                    href={`/voting?category=${cat.slug}`}
                    className="py-2.5 px-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold text-center transition flex items-center justify-center space-x-1"
                  >
                    <Vote className="w-3.5 h-3.5" />
                    <span>Vote Now</span>
                  </Link>

                  <Link
                    href="/nominate"
                    className="py-2.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold text-center transition flex items-center justify-center space-x-1"
                  >
                    <span>Nominate</span>
                    <ChevronRight className="w-3.5 h-3.5" />
                  </Link>
                </div>
              </div>
            );
          })}
        </div>

        {/* Bottom Banner */}
        <div className="p-8 bg-slate-900/40 border border-slate-800 rounded-3xl flex flex-col sm:flex-row items-center justify-between gap-4">
          <div>
            <h4 className="text-base font-bold text-white">Have a suggestion for a new award category?</h4>
            <p className="text-xs text-slate-400 mt-0.5">
              Contact the CSCPO Awards Secretariat to submit proposals for future South Asian editions.
            </p>
          </div>
          <Link
            href="/nominate"
            className="px-6 py-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold whitespace-nowrap"
          >
            Submit a Nomination
          </Link>
        </div>
      </div>
    </div>
  );
}
