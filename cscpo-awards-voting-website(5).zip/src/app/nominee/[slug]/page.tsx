"use client";

import React, { useState, useEffect, use } from "react";
import Link from "next/link";
import { notFound } from "next/navigation";
import { Nominee } from "@/lib/types";
import VotingModal from "@/components/VotingModal";
import ShareModal from "@/components/ShareModal";
import {
  Award,
  Vote,
  Share2,
  CheckCircle,
  ExternalLink,
  Globe,
  FileText,
  ChevronLeft,
  Calendar,
  Building,
  User,
  ShieldCheck,
  TrendingUp,
  Download,
  QrCode,
  ArrowRight,
} from "lucide-react";

export default function NomineeProfilePage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const resolvedParams = use(params);
  const slug = resolvedParams.slug;

  const [nominee, setNominee] = useState<Nominee | null>(null);
  const [totalCategoryVotes, setTotalCategoryVotes] = useState<number>(0);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const [isVotingOpen, setIsVotingOpen] = useState(false);
  const [isShareOpen, setIsShareOpen] = useState(false);

  useEffect(() => {
    async function loadNominee() {
      try {
        setIsLoading(true);
        const res = await fetch(`/api/nominees/${slug}`);
        const data = await res.json();
        if (!res.ok || !data.success || !data.data) {
          setError("Nominee profile not found.");
          return;
        }
        setNominee(data.data);
        setTotalCategoryVotes(data.data.totalCategoryVotes || 0);
      } catch (err) {
        console.error(err);
        setError("Failed to load nominee details.");
      } finally {
        setIsLoading(false);
      }
    }
    loadNominee();
  }, [slug]);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-slate-950 text-slate-100 flex items-center justify-center">
        <div className="flex flex-col items-center space-y-3">
          <div className="w-10 h-10 border-4 border-amber-500 border-t-transparent rounded-full animate-spin" />
          <p className="text-xs text-slate-400">Loading Nominee Dossier...</p>
        </div>
      </div>
    );
  }

  if (error || !nominee) {
    return (
      <div className="min-h-screen bg-slate-950 text-slate-100 flex items-center justify-center p-4">
        <div className="bg-slate-900 border border-slate-800 p-8 rounded-2xl max-w-md text-center space-y-4">
          <h2 className="text-xl font-bold text-white">Nominee Not Found</h2>
          <p className="text-xs text-slate-400">
            The profile you are seeking may not have been approved yet or has an invalid URL.
          </p>
          <Link
            href="/voting"
            className="inline-block px-5 py-2.5 rounded-xl bg-amber-500 text-slate-950 font-bold text-xs"
          >
            Back to Public Voting
          </Link>
        </div>
      </div>
    );
  }

  const handleVoteSuccess = (id: number, newCount: number) => {
    setNominee((prev) => (prev ? { ...prev, voteCount: newCount } : null));
  };

  const supportingDocs = Array.isArray(nominee.supportingDocuments)
    ? (nominee.supportingDocuments as Array<{ title: string; url: string }>)
    : [];

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 py-8">
      <div className="container mx-auto px-4 max-w-6xl space-y-8">
        {/* Breadcrumb Navigation */}
        <div className="flex items-center space-x-2 text-xs text-slate-400">
          <Link href="/" className="hover:text-amber-400 transition">
            Home
          </Link>
          <span>/</span>
          <Link href="/voting" className="hover:text-amber-400 transition">
            Voting Gallery
          </Link>
          <span>/</span>
          <span className="text-slate-200 font-medium truncate">{nominee.name}</span>
        </div>

        {/* TOP HERO PROFILE HEADER */}
        <div className="relative bg-gradient-to-br from-slate-900 via-slate-900/90 to-amber-950/20 border border-slate-800 rounded-3xl p-6 sm:p-10 shadow-2xl overflow-hidden">
          {/* Subtle glow */}
          <div className="absolute top-0 right-0 w-96 h-96 bg-amber-500/10 blur-[100px] pointer-events-none rounded-full" />

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center relative z-10">
            {/* Left Photo */}
            <div className="lg:col-span-4 flex flex-col items-center">
              <div className="relative w-56 h-56 sm:w-64 sm:h-64 rounded-2xl overflow-hidden border-2 border-amber-400/50 shadow-2xl shadow-amber-500/10 group">
                <img
                  src={nominee.photoUrl}
                  alt={nominee.name}
                  className="w-full h-full object-cover object-top"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-slate-950/10 to-transparent" />
                <div className="absolute bottom-2 left-2 right-2 flex flex-col items-center gap-1.5 text-center">
                  <span className="inline-flex items-center space-x-1 px-3 py-1 rounded-full bg-slate-950/90 border border-emerald-500/40 text-[11px] font-bold text-emerald-400 shadow">
                    <CheckCircle className="w-3.5 h-3.5" />
                    <span>CSCPO Verified Finalist</span>
                  </span>
                  <div className="w-full max-w-[210px] h-11 rounded-md bg-transparent px-1.5 py-0.5 flex items-center justify-center">
                    <img
                      src="/images/chartered-supply-chain-professionals.png"
                      alt="Chartered Supply Chain Professionals Organization"
                      className="w-full h-full object-contain"
                    />
                  </div>
                </div>
              </div>

              {/* Reference ID */}
              <div className="mt-3 text-center">
                <span className="font-mono text-xs text-slate-400 tracking-wider">
                  Ref: <strong className="text-amber-400">{nominee.refNumber}</strong>
                </span>
              </div>
            </div>

            {/* Right Details */}
            <div className="lg:col-span-8 space-y-5 text-center lg:text-left">
              <div className="space-y-2">
                <div className="inline-flex items-center space-x-2 px-3.5 py-1 rounded-full bg-amber-500/10 border border-amber-500/20 text-amber-300 text-xs font-semibold">
                  <Award className="w-3.5 h-3.5 text-amber-400" />
                  <span>Category: {nominee.categoryName || "South Asian Supply Chain Leadership"}</span>
                </div>

                <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-white tracking-tight">
                  {nominee.name}
                </h1>

                <p className="text-base sm:text-lg text-slate-300 font-medium">
                  {nominee.designation}
                </p>

                <p className="text-sm text-slate-400 flex items-center justify-center lg:justify-start space-x-2">
                  <Building className="w-4 h-4 text-amber-400" />
                  <span>{nominee.organization}</span>
                  <span>·</span>
                  <span>{nominee.country}</span>
                </p>
              </div>

              {/* Live Votes Ribbon & Standings */}
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 max-w-lg mx-auto lg:mx-0">
                <div className="p-3 bg-slate-950/80 border border-slate-800 rounded-2xl text-center">
                  <div className="text-2xl font-extrabold text-amber-400">
                    # {nominee.voteCount.toLocaleString()}
                  </div>
                  <div className="text-[10px] uppercase font-bold tracking-wider text-slate-400 mt-0.5">
                    Total Live Votes
                  </div>
                </div>

                <div className="p-3 bg-slate-950/80 border border-slate-800 rounded-2xl text-center flex flex-col justify-center">
                  <div className="text-xl font-extrabold text-emerald-400 flex items-center justify-center space-x-1">
                    <span className="text-amber-400">★</span>
                    <span>Finalist</span>
                  </div>
                  <div className="text-[10px] uppercase font-bold tracking-wider text-slate-400 mt-0.5">
                    Honored Nominee
                  </div>
                </div>

                <div className="p-3 bg-slate-950/80 border border-slate-800 rounded-2xl text-center col-span-2 sm:col-span-1">
                  <div className="text-2xl font-extrabold text-emerald-400">
                    {nominee.experienceYears}+ Yrs
                  </div>
                  <div className="text-[10px] uppercase font-bold tracking-wider text-slate-400 mt-0.5">
                    Industry Exp.
                  </div>
                </div>
              </div>

              {/* Primary Call to Action Buttons */}
              <div className="flex flex-wrap items-center justify-center lg:justify-start gap-3 pt-2">
                <button
                  onClick={() => setIsVotingOpen(true)}
                  className="px-8 py-3.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-bold text-sm tracking-wide shadow-xl shadow-amber-500/20 transition flex items-center space-x-2 cursor-pointer transform hover:-translate-y-0.5"
                >
                  <Vote className="w-4 h-4" />
                  <span>Vote for {nominee.name.split(" ")[0]}</span>
                </button>

                <button
                  onClick={() => setIsShareOpen(true)}
                  className="px-5 py-3.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-200 font-semibold text-sm transition flex items-center space-x-2 cursor-pointer"
                >
                  <Share2 className="w-4 h-4 text-amber-400" />
                  <span>Share Profile</span>
                </button>

                {nominee.linkedinUrl && (
                  <a
                    href={nominee.linkedinUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="p-3.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-300 hover:text-white transition flex items-center justify-center"
                    title="LinkedIn Profile"
                  >
                    <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24">
                      <path d="M19 3a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h14m-.5 15.5v-5.3a3.26 3.26 0 0 0-3.26-3.26c-.85 0-1.84.52-2.28 1.3v-1.11h-2.79v8.37h2.79v-4.93c0-.77.62-1.4 1.39-1.4a1.4 1.4 0 0 1 1.4 1.4v4.93h2.75M6.46 10.9h2.77v8.37H6.46v-8.37M7.85 6.64a1.6 1.6 0 1 0 0 3.2 1.6 1.6 0 0 0 0-3.2" />
                    </svg>
                  </a>
                )}

                {nominee.websiteUrl && (
                  <a
                    href={nominee.websiteUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="p-3.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-300 hover:text-white transition"
                    title="Company Website"
                  >
                    <Globe className="w-4 h-4" />
                  </a>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* DETAILED PROFILE BODY */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* Left Main Bio & Achievements */}
          <div className="lg:col-span-8 space-y-8">
            {/* Executive Summary */}
            <div className="bg-slate-900/60 border border-slate-800 p-6 sm:p-8 rounded-3xl space-y-3">
              <h3 className="text-lg font-bold text-white flex items-center space-x-2">
                <span className="w-2 h-2 rounded-full bg-amber-400" />
                <span>Executive Achievement Summary</span>
              </h3>
              <p className="text-sm text-slate-300 leading-relaxed">
                {nominee.achievementSummary}
              </p>
            </div>

            {/* Why Nominate Justification */}
            <div className="bg-slate-900/60 border border-slate-800 p-6 sm:p-8 rounded-3xl space-y-3">
              <h3 className="text-lg font-bold text-white flex items-center space-x-2">
                <Award className="w-5 h-5 text-amber-400" />
                <span>Why This Nominee Deserves the Award</span>
              </h3>
              <p className="text-sm text-slate-300 leading-relaxed whitespace-pre-line">
                {nominee.whyNominate}
              </p>
            </div>

            {/* Professional Biography */}
            {nominee.bio && (
              <div className="bg-slate-900/60 border border-slate-800 p-6 sm:p-8 rounded-3xl space-y-3">
                <h3 className="text-lg font-bold text-white flex items-center space-x-2">
                  <User className="w-5 h-5 text-amber-400" />
                  <span>Professional Biography</span>
                </h3>
                <p className="text-sm text-slate-300 leading-relaxed whitespace-pre-line">
                  {nominee.bio}
                </p>
              </div>
            )}

            {/* Major Contributions to Supply Chain Management */}
            {nominee.supplyChainContributions && (
              <div className="bg-slate-900/60 border border-slate-800 p-6 sm:p-8 rounded-3xl space-y-3">
                <h3 className="text-lg font-bold text-white flex items-center space-x-2">
                  <TrendingUp className="w-5 h-5 text-emerald-400" />
                  <span>Key Contributions to South Asian Supply Chains</span>
                </h3>
                <p className="text-sm text-slate-300 leading-relaxed whitespace-pre-line">
                  {nominee.supplyChainContributions}
                </p>
              </div>
            )}

            {/* Career History */}
            {nominee.careerHistory && (
              <div className="bg-slate-900/60 border border-slate-800 p-6 sm:p-8 rounded-3xl space-y-3">
                <h3 className="text-lg font-bold text-white flex items-center space-x-2">
                  <Calendar className="w-5 h-5 text-amber-400" />
                  <span>Career Track & Leadership History</span>
                </h3>
                <p className="text-sm text-slate-300 leading-relaxed whitespace-pre-line">
                  {nominee.careerHistory}
                </p>
              </div>
            )}

            {/* Supporting Documents / Evidence */}
            {supportingDocs.length > 0 && (
              <div className="bg-slate-900/60 border border-slate-800 p-6 sm:p-8 rounded-3xl space-y-4">
                <h3 className="text-lg font-bold text-white flex items-center space-x-2">
                  <FileText className="w-5 h-5 text-amber-400" />
                  <span>Verified Supporting Documents & Evidence</span>
                </h3>
                <div className="space-y-2">
                  {supportingDocs.map((doc, idx) => (
                    <div
                      key={idx}
                      className="p-3.5 bg-slate-950 border border-slate-800 rounded-xl flex items-center justify-between text-xs"
                    >
                      <div className="flex items-center space-x-2.5">
                        <FileText className="w-4 h-4 text-amber-400" />
                        <span className="text-slate-200 font-medium">{doc.title}</span>
                      </div>
                      <span className="text-[11px] text-emerald-400 font-semibold flex items-center space-x-1">
                        <ShieldCheck className="w-3.5 h-3.5" />
                        <span>Jury Verified</span>
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Right Sidebar: Campaign Tools & Share */}
          <div className="lg:col-span-4 space-y-6">
            {/* Quick Voting Sticky Card */}
            <div className="bg-gradient-to-b from-slate-900 to-slate-950 border border-amber-500/30 p-6 rounded-3xl space-y-4 shadow-xl">
              <div className="text-center space-y-1">
                <span className="text-[10px] uppercase font-bold tracking-widest text-amber-400">
                  Verified Public Vote
                </span>
                <h4 className="text-xl font-extrabold text-white">Support This Nominee</h4>
                <p className="text-xs text-slate-400">
                  Cast your verified vote today to help {nominee.name} win in the CSCPO South Asian Leadership Awards.
                </p>
              </div>

              <div className="p-4 bg-slate-950 border border-slate-800 rounded-2xl text-center space-y-1">
                <div className="text-3xl font-extrabold text-amber-400">
                  #{nominee.voteCount.toLocaleString()}
                </div>
                <div className="text-[10px] uppercase font-bold text-slate-400">
                  Current Certified Votes
                </div>
              </div>

              <button
                onClick={() => setIsVotingOpen(true)}
                className="w-full py-3.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-bold text-sm shadow-lg shadow-amber-500/20 transition flex items-center justify-center space-x-2 cursor-pointer"
              >
                <Vote className="w-4 h-4" />
                <span>Cast Verified Vote Now</span>
              </button>

              <div className="text-[11px] text-slate-400 text-center flex items-center justify-center space-x-1">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                <span>Protected by CSCPO 1-Vote-Per-Category policy</span>
              </div>
            </div>

            {/* Campaign Flyer & QR Quick Actions */}
            <div className="bg-slate-900/60 border border-slate-800 p-6 rounded-3xl space-y-4 text-xs">
              <h4 className="text-sm font-bold text-white flex items-center space-x-2">
                <Share2 className="w-4 h-4 text-amber-400" />
                <span>Nominee Campaign Toolkit</span>
              </h4>

              <p className="text-slate-400 leading-relaxed">
                Nominees and supporters can download high-resolution campaign flyers or scan QR codes for direct mobile
                voting.
              </p>

              <div className="space-y-2">
                <button
                  onClick={() => setIsShareOpen(true)}
                  className="w-full py-2.5 px-3 rounded-xl bg-slate-950 hover:bg-slate-850 border border-slate-800 text-slate-200 font-semibold flex items-center justify-center space-x-2 transition cursor-pointer"
                >
                  <Download className="w-4 h-4 text-amber-400" />
                  <span>Download Campaign Poster</span>
                </button>

                <button
                  onClick={() => setIsShareOpen(true)}
                  className="w-full py-2.5 px-3 rounded-xl bg-slate-950 hover:bg-slate-850 border border-slate-800 text-slate-200 font-semibold flex items-center justify-center space-x-2 transition cursor-pointer"
                >
                  <QrCode className="w-4 h-4 text-amber-400" />
                  <span>View Mobile Scan QR Code</span>
                </button>
              </div>
            </div>

            {/* Nominator Credit (if available) */}
            {nominee.nominatorName && (
              <div className="bg-slate-900/40 border border-slate-800/80 p-5 rounded-3xl space-y-2 text-xs">
                <div className="text-[10px] uppercase font-bold tracking-wider text-slate-400">
                  Nomination Submitted By
                </div>
                <div className="font-bold text-slate-200">{nominee.nominatorName}</div>
                <div className="text-slate-400 text-[11px]">{nominee.nominatorRelation}</div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Voting Modal */}
      <VotingModal
        nominee={nominee}
        isOpen={isVotingOpen}
        onClose={() => setIsVotingOpen(false)}
        onVoteSuccess={handleVoteSuccess}
      />

      {/* Share Modal */}
      <ShareModal
        nominee={nominee}
        isOpen={isShareOpen}
        onClose={() => setIsShareOpen(false)}
      />
    </div>
  );
}
