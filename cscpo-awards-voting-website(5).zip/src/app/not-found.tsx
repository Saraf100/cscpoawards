"use client";

import React from "react";
import Link from "next/link";
import { Shield, Vote, Award, Key, ArrowRight, Home } from "lucide-react";

export default function NotFound() {
  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col items-center justify-center p-4">
      <div className="max-w-md w-full text-center space-y-6 bg-slate-900 border border-slate-800 p-8 rounded-3xl shadow-2xl">
        <div className="w-16 h-16 rounded-full bg-amber-500/20 border border-amber-400/40 flex items-center justify-center text-amber-400 mx-auto">
          <Shield className="w-8 h-8" />
        </div>

        <div className="space-y-2">
          <span className="text-[11px] uppercase font-bold text-amber-400 tracking-wider">
            CSCPO South Asian Leadership Awards
          </span>
          <h1 className="text-2xl font-extrabold text-white">Page Not Found (404)</h1>
          <p className="text-xs text-slate-400">
            The page you are looking for might have been moved or had its link updated. Please use the direct navigation
            shortcuts below:
          </p>
        </div>

        <div className="space-y-2.5 pt-2">
          <Link
            href="/admin"
            className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-bold text-xs flex items-center justify-center space-x-2 transition shadow-lg shadow-amber-500/20"
          >
            <Shield className="w-4 h-4" />
            <span>Go to Admin Portal (/admin)</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </Link>

          <Link
            href="/access"
            className="w-full py-2.5 px-4 rounded-xl bg-slate-800 hover:bg-slate-750 text-amber-300 font-semibold text-xs flex items-center justify-center space-x-2 transition border border-slate-700"
          >
            <Key className="w-3.5 h-3.5" />
            <span>View Access Links & Credentials (/access)</span>
          </Link>

          <div className="grid grid-cols-2 gap-2 pt-1">
            <Link
              href="/voting"
              className="py-2 px-3 rounded-xl bg-slate-950 hover:bg-slate-850 border border-slate-800 text-slate-300 text-xs font-medium text-center transition flex items-center justify-center space-x-1"
            >
              <Vote className="w-3.5 h-3.5 text-amber-400" />
              <span>Voting Gallery</span>
            </Link>

            <Link
              href="/"
              className="py-2 px-3 rounded-xl bg-slate-950 hover:bg-slate-850 border border-slate-800 text-slate-300 text-xs font-medium text-center transition flex items-center justify-center space-x-1"
            >
              <Home className="w-3.5 h-3.5 text-amber-400" />
              <span>Homepage</span>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
