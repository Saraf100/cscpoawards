"use client";

import React, { useState } from "react";
import Link from "next/link";
import {
  FileText,
  Database,
  Shield,
  Layers,
  Code,
  Download,
  Copy,
  Check,
  CheckCircle,
  ExternalLink,
  ChevronRight,
  Workflow,
  Cpu,
  Lock,
} from "lucide-react";

export default function SRSPage() {
  const [activeSection, setActiveSection] = useState<string>("overview");
  const [copied, setCopied] = useState(false);

  const handleDownloadMarkdown = () => {
    const srsContent = `# SOFTWARE REQUIREMENTS SPECIFICATION (SRS)
## CSCPO South Asian Leadership Awards
**Version:** 1.0.0-PROD  
**Host Organization:** Council of Supply Chain Professionals Organization (CSCPO)  
**Target Embedding Site:** https://cscpo.org/cscpobdawards2026/  
**Reference Architecture:** techawardbd.com/voting

---

### 1. SYSTEM PURPOSE & EXECUTIVE SUMMARY
The CSCPO South Asian Leadership Awards Platform is a mission-critical, high-integrity web application combining:
1. An international online **Nomination Submission System**.
2. A cryptographic **Verified Public Voting Platform**.
3. A comprehensive **Award Management Dashboard (Admin Portal)**.

### 2. USER ROLES & RBAC MATRIX
| Role | Capabilities |
| --- | --- |
| Guest Visitor | Browse nominees, view profiles, inspect live results, read criteria |
| Verified Voter | Authenticated via Google, Facebook, or Email OTP; cast 1 vote per category |
| Nominee / Applicant | Submit nomination, save draft, track review status with ref code |
| Screening Jury | Review dossiers, approve/reject submissions with structured feedback |
| Administrator | Configure voting dates, manage policy, audit fraud, export CSV ledgers |

### 2.1 FORCED ADMIN AUTHENTICATION CREDENTIALS
- **Master Administrator**:
  - Route: \`/admin\`
  - Login Name / Email: \`admin@cscpo.org\` or \`admin\`
  - Password: \`cscpo@leadership#2026\`
- **Jury Screening Officer**:
  - Route: \`/admin\`
  - Login Name / Email: \`jury@cscpo.org\` or \`jury\`
  - Password: \`jury@review#2026\`

### 3. DATABASE SCHEMA & POSTGRESQL ARCHITECTURE
- **categories**: (id, slug, name, name_bn, description, icon, display_order, is_active)
- **nominees**: (id, slug, ref_number, category_id, name, designation, organization, country, email, mobile, photo_url, achievement_summary, why_nominate, vote_count, status, rank)
- **voters**: (id, email, name, auth_provider, provider_id, is_identity_verified, ip_address, status, vote_count_total)
- **email_otp_requests**: (id, email, name, code_hash, attempts, requested_ip, expires_at, consumed_at, created_at)
- **votes**: (id, voter_id, nominee_id, category_id, ip_address, verification_method, is_fraud, is_valid, created_at)
- **voting_settings**: (id, voting_status, voting_start_date, voting_end_date, voting_policy, show_public_counts)
- **admin_audit_logs**: (id, action, performed_by, details, ip_address, created_at)
- **notifications_log**: (id, recipient_email, type, subject, body, status, sent_at)

### VOTER AUTHENTICATION CONFIGURATION
- Google OAuth: GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET; callback /api/auth/oauth/google/callback.
- Facebook OAuth: FACEBOOK_APP_ID and FACEBOOK_APP_SECRET; callback /api/auth/oauth/facebook/callback.
- Email OTP: verified Resend sender configured with RESEND_API_KEY and RESEND_FROM_EMAIL.
- Voter sessions use signed HTTP-only cookies. Vote API derives the voter from that session, never from a client-supplied email.

### 4. VOTING INTEGRITY ENGINE & ANTI-FRAUD LOGIC
- Rule 1: Verified accounts only (no anonymous voting).
- Rule 2: Strictly 1 vote per category per verified voter (enforced by backend unique index query).
- Rule 3: Anti-bot challenge (dynamic math/CAPTCHA validation).
- Rule 4: IP velocity limits (>25 votes per hour triggers fraud flag).
- Rule 5: Immutable audit trail with transaction receipt codes.

### 5. IFRAME EMBED PROTOCOL
\`\`\`html
<iframe src="https://cscpo.org/cscpobdawards2026/voting?embed=true" width="100%" height="900" frameborder="0"></iframe>
\`\`\`
`;

    const blob = new Blob([srsContent], { type: "text/markdown" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "CSCPO-Awards-SRS-Specification.md";
    a.click();
  };

  const copyIframe = () => {
    navigator.clipboard.writeText(
      '<iframe src="https://cscpo.org/cscpobdawards2026/voting?embed=true" width="100%" height="900" frameborder="0"></iframe>'
    );
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 py-10">
      <div className="container mx-auto px-4 max-w-6xl space-y-10">
        {/* Header Ribbon */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 pb-6 border-b border-slate-800">
          <div className="space-y-2">
            <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/20 text-amber-300 text-xs font-semibold">
              <Code className="w-3.5 h-3.5 text-amber-400" />
              <span>Fullstack Developer Specification Document</span>
            </div>
            <h1 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
              Software Requirements Specification (SRS)
            </h1>
            <p className="text-sm text-slate-400 max-w-2xl">
              Complete engineering blueprints, database entity models, voting verification algorithms, and embedding
              architecture for the CSCPO South Asian Leadership Awards.
            </p>
          </div>

          <div className="flex items-center space-x-2">
            <button
              onClick={handleDownloadMarkdown}
              className="px-4 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs flex items-center space-x-2 shadow-lg shadow-amber-500/20 transition cursor-pointer"
            >
              <Download className="w-4 h-4" />
              <span>Download SRS (.md)</span>
            </button>
          </div>
        </div>

        {/* Section Navigation Tabs */}
        <div className="flex border-b border-slate-800 space-x-2 overflow-x-auto pb-1 text-xs font-semibold no-scrollbar">
          {[
            { id: "overview", label: "1. Executive Summary & Architecture" },
            { id: "rbac", label: "2. User Roles & RBAC" },
            { id: "schema", label: "3. Database Schema & Models" },
            { id: "engine", label: "4. Voting Engine & Anti-Fraud" },
            { id: "layouts", label: "5. Page Layouts & UX Specs" },
            { id: "workflows", label: "6. Admin Workflows" },
            { id: "api", label: "7. API Endpoint Reference" },
            { id: "embed", label: "8. Iframe Embed Guide" },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveSection(tab.id)}
              className={`px-3.5 py-2 rounded-xl whitespace-nowrap transition cursor-pointer ${
                activeSection === tab.id
                  ? "bg-amber-500 text-slate-950 font-bold"
                  : "text-slate-400 hover:text-white hover:bg-slate-900"
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* SECTION CONTENTS */}
        <div className="bg-slate-900/60 border border-slate-800 rounded-3xl p-6 sm:p-10 shadow-2xl space-y-8">
          {/* 1. OVERVIEW */}
          {activeSection === "overview" && (
            <div className="space-y-6 text-sm text-slate-300 leading-relaxed">
              <div className="space-y-2 border-b border-slate-800 pb-4">
                <h2 className="text-xl font-bold text-white flex items-center space-x-2">
                  <Layers className="w-5 h-5 text-amber-400" />
                  <span>1. System Purpose & Architecture Overview</span>
                </h2>
                <p className="text-xs text-slate-400">
                  Engineering foundation for an internationally credible, multi-device friendly award platform.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="p-4 bg-slate-950 border border-slate-800 rounded-2xl space-y-2">
                  <div className="text-amber-400 font-bold text-sm">Nomination Portal</div>
                  <p className="text-xs text-slate-400">
                    Comprehensive multi-field online form with validation, automatic reference codes (`CSCPO-NXXXX`),
                    draft saving, evidence attachments, and status tracking.
                  </p>
                </div>

                <div className="p-4 bg-slate-950 border border-slate-800 rounded-2xl space-y-2">
                  <div className="text-emerald-400 font-bold text-sm">Verified Public Voting</div>
                  <p className="text-xs text-slate-400">
                    Server-verified account authentication via configured Google/Facebook OAuth or email OTP. Enforces one vote per category, anti-bot challenge, IP velocity checks, and instant receipt generation. Social login is not real-world identity verification.
                  </p>
                </div>

                <div className="p-4 bg-slate-950 border border-slate-800 rounded-2xl space-y-2">
                  <div className="text-blue-400 font-bold text-sm">Organizer Admin Center</div>
                  <p className="text-xs text-slate-400">
                    Complete oversight for jury screening, approving/rejecting nominations with reason, live vote
                    monitoring, fraudulent vote revocation, and CSV data export.
                  </p>
                </div>
              </div>

              <div className="space-y-3 pt-2">
                <h3 className="text-base font-bold text-white">Recommended Technology Stack</h3>
                <ul className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                  <li className="p-3 bg-slate-950 rounded-xl border border-slate-800 flex items-center space-x-2">
                    <CheckCircle className="w-4 h-4 text-emerald-400" />
                    <span>Frontend & Fullstack: Next.js App Router (React 19)</span>
                  </li>
                  <li className="p-3 bg-slate-950 rounded-xl border border-slate-800 flex items-center space-x-2">
                    <CheckCircle className="w-4 h-4 text-emerald-400" />
                    <span>Database: PostgreSQL with Drizzle ORM</span>
                  </li>
                  <li className="p-3 bg-slate-950 rounded-xl border border-slate-800 flex items-center space-x-2">
                    <CheckCircle className="w-4 h-4 text-emerald-400" />
                    <span>Styling: Tailwind CSS (Mobile, Tablet, Desktop Responsive)</span>
                  </li>
                  <li className="p-3 bg-slate-950 rounded-xl border border-slate-800 flex items-center space-x-2">
                    <CheckCircle className="w-4 h-4 text-emerald-400" />
                    <span>Security: IP Velocity Limiting, CAPTCHA, Confetti Feedback</span>
                  </li>
                </ul>
              </div>
            </div>
          )}

          {/* 2. RBAC */}
          {activeSection === "rbac" && (
            <div className="space-y-6 text-sm text-slate-300 leading-relaxed">
              <div className="space-y-2 border-b border-slate-800 pb-4">
                <h2 className="text-xl font-bold text-white flex items-center space-x-2">
                  <Shield className="w-5 h-5 text-amber-400" />
                  <span>2. User Roles & RBAC Matrix</span>
                </h2>
                <p className="text-xs text-slate-400">
                  Defines access privileges across public users, verified voters, and organizers.
                </p>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs border border-slate-800 rounded-xl overflow-hidden">
                  <thead className="bg-slate-950 text-slate-400 uppercase tracking-wider text-[10px]">
                    <tr>
                      <th className="p-3">Feature / Capability</th>
                      <th className="p-3">Guest Visitor</th>
                      <th className="p-3">Verified Voter</th>
                      <th className="p-3">Nominee</th>
                      <th className="p-3">Administrator</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800">
                    <tr>
                      <td className="p-3 font-medium text-white">Browse Nominees & Profiles</td>
                      <td className="p-3 text-emerald-400">Yes</td>
                      <td className="p-3 text-emerald-400">Yes</td>
                      <td className="p-3 text-emerald-400">Yes</td>
                      <td className="p-3 text-emerald-400">Yes</td>
                    </tr>
                    <tr>
                      <td className="p-3 font-medium text-white">Submit New Nomination</td>
                      <td className="p-3 text-emerald-400">Yes</td>
                      <td className="p-3 text-emerald-400">Yes</td>
                      <td className="p-3 text-emerald-400">Yes</td>
                      <td className="p-3 text-emerald-400">Yes</td>
                    </tr>
                    <tr>
                      <td className="p-3 font-medium text-white">Cast Public Vote</td>
                      <td className="p-3 text-red-400">Auth Required</td>
                      <td className="p-3 text-emerald-400">Yes (1/category)</td>
                      <td className="p-3 text-emerald-400">Yes (1/category)</td>
                      <td className="p-3 text-emerald-400">Yes</td>
                    </tr>
                    <tr>
                      <td className="p-3 font-medium text-white">Download Campaign Poster & QR</td>
                      <td className="p-3 text-emerald-400">Yes</td>
                      <td className="p-3 text-emerald-400">Yes</td>
                      <td className="p-3 text-emerald-400">Yes</td>
                      <td className="p-3 text-emerald-400">Yes</td>
                    </tr>
                    <tr>
                      <td className="p-3 font-medium text-white">Approve / Reject Nominations</td>
                      <td className="p-3 text-slate-600">No</td>
                      <td className="p-3 text-slate-600">No</td>
                      <td className="p-3 text-slate-600">No</td>
                      <td className="p-3 text-emerald-400">Yes</td>
                    </tr>
                    <tr>
                      <td className="p-3 font-medium text-white">Revoke Votes & Flag Fraud</td>
                      <td className="p-3 text-slate-600">No</td>
                      <td className="p-3 text-slate-600">No</td>
                      <td className="p-3 text-slate-600">No</td>
                      <td className="p-3 text-emerald-400">Yes</td>
                    </tr>
                    <tr>
                      <td className="p-3 font-medium text-white">Export CSV Ledgers</td>
                      <td className="p-3 text-slate-600">No</td>
                      <td className="p-3 text-slate-600">No</td>
                      <td className="p-3 text-slate-600">No</td>
                      <td className="p-3 text-emerald-400">Yes</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* 3. SCHEMA */}
          {activeSection === "schema" && (
            <div className="space-y-6 text-sm text-slate-300 leading-relaxed">
              <div className="space-y-2 border-b border-slate-800 pb-4">
                <h2 className="text-xl font-bold text-white flex items-center space-x-2">
                  <Database className="w-5 h-5 text-amber-400" />
                  <span>3. Database Schema & PostgreSQL Architecture</span>
                </h2>
                <p className="text-xs text-slate-400">
                  Defined with Drizzle ORM over PostgreSQL (`app_db`).
                </p>
              </div>

              <div className="space-y-4">
                <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800 font-mono text-xs space-y-2">
                  <div className="text-amber-400 font-bold font-sans">Tables Implemented:</div>
                  <ul className="space-y-1.5 text-slate-300">
                    <li>
                      <strong className="text-white">1. categories:</strong> id (PK), slug (UK), name, name_bn, description,
                      icon, display_order, is_active.
                    </li>
                    <li>
                      <strong className="text-white">2. nominees:</strong> id (PK), slug (UK), ref_number (UK),
                      category_id (FK), name, designation, organization, country, email, mobile, photo_url,
                      achievement_summary, why_nominate, experience_years, supporting_documents (JSONB), status
                      (APPROVED/PENDING/REJECTED), vote_count, rank.
                    </li>
                    <li>
                      <strong className="text-white">3. voters:</strong> id (PK), email (UK), name, auth_provider
                      (GOOGLE/FACEBOOK/EMAIL_OTP), provider_id, is_identity_verified, ip_address, status (ACTIVE/FLAGGED/SUSPENDED),
                      vote_count_total.
                    </li>
                    <li>
                      <strong className="text-white">4. email_otp_requests:</strong> email, one-way code hash, attempt count, request IP, expiration, consumption timestamp.
                    </li>
                    <li>
                      <strong className="text-white">5. votes:</strong> id (PK), voter_id (FK), nominee_id (FK),
                      category_id (FK), voter_email, ip_address, verification_method, is_fraud, is_valid, revoked_reason,
                      created_at.
                    </li>
                    <li>
                      <strong className="text-white">6. voting_settings:</strong> id (PK), voting_status
                      (OPEN/PAUSED/CLOSED), voting_start_date, voting_end_date, voting_policy, show_public_counts,
                      show_public_rankings, require_captcha.
                    </li>
                    <li>
                      <strong className="text-white">7. admin_audit_logs:</strong> id (PK), action, performed_by,
                      details, ip_address, created_at.
                    </li>
                    <li>
                      <strong className="text-white">8. notifications_log:</strong> id (PK), recipient_email, type,
                      subject, body, status, sent_at.
                    </li>
                    <li>
                      <strong className="text-white">9. previous_winners:</strong> id (PK), year, category_name,
                      winner_name, designation, organization, country, achievement.
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          )}

          {/* 4. VOTING ENGINE */}
          {activeSection === "engine" && (
            <div className="space-y-6 text-sm text-slate-300 leading-relaxed">
              <div className="space-y-2 border-b border-slate-800 pb-4">
                <h2 className="text-xl font-bold text-white flex items-center space-x-2">
                  <Workflow className="w-5 h-5 text-amber-400" />
                  <span>4. Voting Engine Logic & Anti-Fraud State Machine</span>
                </h2>
                <p className="text-xs text-slate-400">
                  Algorithmic integrity guarantees to satisfy international award standards.
                </p>
              </div>

              <div className="p-4 bg-slate-950 border border-slate-800 rounded-2xl space-y-3 text-xs">
                <div className="text-amber-400 font-bold text-sm">Voting Flow Sequence:</div>
                <ol className="list-decimal list-inside space-y-2 text-slate-300">
                  <li>User selects nominee card and clicks &ldquo;Vote Now&rdquo;.</li>
                  <li>
                    System checks the signed server-side voter session. If unauthenticated, Google/Facebook redirects to configured OAuth providers or email sends a server-generated, time-limited OTP via Resend.
                  </li>
                  <li>
                    System executes pre-vote policy check on backend (e.g. querying <code>votes</code> where{" "}
                    <code>voter_id = ? AND category_id = ? AND is_valid = true</code>).
                  </li>
                  <li>
                    If a vote in that category has already occurred, server rejects request with HTTP 409 and user-friendly
                    policy message.
                  </li>
                  <li>
                    User solves anti-bot challenge (dynamic math equation).
                  </li>
                  <li>
                    Server logs IP address, checks 1-hour burst velocity (&gt;25 votes from same IP flags fraud), and
                    inserts vote into database.
                  </li>
                  <li>
                    Atomically increments <code>nominees.vote_count</code> and <code>voters.vote_count_total</code>.
                  </li>
                  <li>
                    Generates official receipt code (e.g. <code>CSCPO-VOTE-12-KV31...</code>), logs notification, and
                    triggers confetti celebration.
                  </li>
                </ol>
              </div>
            </div>
          )}

          {/* 5. PAGE LAYOUTS */}
          {activeSection === "layouts" && (
            <div className="space-y-6 text-sm text-slate-300 leading-relaxed">
              <div className="space-y-2 border-b border-slate-800 pb-4">
                <h2 className="text-xl font-bold text-white flex items-center space-x-2">
                  <Layers className="w-5 h-5 text-amber-400" />
                  <span>5. Page Layouts & User Experience Specifications</span>
                </h2>
                <p className="text-xs text-slate-400">
                  Detailed layout guidelines reflecting techawardbd.com/voting reference and prestige awards identity.
                </p>
              </div>

              <div className="space-y-4 text-xs">
                <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800 space-y-1.5">
                  <div className="text-amber-400 font-bold">1. Nominee Card Blueprint:</div>
                  <p className="text-slate-300">
                    Photo header (64h) with approved badge, country pill, category ribbon. Body contains full name,
                    designation, organization, achievement summary. Below, two prominent metric boxes: Total Votes (`#
                    1,250`) and Honored Nominee distinction (★ Finalist) to honor each candidate equally. Action bar contains View Profile, Vote Now, and Share Voting Link.
                  </p>
                </div>

                <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800 space-y-1.5">
                  <div className="text-emerald-400 font-bold">2. Dedicated Nominee Page (`/nominee/[slug]`):</div>
                  <p className="text-slate-300">
                    High-res profile photo, verified finalist badge, reference number, live category standing, full biography,
                    major supply chain contributions, verified certificates list, campaign poster generator, and instant
                    voting modal.
                  </p>
                </div>

                <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800 space-y-1.5">
                  <div className="text-blue-400 font-bold">3. Transparency Dashboard (`/results`):</div>
                  <p className="text-slate-300">
                    Four summary KPIs, category distribution progress bars with percentage share, country participation stats,
                    and anonymized live audit feed with timestamps and verification methods.
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* 6. ADMIN WORKFLOWS */}
          {activeSection === "workflows" && (
            <div className="space-y-6 text-sm text-slate-300 leading-relaxed">
              <div className="space-y-2 border-b border-slate-800 pb-4">
                <h2 className="text-xl font-bold text-white flex items-center space-x-2">
                  <Cpu className="w-5 h-5 text-amber-400" />
                  <span>6. Administrator Operational Workflows</span>
                </h2>
                <p className="text-xs text-slate-400">
                  Standard operating procedures for CSCPO jury and election officers.
                </p>
              </div>

              <div className="space-y-3 text-xs">
                <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800 space-y-2">
                  <div className="text-amber-400 font-bold">Nomination Review & Decision:</div>
                  <p>
                    Administrators inspect pending submissions under <code>/admin</code>. Clicking &ldquo;Approve&rdquo; sets
                    status to <code>APPROVED</code>, dispatches an approval notification to the candidate, and publishes
                    their card to <code>/voting</code>. Clicking &ldquo;Reject&rdquo; opens a modal prompting for specific
                    feedback, which is recorded in the audit trail.
                  </p>
                </div>

                <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800 space-y-2">
                  <div className="text-red-400 font-bold">Vote Revocation & Audit Trace:</div>
                  <p>
                    If suspicious burst voting or bot script activity is detected, the administrator can revoke a specific
                    vote ID or suspend the voter. When revoked, the system adjusts the nominee&rsquo;s vote count downward
                    with an immutable reason in <code>admin_audit_logs</code>.
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* 7. API ENDPOINT REFERENCE */}
          {activeSection === "api" && (
            <div className="space-y-6 text-sm text-slate-300 leading-relaxed">
              <div className="space-y-2 border-b border-slate-800 pb-4">
                <h2 className="text-xl font-bold text-white flex items-center space-x-2">
                  <Code className="w-5 h-5 text-amber-400" />
                  <span>7. RESTful API Endpoints Reference</span>
                </h2>
                <p className="text-xs text-slate-400">
                  All endpoints return JSON responses with standard <code>{`{ success: boolean, data?: any, error?: string }`}</code>.
                </p>
              </div>

              <div className="space-y-2 text-xs font-mono">
                <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 flex justify-between">
                  <span className="text-emerald-400 font-bold">GET /api/nominees</span>
                  <span className="text-slate-400">Query params: category, country, search, sort, status</span>
                </div>
                <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 flex justify-between">
                  <span className="text-amber-400 font-bold">POST /api/nominees</span>
                  <span className="text-slate-400">Submit new nomination or save as draft</span>
                </div>
                <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 flex justify-between">
                  <span className="text-emerald-400 font-bold">GET /api/nominees/[slug]</span>
                  <span className="text-slate-400">Fetch single nominee dossier & rank stats</span>
                </div>
                <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 flex justify-between">
                  <span className="text-emerald-400 font-bold">GET /api/categories</span>
                  <span className="text-slate-400">Fetch all categories with vote totals</span>
                </div>
                <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 flex justify-between">
                  <span className="text-amber-400 font-bold">POST /api/votes/cast</span>
                  <span className="text-slate-400">Cast verified vote with anti-fraud & CAPTCHA</span>
                </div>
                <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 flex justify-between">
                  <span className="text-emerald-400 font-bold">GET /api/votes/stats</span>
                  <span className="text-slate-400">Aggregated live transparency statistics</span>
                </div>
                <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 flex justify-between">
                  <span className="text-amber-400 font-bold">POST /api/nomination/status</span>
                  <span className="text-slate-400">Query application status by refNumber + email</span>
                </div>
                <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 flex justify-between">
                  <span className="text-red-400 font-bold">POST /api/admin/nominees/[id]/status</span>
                  <span className="text-slate-400">Approve or reject nomination with audit note</span>
                </div>
              </div>
            </div>
          )}

          {/* 8. EMBED GUIDE */}
          {activeSection === "embed" && (
            <div className="space-y-6 text-sm text-slate-300 leading-relaxed">
              <div className="space-y-2 border-b border-slate-800 pb-4">
                <h2 className="text-xl font-bold text-white flex items-center space-x-2">
                  <ExternalLink className="w-5 h-5 text-amber-400" />
                  <span>8. Iframe Embedding in https://cscpo.org/cscpobdawards2026/</span>
                </h2>
                <p className="text-xs text-slate-400">
                  Standard responsive code snippet to embed this entire voting platform into the CSCPO WordPress or
                  custom event page.
                </p>
              </div>

              <div className="space-y-3">
                <p className="text-xs text-slate-300">
                  Copy and paste the following snippet into the HTML block of the page at{" "}
                  <code>https://cscpo.org/cscpobdawards2026/</code>:
                </p>

                <div className="relative p-4 bg-slate-950 border border-slate-800 rounded-2xl font-mono text-xs text-amber-300">
                  <pre className="overflow-x-auto">
{`<div style="width:100%; max-width:1200px; margin:0 auto; overflow:hidden; border-radius:16px; box-shadow:0 10px 30px rgba(0,0,0,0.3);">
  <iframe 
    src="https://cscpo.org/cscpobdawards2026/voting?embed=true" 
    width="100%" 
    height="950" 
    frameborder="0" 
    allow="clipboard-write"
    loading="lazy"
    title="CSCPO South Asian Leadership Awards - Public Voting Portal">
  </iframe>
</div>`}
                  </pre>
                  <button
                    onClick={copyIframe}
                    className="absolute top-3 right-3 px-3 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs flex items-center space-x-1 cursor-pointer"
                  >
                    {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copied ? "Copied" : "Copy"}</span>
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
