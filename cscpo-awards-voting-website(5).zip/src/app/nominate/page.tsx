"use client";

import React, { useState, useEffect } from "react";
import Link from "next/link";
import { Category } from "@/lib/types";
import {
  Award,
  CheckCircle2,
  AlertCircle,
  FileText,
  Upload,
  Save,
  Send,
  Search,
  Clock,
  ShieldCheck,
  User,
  Building,
  Mail,
  Phone,
  Briefcase,
  ExternalLink,
  ChevronRight,
  Info,
} from "lucide-react";

export default function NominatePage() {
  const [categories, setCategories] = useState<Category[]>([]);
  const [activeTab, setActiveTab] = useState<"NEW" | "TRACK">("NEW");

  // Form Fields
  const [categoryId, setCategoryId] = useState<string>("");
  const [name, setName] = useState("");
  const [designation, setDesignation] = useState("");
  const [organization, setOrganization] = useState("");
  const [country, setCountry] = useState("Bangladesh");
  const [email, setEmail] = useState("");
  const [mobile, setMobile] = useState("");
  const [experienceYears, setExperienceYears] = useState("10");
  const [achievementSummary, setAchievementSummary] = useState("");
  const [whyNominate, setWhyNominate] = useState("");
  const [bio, setBio] = useState("");
  const [careerHistory, setCareerHistory] = useState("");
  const [supplyChainContributions, setSupplyChainContributions] = useState("");
  const [photoUrl, setPhotoUrl] = useState("");
  const [linkedinUrl, setLinkedinUrl] = useState("");
  const [websiteUrl, setWebsiteUrl] = useState("");
  const [nominatorName, setNominatorName] = useState("");
  const [nominatorEmail, setNominatorEmail] = useState("");
  const [nominatorRelation, setNominatorRelation] = useState("Self-Nomination");

  // Supporting docs
  const [docTitle, setDocTitle] = useState("");
  const [docUrl, setDocUrl] = useState("");
  const [supportingDocs, setSupportingDocs] = useState<Array<{ title: string; url: string }>>([]);

  // Submission State
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submissionSuccess, setSubmissionSuccess] = useState<{
    refNumber: string;
    message: string;
    isDraft: boolean;
  } | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Status tracking state
  const [trackRefNumber, setTrackRefNumber] = useState("");
  const [trackEmail, setTrackEmail] = useState("");
  const [isTracking, setIsTracking] = useState(false);
  const [trackedNomination, setTrackedNomination] = useState<any | null>(null);
  const [trackError, setTrackError] = useState<string | null>(null);

  useEffect(() => {
    fetch("/api/categories")
      .then((res) => res.json())
      .then((data) => {
        if (data.success && data.data) {
          setCategories(data.data);
          if (data.data.length > 0) {
            setCategoryId(String(data.data[0].id));
          }
        }
      })
      .catch(console.error);

    // Restore draft from localStorage if present
    try {
      const savedDraft = localStorage.getItem("cscpo_nomination_draft");
      if (savedDraft) {
        const d = JSON.parse(savedDraft);
        if (d.name) setName(d.name);
        if (d.designation) setDesignation(d.designation);
        if (d.organization) setOrganization(d.organization);
        if (d.country) setCountry(d.country);
        if (d.email) setEmail(d.email);
        if (d.mobile) setMobile(d.mobile);
        if (d.achievementSummary) setAchievementSummary(d.achievementSummary);
        if (d.whyNominate) setWhyNominate(d.whyNominate);
      }
    } catch (e) {
      console.error(e);
    }
  }, []);

  const addSupportingDoc = () => {
    if (!docTitle) return;
    setSupportingDocs((prev) => [
      ...prev,
      { title: docTitle, url: docUrl || "https://cscpo.org/evidence-dossier" },
    ]);
    setDocTitle("");
    setDocUrl("");
  };

  const removeSupportingDoc = (index: number) => {
    setSupportingDocs((prev) => prev.filter((_, i) => i !== index));
  };

  const handleSaveDraftLocally = () => {
    const draft = {
      categoryId,
      name,
      designation,
      organization,
      country,
      email,
      mobile,
      achievementSummary,
      whyNominate,
    };
    localStorage.setItem("cscpo_nomination_draft", JSON.stringify(draft));
    alert("Draft saved to browser storage. You can continue filling it anytime.");
  };

  const handleSubmit = async (isDraft: boolean) => {
    if (!name || !organization || !categoryId || !email) {
      setErrorMessage("Please fill in the required fields: Full Name, Organization, Award Category, and Email.");
      return;
    }

    setIsSubmitting(true);
    setErrorMessage(null);

    try {
      const res = await fetch("/api/nominees", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          categoryId: Number(categoryId),
          name,
          designation,
          organization,
          country,
          email,
          mobile,
          experienceYears: Number(experienceYears),
          achievementSummary,
          whyNominate,
          bio,
          careerHistory,
          supplyChainContributions,
          supportingDocuments: supportingDocs,
          photoUrl,
          linkedinUrl,
          websiteUrl,
          isDraft,
          nominatorName: nominatorName || name,
          nominatorEmail: nominatorEmail || email,
          nominatorRelation,
        }),
      });

      const result = await res.json();

      if (!res.ok || !result.success) {
        setErrorMessage(result.error || "Failed to submit nomination. Please review the form.");
        setIsSubmitting(false);
        return;
      }

      // Clear local draft if submitted
      if (!isDraft) {
        localStorage.removeItem("cscpo_nomination_draft");
      }

      setSubmissionSuccess({
        refNumber: result.refNumber,
        message: result.message,
        isDraft,
      });
    } catch (err) {
      console.error(err);
      setErrorMessage("Network error while submitting nomination. Please try again.");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleTrackSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!trackRefNumber || !trackEmail) {
      setTrackError("Please enter both the Reference Number and your Email Address.");
      return;
    }

    setIsTracking(true);
    setTrackError(null);
    setTrackedNomination(null);

    try {
      const res = await fetch("/api/nomination/status", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          refNumber: trackRefNumber,
          email: trackEmail,
        }),
      });

      const result = await res.json();
      if (!res.ok || !result.success) {
        setTrackError(result.error || "Nomination not found. Please verify your reference number.");
      } else {
        setTrackedNomination(result.data);
      }
    } catch (err) {
      console.error(err);
      setTrackError("Error querying status. Please check your network.");
    } finally {
      setIsTracking(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 py-10">
      <div className="container mx-auto px-4 max-w-4xl space-y-8">
        {/* Header Ribbon */}
        <div className="text-center space-y-3">
          <div className="inline-flex items-center space-x-2 px-3.5 py-1 rounded-full bg-amber-500/10 border border-amber-500/20 text-amber-300 text-xs font-semibold">
            <Award className="w-3.5 h-3.5 text-amber-400" />
            <span>CSCPO South Asian Leadership Awards</span>
          </div>
          <h1 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
            Nomination & Submission Portal
          </h1>
          <p className="text-sm text-slate-400 max-w-2xl mx-auto">
            Nominate exceptional supply chain, logistics, and procurement leaders across Bangladesh, India, Sri Lanka,
            Pakistan, Nepal, and Bhutan.
          </p>
        </div>

        {/* Tab Toggle: New Nomination vs Track Status */}
        <div className="flex bg-slate-900 border border-slate-800 p-1.5 rounded-2xl max-w-md mx-auto">
          <button
            onClick={() => setActiveTab("NEW")}
            className={`flex-1 py-2.5 rounded-xl text-xs font-bold transition flex items-center justify-center space-x-2 ${
              activeTab === "NEW"
                ? "bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20"
                : "text-slate-400 hover:text-white"
            }`}
          >
            <Send className="w-3.5 h-3.5" />
            <span>Submit Nomination</span>
          </button>
          <button
            onClick={() => setActiveTab("TRACK")}
            className={`flex-1 py-2.5 rounded-xl text-xs font-bold transition flex items-center justify-center space-x-2 ${
              activeTab === "TRACK"
                ? "bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20"
                : "text-slate-400 hover:text-white"
            }`}
          >
            <Search className="w-3.5 h-3.5" />
            <span>Track Application Status</span>
          </button>
        </div>

        {/* TAB 1: SUBMIT NOMINATION FORM */}
        {activeTab === "NEW" && (
          <div className="bg-slate-900/80 border border-slate-800 rounded-3xl p-6 sm:p-10 shadow-2xl backdrop-blur-md space-y-8">
            {/* Open Public Submission Attestation */}
            <div className="p-4 bg-amber-500/10 border border-amber-500/20 rounded-2xl flex items-start space-x-3 text-xs text-amber-200">
              <Info className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
              <div>
                <strong className="text-white block font-semibold mb-0.5">
                  Open Public Nomination Portal
                </strong>
                <span>
                  Anyone is welcome to submit a nomination — individuals, employers, colleagues, industry bodies, or
                  self-nominations. Once submitted, your nomination is screened by the CSCPO Committee and approved for
                  public voting.
                </span>
              </div>
            </div>
            {submissionSuccess ? (
              <div className="py-12 text-center space-y-6">
                <div className="w-16 h-16 rounded-full bg-emerald-500/20 border-2 border-emerald-400 flex items-center justify-center text-emerald-400 mx-auto shadow-lg shadow-emerald-500/20">
                  <CheckCircle2 className="w-8 h-8" />
                </div>

                <div className="space-y-2">
                  <h3 className="text-2xl font-bold text-white">
                    {submissionSuccess.isDraft ? "Draft Saved Successfully!" : "Nomination Officially Submitted!"}
                  </h3>
                  <p className="text-sm text-slate-300 max-w-md mx-auto">
                    {submissionSuccess.message}
                  </p>
                </div>

                {/* Reference Number Box */}
                <div className="bg-slate-950 border border-amber-500/30 p-5 rounded-2xl max-w-sm mx-auto text-center space-y-1">
                  <div className="text-[11px] uppercase font-bold text-slate-400 tracking-wider">
                    Nomination Reference Number
                  </div>
                  <div className="text-2xl font-mono font-extrabold text-amber-400 tracking-widest">
                    {submissionSuccess.refNumber}
                  </div>
                  <div className="text-[11px] text-slate-400 pt-1">
                    Keep this number to track jury screening and voting card publishing.
                  </div>
                </div>

                <div className="flex flex-wrap items-center justify-center gap-3 pt-4">
                  <button
                    onClick={() => {
                      setSubmissionSuccess(null);
                      setName("");
                      setOrganization("");
                      setAchievementSummary("");
                      setWhyNominate("");
                    }}
                    className="px-6 py-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold"
                  >
                    Submit Another Nomination
                  </button>

                  <Link
                    href="/voting"
                    className="px-6 py-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold"
                  >
                    View Public Voting Gallery
                  </Link>
                </div>
              </div>
            ) : (
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  handleSubmit(false);
                }}
                className="space-y-8"
              >
                {errorMessage && (
                  <div className="p-4 bg-red-950/60 border border-red-500/40 rounded-2xl text-red-200 text-xs flex items-start space-x-2.5">
                    <AlertCircle className="w-4 h-4 shrink-0 text-red-400 mt-0.5" />
                    <span>{errorMessage}</span>
                  </div>
                )}

                {/* SECTION 1: AWARD CATEGORY */}
                <div className="space-y-4">
                  <div className="flex items-center space-x-2 border-b border-slate-800 pb-2">
                    <Award className="w-5 h-5 text-amber-400" />
                    <h3 className="text-base font-bold text-white">1. Select Award Category</h3>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                      Award Category <span className="text-red-400">*</span>
                    </label>
                    <select
                      value={categoryId}
                      onChange={(e) => setCategoryId(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:border-amber-500 transition"
                      required
                    >
                      {categories.map((cat) => (
                        <option key={cat.id} value={cat.id}>
                          {cat.name}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                {/* SECTION 2: NOMINEE PERSONAL & PROFESSIONAL DETAILS */}
                <div className="space-y-4">
                  <div className="flex items-center space-x-2 border-b border-slate-800 pb-2">
                    <User className="w-5 h-5 text-amber-400" />
                    <h3 className="text-base font-bold text-white">2. Nominee Profile Details</h3>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                        Nominee Full Name <span className="text-red-400">*</span>
                      </label>
                      <input
                        type="text"
                        placeholder="e.g. Sharfuddin Ahmed"
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-amber-500"
                        required
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                        Current Designation <span className="text-red-400">*</span>
                      </label>
                      <input
                        type="text"
                        placeholder="e.g. Chief Supply Chain Officer (CSCO)"
                        value={designation}
                        onChange={(e) => setDesignation(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-amber-500"
                        required
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                        Organization / Company <span className="text-red-400">*</span>
                      </label>
                      <input
                        type="text"
                        placeholder="e.g. Apex Logistics Ltd."
                        value={organization}
                        onChange={(e) => setOrganization(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-amber-500"
                        required
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                        Country <span className="text-red-400">*</span>
                      </label>
                      <select
                        value={country}
                        onChange={(e) => setCountry(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-amber-500"
                      >
                        <option value="Bangladesh">Bangladesh</option>
                        <option value="India">India</option>
                        <option value="Sri Lanka">Sri Lanka</option>
                        <option value="Pakistan">Pakistan</option>
                        <option value="Nepal">Nepal</option>
                        <option value="Bhutan">Bhutan</option>
                        <option value="Maldives">Maldives</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                        Contact Email <span className="text-red-400">*</span>
                      </label>
                      <input
                        type="email"
                        placeholder="nominee@company.com"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-amber-500"
                        required
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                        Contact Mobile Number <span className="text-red-400">*</span>
                      </label>
                      <input
                        type="text"
                        placeholder="+880 1711 000000"
                        value={mobile}
                        onChange={(e) => setMobile(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-amber-500"
                        required
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                        Professional Experience (Years)
                      </label>
                      <input
                        type="number"
                        min="1"
                        max="50"
                        value={experienceYears}
                        onChange={(e) => setExperienceYears(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-amber-500"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                        Nominee Photograph URL / Headshot
                      </label>
                      <input
                        type="url"
                        placeholder="https://images.pexels.com/... or uploaded photo link"
                        value={photoUrl}
                        onChange={(e) => setPhotoUrl(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-amber-500"
                      />
                    </div>
                  </div>
                </div>

                {/* SECTION 3: ACHIEVEMENTS & CONTRIBUTIONS */}
                <div className="space-y-4">
                  <div className="flex items-center space-x-2 border-b border-slate-800 pb-2">
                    <Briefcase className="w-5 h-5 text-amber-400" />
                    <h3 className="text-base font-bold text-white">3. Achievements & Justification</h3>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                      Achievement Submission (Key metrics, operational milestones, innovation) <span className="text-red-400">*</span>
                    </label>
                    <textarea
                      rows={3}
                      placeholder="Describe specific supply chain breakthroughs, cost reductions, sustainability impact, or warehouse throughput improvements..."
                      value={achievementSummary}
                      onChange={(e) => setAchievementSummary(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-700 rounded-xl p-3.5 text-sm text-white focus:outline-none focus:border-amber-500 leading-relaxed"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                      Why Nominate? (Explanation of why the nominee deserves the award) <span className="text-red-400">*</span>
                    </label>
                    <textarea
                      rows={3}
                      placeholder="Explain leadership character, mentorship, resilience under crisis, and peer recognition..."
                      value={whyNominate}
                      onChange={(e) => setWhyNominate(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-700 rounded-xl p-3.5 text-sm text-white focus:outline-none focus:border-amber-500 leading-relaxed"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                      Major Contributions to South Asian Supply Chains (Optional)
                    </label>
                    <textarea
                      rows={2}
                      placeholder="Regional cross-border logistics, port connectivity, trade policy advocacy, etc."
                      value={supplyChainContributions}
                      onChange={(e) => setSupplyChainContributions(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-700 rounded-xl p-3.5 text-sm text-white focus:outline-none focus:border-amber-500 leading-relaxed"
                    />
                  </div>
                </div>

                {/* SECTION 4: SUPPORTING EVIDENCE & ONLINE PROFILES */}
                <div className="space-y-4">
                  <div className="flex items-center space-x-2 border-b border-slate-800 pb-2">
                    <FileText className="w-5 h-5 text-amber-400" />
                    <h3 className="text-base font-bold text-white">4. Supporting Evidence & Links</h3>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                        LinkedIn Profile URL
                      </label>
                      <input
                        type="url"
                        placeholder="https://linkedin.com/in/username"
                        value={linkedinUrl}
                        onChange={(e) => setLinkedinUrl(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-amber-500"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                        Corporate / Personal Website
                      </label>
                      <input
                        type="url"
                        placeholder="https://company.com"
                        value={websiteUrl}
                        onChange={(e) => setWebsiteUrl(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-amber-500"
                      />
                    </div>
                  </div>

                  {/* Supporting Document adder */}
                  <div className="p-4 bg-slate-950 border border-slate-800 rounded-2xl space-y-3">
                    <label className="text-xs font-semibold text-slate-300 block">
                      Add Supporting Certificates / Case Studies (Optional)
                    </label>
                    <div className="grid grid-cols-1 sm:grid-cols-12 gap-2">
                      <div className="sm:col-span-6">
                        <input
                          type="text"
                          placeholder="Document Title (e.g. ISO 28000 Certificate)"
                          value={docTitle}
                          onChange={(e) => setDocTitle(e.target.value)}
                          className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white"
                        />
                      </div>
                      <div className="sm:col-span-4">
                        <input
                          type="url"
                          placeholder="Document URL / PDF link"
                          value={docUrl}
                          onChange={(e) => setDocUrl(e.target.value)}
                          className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white"
                        />
                      </div>
                      <div className="sm:col-span-2">
                        <button
                          type="button"
                          onClick={addSupportingDoc}
                          className="w-full h-full py-2 bg-slate-800 hover:bg-slate-750 border border-slate-700 text-amber-300 rounded-xl text-xs font-semibold transition cursor-pointer"
                        >
                          + Add
                        </button>
                      </div>
                    </div>

                    {supportingDocs.length > 0 && (
                      <div className="space-y-1.5 pt-2">
                        {supportingDocs.map((doc, idx) => (
                          <div
                            key={idx}
                            className="flex items-center justify-between p-2 bg-slate-900 rounded-lg text-xs"
                          >
                            <span className="text-slate-200">{doc.title}</span>
                            <button
                              type="button"
                              onClick={() => removeSupportingDoc(idx)}
                              className="text-red-400 hover:text-red-300 text-[11px]"
                            >
                              Remove
                            </button>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>

                {/* SECTION 5: NOMINATOR DETAILS */}
                <div className="space-y-4">
                  <div className="flex items-center space-x-2 border-b border-slate-800 pb-2">
                    <ShieldCheck className="w-5 h-5 text-amber-400" />
                    <h3 className="text-base font-bold text-white">5. Nominator Information</h3>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <div>
                      <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                        Nominator Relationship
                      </label>
                      <select
                        value={nominatorRelation}
                        onChange={(e) => setNominatorRelation(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2.5 text-xs text-white"
                      >
                        <option value="Self-Nomination">Self-Nomination</option>
                        <option value="Employer / Company">Employer / Company</option>
                        <option value="Colleague / Peer">Colleague / Peer</option>
                        <option value="Industry Association">Industry Association</option>
                        <option value="Academic Institution">Academic Institution</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                        Nominator Name
                      </label>
                      <input
                        type="text"
                        placeholder="Your Name / Organization"
                        value={nominatorName}
                        onChange={(e) => setNominatorName(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2.5 text-xs text-white"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                        Nominator Email
                      </label>
                      <input
                        type="email"
                        placeholder="nominator@company.com"
                        value={nominatorEmail}
                        onChange={(e) => setNominatorEmail(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2.5 text-xs text-white"
                      />
                    </div>
                  </div>
                </div>

                {/* ACTION BUTTONS */}
                <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-4 border-t border-slate-800">
                  <button
                    type="button"
                    onClick={handleSaveDraftLocally}
                    className="w-full sm:w-auto px-5 py-3 rounded-xl bg-slate-800 hover:bg-slate-750 border border-slate-700 text-slate-200 text-xs font-semibold flex items-center justify-center space-x-2 transition cursor-pointer"
                  >
                    <Save className="w-4 h-4 text-amber-400" />
                    <span>Save as Draft (Local)</span>
                  </button>

                  <div className="flex items-center space-x-3 w-full sm:w-auto">
                    <button
                      type="submit"
                      disabled={isSubmitting}
                      className="w-full sm:w-auto px-8 py-3.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-bold text-sm tracking-wide shadow-xl shadow-amber-500/20 transition flex items-center justify-center space-x-2 cursor-pointer"
                    >
                      {isSubmitting ? (
                        <span>Submitting to CSCPO Ledger...</span>
                      ) : (
                        <>
                          <Send className="w-4 h-4" />
                          <span>Submit Official Nomination</span>
                        </>
                      )}
                    </button>
                  </div>
                </div>
              </form>
            )}
          </div>
        )}

        {/* TAB 2: TRACK NOMINATION STATUS */}
        {activeTab === "TRACK" && (
          <div className="bg-slate-900/80 border border-slate-800 rounded-3xl p-6 sm:p-10 shadow-2xl backdrop-blur-md space-y-8 max-w-2xl mx-auto">
            <div className="text-center space-y-2">
              <h3 className="text-xl font-bold text-white">Track Nomination Status</h3>
              <p className="text-xs text-slate-400">
                Enter your unique Nomination Reference Number (e.g. <code>CSCPO-N1001</code>) and email to check jury screening progress.
              </p>
            </div>

            <form onSubmit={handleTrackSubmit} className="space-y-4">
              {trackError && (
                <div className="p-3 bg-red-950/60 border border-red-500/40 rounded-xl text-red-200 text-xs flex items-center space-x-2">
                  <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
                  <span>{trackError}</span>
                </div>
              )}

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  Nomination Reference Number
                </label>
                <input
                  type="text"
                  placeholder="e.g. CSCPO-N1001"
                  value={trackRefNumber}
                  onChange={(e) => setTrackRefNumber(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-3 text-sm text-white font-mono uppercase focus:outline-none focus:border-amber-500"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  Nominee / Nominator Email Address
                </label>
                <input
                  type="email"
                  placeholder="name@company.com"
                  value={trackEmail}
                  onChange={(e) => setTrackEmail(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:border-amber-500"
                  required
                />
              </div>

              <button
                type="submit"
                disabled={isTracking}
                className="w-full py-3.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-sm transition flex items-center justify-center space-x-2 cursor-pointer"
              >
                {isTracking ? <span>Checking CSCPO Ledger...</span> : <span>Track Application Status</span>}
              </button>
            </form>

            {/* Tracked Result Display */}
            {trackedNomination && (
              <div className="mt-6 p-5 bg-slate-950 border border-slate-800 rounded-2xl space-y-4 animate-fade-in">
                <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                  <div>
                    <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">
                      Reference Code
                    </span>
                    <h4 className="text-base font-mono font-bold text-amber-400">
                      {trackedNomination.refNumber}
                    </h4>
                  </div>
                  <div>
                    {trackedNomination.status === "APPROVED" && (
                      <span className="px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-xs font-bold">
                        ✓ Approved for Public Voting
                      </span>
                    )}
                    {trackedNomination.status === "PENDING" && (
                      <span className="px-3 py-1 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30 text-xs font-bold">
                        ⏳ Under Jury Review
                      </span>
                    )}
                    {trackedNomination.status === "REJECTED" && (
                      <span className="px-3 py-1 rounded-full bg-red-500/20 text-red-300 border border-red-500/30 text-xs font-bold">
                        ✕ Not Approved
                      </span>
                    )}
                  </div>
                </div>

                <div className="space-y-2 text-xs">
                  <div className="flex justify-between">
                    <span className="text-slate-400">Nominee Name:</span>
                    <span className="text-white font-bold">{trackedNomination.name}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Organization:</span>
                    <span className="text-slate-200">{trackedNomination.organization}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Category:</span>
                    <span className="text-amber-300 font-medium">{trackedNomination.categoryName}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Submission Date:</span>
                    <span className="text-slate-300">
                      {new Date(trackedNomination.createdAt).toLocaleDateString()}
                    </span>
                  </div>
                </div>

                {trackedNomination.status === "APPROVED" && (
                  <div className="pt-3 border-t border-slate-800 flex items-center justify-between">
                    <span className="text-xs text-slate-400">
                      Live Votes: <strong className="text-amber-400">#{trackedNomination.voteCount}</strong>
                    </span>
                    <Link
                      href={`/nominee/${trackedNomination.slug}`}
                      className="px-3.5 py-1.5 rounded-lg bg-amber-500 text-slate-950 font-bold text-xs flex items-center space-x-1"
                    >
                      <span>View Voting Profile</span>
                      <ExternalLink className="w-3.5 h-3.5" />
                    </Link>
                  </div>
                )}

                {trackedNomination.status === "REJECTED" && (
                  <div className="p-3 bg-red-950/40 border border-red-500/30 rounded-xl text-xs text-red-300 space-y-1">
                    <div className="font-bold">Jury Evaluation Feedback:</div>
                    <p>{trackedNomination.rejectionReason || "Incomplete documentation or category mismatch."}</p>
                  </div>
                )}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
