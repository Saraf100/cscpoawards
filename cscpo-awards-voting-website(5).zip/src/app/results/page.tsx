"use client";

import React, { useState, useEffect } from "react";
import Link from "next/link";
import {
  BarChart3,
  ShieldCheck,
  TrendingUp,
  Award,
  Users,
  Vote,
  Globe,
  Clock,
  CheckCircle2,
  Download,
  RefreshCw,
  ExternalLink,
  ChevronRight,
  Lock,
} from "lucide-react";

export default function ResultsPage() {
  const [stats, setStats] = useState<any | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [selectedCategory, setSelectedCategory] = useState<string>("all");

  const fetchStats = async () => {
    try {
      setIsLoading(true);
      const res = await fetch("/api/votes/stats");
      const data = await res.json();
      if (data.success) {
        setStats(data.data);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchStats();
    // Auto refresh every 30 seconds
    const interval = setInterval(fetchStats, 30000);
    return () => clearInterval(interval);
  }, []);

  if (isLoading && !stats) {
    return (
      <div className="min-h-screen bg-slate-950 text-slate-100 flex items-center justify-center">
        <div className="flex flex-col items-center space-y-3">
          <div className="w-10 h-10 border-4 border-amber-500 border-t-transparent rounded-full animate-spin" />
          <p className="text-xs text-slate-400">Loading Live Transparency Ledger...</p>
        </div>
      </div>
    );
  }

  const categoryStats = stats?.categoryStats || [];
  const countryStats = stats?.countryStats || [];
  const recentVotes = stats?.recentVotes || [];

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 py-10">
      <div className="container mx-auto px-4 max-w-6xl space-y-10">
        {/* Header & Status */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 pb-6 border-b border-slate-800">
          <div className="space-y-2">
            <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/20 text-amber-300 text-xs font-semibold">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
              <span>Cryptographic Transparency Ledger</span>
            </div>
            <h1 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
              Voting Transparency & Results Dashboard
            </h1>
            <p className="text-sm text-slate-400 max-w-2xl">
              Real-time aggregated results for the CSCPO South Asian Leadership Awards. All votes are audited,
              duplicate-checked, and recorded with cryptographic timestamps.
            </p>
          </div>

          <div className="flex flex-col items-start md:items-end space-y-2">
            <div className="flex items-center space-x-2 text-[11px] text-slate-400">
              <Clock className="w-3.5 h-3.5 text-amber-400" />
              <span>Last updated: {stats?.lastUpdated ? new Date(stats.lastUpdated).toLocaleTimeString() : "Live"}</span>
              <button
                onClick={fetchStats}
                title="Refresh stats"
                className="p-1 hover:text-white rounded"
              >
                <RefreshCw className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>

        {/* 4 PRIMARY METRIC CARDS */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="p-5 bg-gradient-to-b from-slate-900 to-slate-950 border border-slate-800 rounded-2xl space-y-1">
            <div className="flex items-center justify-between text-slate-400 text-xs font-medium">
              <span>Approved Nominees</span>
              <Award className="w-4 h-4 text-amber-400" />
            </div>
            <div className="text-3xl font-extrabold text-white tracking-tight">
              #{stats?.totalNominees || 0}
            </div>
            <div className="text-[10px] text-emerald-400 font-medium">Jury Screened Finalists</div>
          </div>

          <div className="p-5 bg-gradient-to-b from-slate-900 to-slate-950 border border-slate-800 rounded-2xl space-y-1">
            <div className="flex items-center justify-between text-slate-400 text-xs font-medium">
              <span>Total Votes Cast</span>
              <Vote className="w-4 h-4 text-amber-400" />
            </div>
            <div className="text-3xl font-extrabold text-amber-400 tracking-tight">
              #{Number(stats?.totalVotes || 0).toLocaleString()}
            </div>
            <div className="text-[10px] text-slate-400 font-medium">Certified Public Votes</div>
          </div>

          <div className="p-5 bg-gradient-to-b from-slate-900 to-slate-950 border border-slate-800 rounded-2xl space-y-1">
            <div className="flex items-center justify-between text-slate-400 text-xs font-medium">
              <span>Authenticated Voter Accounts</span>
              <Users className="w-4 h-4 text-emerald-400" />
            </div>
            <div className="text-3xl font-extrabold text-emerald-400 tracking-tight">
              #{stats?.verifiedVoters || 0}
            </div>
            <div className="text-[10px] text-slate-400 font-medium">Account access verified; not government ID verification</div>
          </div>

          <div className="p-5 bg-gradient-to-b from-slate-900 to-slate-950 border border-slate-800 rounded-2xl space-y-1">
            <div className="flex items-center justify-between text-slate-400 text-xs font-medium">
              <span>Award Categories</span>
              <TrendingUp className="w-4 h-4 text-blue-400" />
            </div>
            <div className="text-3xl font-extrabold text-blue-400 tracking-tight">
              #{stats?.totalCategories || 0}
            </div>
            <div className="text-[10px] text-slate-400 font-medium">Active Competitions</div>
          </div>
        </div>

        {/* CATEGORY-WISE VOTING PROGRESS BREAKDOWN */}
        <div className="bg-slate-900/60 border border-slate-800 p-6 sm:p-8 rounded-3xl space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-4">
            <div>
              <h3 className="text-lg font-bold text-white flex items-center space-x-2">
                <BarChart3 className="w-5 h-5 text-amber-400" />
                <span>Category-Wise Voting Distribution</span>
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                Breakdown of public votes cast across each specialized supply chain discipline.
              </p>
            </div>

            <Link
              href="/voting"
              className="text-xs text-amber-400 hover:underline flex items-center space-x-1"
            >
              <span>Vote in any category</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </Link>
          </div>

          <div className="space-y-4">
            {categoryStats.map((cat: any) => (
              <div key={cat.id} className="space-y-1.5 p-3.5 bg-slate-950/70 border border-slate-800 rounded-2xl">
                <div className="flex items-center justify-between text-xs">
                  <div className="font-bold text-slate-200 flex items-center space-x-2">
                    <span>{cat.name}</span>
                    <span className="text-[10px] text-slate-400 font-normal">
                      ({cat.nomineeCount} nominees)
                    </span>
                  </div>
                  <div className="flex items-center space-x-3">
                    <span className="font-bold text-amber-400">#{cat.totalVotes.toLocaleString()} votes</span>
                    <span className="text-slate-400 font-mono text-[11px] min-w-[36px] text-right">
                      {cat.percentage}%
                    </span>
                  </div>
                </div>

                {/* Progress bar */}
                <div className="w-full h-2.5 bg-slate-800 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-amber-500 to-amber-400 rounded-full transition-all duration-700"
                    style={{ width: `${Math.max(5, cat.percentage)}%` }}
                  />
                </div>

                {/* Honored nominee callout */}
                {cat.topNominee && (
                  <div className="pt-1 flex items-center justify-between text-[11px] text-slate-400">
                    <div className="flex items-center space-x-1.5 truncate">
                      <span className="text-amber-400 font-semibold">★ Honored Finalist:</span>
                      <span className="text-slate-300 font-medium truncate">{cat.topNominee.name}</span>
                      <span className="text-slate-500">({cat.topNominee.organization})</span>
                    </div>
                    <span className="text-amber-400 font-medium shrink-0">
                      {cat.topNominee.votes.toLocaleString()} votes
                    </span>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* COUNTRY-WISE STATS & RECENT VOTING FEED */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* Country Participation */}
          <div className="lg:col-span-6 bg-slate-900/60 border border-slate-800 p-6 rounded-3xl space-y-4">
            <h3 className="text-base font-bold text-white flex items-center space-x-2">
              <Globe className="w-4 h-4 text-blue-400" />
              <span>South Asian Country Participation</span>
            </h3>

            <div className="space-y-3">
              {countryStats.map((c: any, idx: number) => (
                <div
                  key={idx}
                  className="p-3 bg-slate-950 border border-slate-800 rounded-xl flex items-center justify-between text-xs"
                >
                  <div className="flex items-center space-x-2.5">
                    <span className="w-6 h-6 rounded-full bg-slate-800 flex items-center justify-center font-bold text-[10px] text-amber-400">
                      0{idx + 1}
                    </span>
                    <div>
                      <div className="font-bold text-slate-200">{c.country}</div>
                      <div className="text-[10px] text-slate-400">{c.nominees} Finalists</div>
                    </div>
                  </div>

                  <div className="text-right">
                    <div className="font-extrabold text-amber-400">#{c.votes.toLocaleString()} votes</div>
                    <div className="text-[10px] text-slate-500">{c.percentage}% share</div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Anonymized Live Audit Feed */}
          <div className="lg:col-span-6 bg-slate-900/60 border border-slate-800 p-6 rounded-3xl space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-bold text-white flex items-center space-x-2">
                <Lock className="w-4 h-4 text-emerald-400" />
                <span>Live Audit Ledger Feed</span>
              </h3>
              <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                Confidential Voter IDs
              </span>
            </div>

            <p className="text-xs text-slate-400">
              Individual voter personal identities remain strictly confidential in accordance with international privacy
              laws. Anonymized cryptographic proofs are published below:
            </p>

            <div className="space-y-2 max-h-80 overflow-y-auto no-scrollbar">
              {recentVotes.map((v: any) => (
                <div
                  key={v.id}
                  className="p-2.5 bg-slate-950 border border-slate-800/80 rounded-xl flex items-center justify-between text-xs"
                >
                  <div className="space-y-0.5 truncate pr-2">
                    <div className="text-slate-200 font-medium truncate">
                      Vote cast for <span className="text-amber-400 font-bold">{v.nomineeName}</span>
                    </div>
                    <div className="text-[10px] text-slate-500 truncate">
                      Category: {v.categoryName} · {v.country}
                    </div>
                  </div>
                  <div className="text-right shrink-0">
                    <span className="text-[10px] font-mono text-emerald-400 block">
                      ✓ {v.method}
                    </span>
                    <span className="text-[9px] text-slate-500">
                      {new Date(v.timestamp).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* OFFICIAL JURY CERTIFICATION NOTICE */}
        <div className="p-6 bg-slate-900/40 border border-slate-800 rounded-3xl flex flex-col md:flex-row items-center justify-between gap-4 text-xs text-slate-400">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-full bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 shrink-0">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h4 className="font-bold text-white text-sm">Official Result Certification Protocol</h4>
              <p className="mt-0.5">
                Public voting contributes to the final award score alongside independent assessments by the CSCPO
                Distinguished Advisory Jury.
              </p>
            </div>
          </div>

          <a
            href="/api/admin/export?type=nominees"
            className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-750 border border-slate-700 text-slate-200 text-xs font-semibold flex items-center space-x-1.5 shrink-0 transition"
          >
            <Download className="w-3.5 h-3.5 text-amber-400" />
            <span>Export Official Standings (CSV)</span>
          </a>
        </div>
      </div>
    </div>
  );
}
