import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { voters } from "@/db/schema";
import { eq } from "drizzle-orm";
import { readVoterSession, VOTER_SESSION_COOKIE } from "@/lib/voter-session";
import { createVoteChallenge } from "@/lib/vote-challenge";

export const dynamic = "force-dynamic";

export async function GET(request: NextRequest) {
  try {
    const session = readVoterSession(request.cookies.get(VOTER_SESSION_COOKIE)?.value);
    if (!session) {
      return NextResponse.json({ success: false, error: "Sign in before requesting a vote challenge." }, { status: 401 });
    }

    const [voter] = await db.select().from(voters).where(eq(voters.id, session.voterId)).limit(1);
    if (!voter || voter.status !== "ACTIVE" || voter.email !== session.email) {
      return NextResponse.json({ success: false, error: "Voter session is invalid or suspended." }, { status: 401 });
    }

    const challenge = createVoteChallenge(voter.id);
    return NextResponse.json({ success: true, data: challenge }, { headers: { "Cache-Control": "no-store" } });
  } catch (error) {
    console.error("Vote CAPTCHA generation error:", error);
    return NextResponse.json({ success: false, error: "Could not create a vote security challenge." }, { status: 500 });
  }
}
