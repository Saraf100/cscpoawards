import { NextResponse } from "next/server";
import { db } from "@/db";
import { nominees, voters, votes, categories, votingSettings } from "@/db/schema";
import { eq, sql, desc } from "drizzle-orm";
import { ensureSeeded } from "@/lib/seed";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    await ensureSeeded();

    const [settings] = await db.select().from(votingSettings).limit(1);

    // Nominees stats
    const approvedNominees = await db
      .select()
      .from(nominees)
      .where(eq(nominees.status, "APPROVED"))
      .orderBy(desc(nominees.voteCount));

    const totalApprovedNominees = approvedNominees.length;
    const totalVotes = approvedNominees.reduce((acc, curr) => acc + (curr.voteCount || 0), 0);

    // Voter stats: provider/email authentication is distinct from real-world identity verification.
    const allVoters = await db.select().from(voters);
    const totalVoters = allVoters.length;
    const verifiedVoters = allVoters.filter((v) => v.status === "ACTIVE").length;
    const identityVerifiedVoters = allVoters.filter((v) => v.isIdentityVerified && v.status === "ACTIVE").length;

    // Categories stats
    const allCategories = await db.select().from(categories).where(eq(categories.isActive, true));

    const categoryStats = allCategories.map((cat) => {
      const catNominees = approvedNominees.filter((n) => n.categoryId === cat.id);
      const catVotes = catNominees.reduce((acc, curr) => acc + (curr.voteCount || 0), 0);
      const topNominee = catNominees.length > 0 ? catNominees[0] : null;

      // Percentage of total votes
      const percentage = totalVotes > 0 ? Math.round((catVotes / totalVotes) * 100) : 0;

      return {
        id: cat.id,
        slug: cat.slug,
        name: cat.name,
        nameBn: cat.nameBn,
        nomineeCount: catNominees.length,
        totalVotes: catVotes,
        percentage,
        topNominee: topNominee
          ? {
              id: topNominee.id,
              name: topNominee.name,
              organization: topNominee.organization,
              votes: topNominee.voteCount,
              photoUrl: topNominee.photoUrl,
            }
          : null,
      };
    });

    // Country stats
    const countryMap = new Map<string, { votes: number; nominees: number }>();
    approvedNominees.forEach((n) => {
      const country = n.country || "Bangladesh";
      const existing = countryMap.get(country) || { votes: 0, nominees: 0 };
      countryMap.set(country, {
        votes: existing.votes + (n.voteCount || 0),
        nominees: existing.nominees + 1,
      });
    });

    const countryStats = Array.from(countryMap.entries()).map(([country, stat]) => ({
      country,
      nominees: stat.nominees,
      votes: stat.votes,
      percentage: totalVotes > 0 ? Math.round((stat.votes / totalVotes) * 100) : 0,
    }));

    // Recent cast votes (anonymized)
    const recentVotesRaw = await db
      .select({
        id: votes.id,
        verificationMethod: votes.verificationMethod,
        createdAt: votes.createdAt,
        categoryId: votes.categoryId,
        nomineeId: votes.nomineeId,
      })
      .from(votes)
      .where(eq(votes.isValid, true))
      .orderBy(desc(votes.createdAt))
      .limit(8);

    const recentVotes = recentVotesRaw.map((v) => {
      const matchingNominee = approvedNominees.find((n) => n.id === v.nomineeId);
      return {
        id: v.id,
        method: v.verificationMethod,
        timestamp: v.createdAt,
        nomineeName: matchingNominee ? matchingNominee.name : "South Asian Leader",
        categoryName: matchingNominee?.categoryName || "Leadership Award",
        country: matchingNominee?.country || "South Asia",
      };
    });

    return NextResponse.json({
      success: true,
      data: {
        totalNominees: totalApprovedNominees,
        totalVotes,
        totalVoters,
        verifiedVoters,
        identityVerifiedVoters,
        totalCategories: allCategories.length,
        votingStatus: settings?.votingStatus || "OPEN",
        votingStartDate: settings?.votingStartDate,
        votingEndDate: settings?.votingEndDate,
        votingPolicy: settings?.votingPolicy || "ONE_VOTE_PER_CATEGORY",
        showPublicCounts: settings?.showPublicCounts ?? true,
        showPublicRankings: settings?.showPublicRankings ?? true,
        categoryStats,
        countryStats,
        recentVotes,
        lastUpdated: new Date().toISOString(),
      },
    });
  } catch (error) {
    console.error("Error computing voting stats:", error);
    return NextResponse.json({ success: false, error: "Failed to compute stats" }, { status: 500 });
  }
}
