import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { voters, votes, nominees, votingSettings, notificationsLog } from "@/db/schema";
import { eq, and, sql } from "drizzle-orm";
import { ensureSeeded } from "@/lib/seed";
import { readVoterSession, VOTER_SESSION_COOKIE } from "@/lib/voter-session";
import { verifyVoteChallenge } from "@/lib/vote-challenge";

export const dynamic = "force-dynamic";

export async function POST(request: NextRequest) {
  try {
    await ensureSeeded();
    const body = await request.json();
    const { nomineeId, captchaAnswer, captchaToken, deviceFingerprint } = body;

    if (!nomineeId) {
      return NextResponse.json({ success: false, error: "Nominee ID is required." }, { status: 400 });
    }

    const session = readVoterSession(request.cookies.get(VOTER_SESSION_COOKIE)?.value);
    if (!session) {
      return NextResponse.json({ success: false, error: "Please authenticate with Google, Facebook, or email OTP before voting." }, { status: 401 });
    }

    // 1. Check Voting Settings
    const [settings] = await db.select().from(votingSettings).limit(1);
    const now = new Date();

    if (settings) {
      if (settings.votingStatus === "CLOSED") {
        return NextResponse.json({ success: false, error: "Voting is officially closed for this season." }, { status: 403 });
      }
      if (settings.votingStatus === "PAUSED") {
        return NextResponse.json({ success: false, error: "Voting is temporarily paused for jury calibration." }, { status: 403 });
      }
      if (settings.votingStartDate && now < new Date(settings.votingStartDate)) {
        return NextResponse.json({ success: false, error: "Voting has not started yet." }, { status: 403 });
      }
      if (settings.votingEndDate && now > new Date(settings.votingEndDate)) {
        return NextResponse.json({ success: false, error: "Voting deadline has passed." }, { status: 403 });
      }
      // Verify the signed challenge generated for this exact authenticated voter.
      if (settings.requireCaptcha && !verifyVoteChallenge(captchaToken, captchaAnswer, session)) {
        return NextResponse.json({ success: false, error: "Security challenge expired or incorrect. Refresh it and try again." }, { status: 400 });
      }
    }

    // 2. Lookup Nominee
    const [nominee] = await db.select().from(nominees).where(eq(nominees.id, Number(nomineeId))).limit(1);
    if (!nominee) {
      return NextResponse.json({ success: false, error: "Nominee not found." }, { status: 404 });
    }
    if (nominee.status !== "APPROVED") {
      return NextResponse.json({ success: false, error: "This nominee is not currently approved for public voting." }, { status: 400 });
    }

    // Resolve the voter only from the signed, HTTP-only server session.
    const [voter] = await db.select().from(voters).where(eq(voters.id, session.voterId)).limit(1);
    if (!voter || voter.email !== session.email || voter.status !== "ACTIVE") {
      return NextResponse.json(
        { success: false, error: "Your voter session is invalid or suspended. Please authenticate again." },
        { status: 401 }
      );
    }
    const email = voter.email;
    const authProvider = voter.authProvider;

    // Extract headers for IP & User Agent
    const ipAddress = request.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ||
      request.headers.get("x-real-ip") ||
      "unknown";
    const userAgent = request.headers.get("user-agent") || "Web Browser";

    // 4. Policy check
    const policy = settings?.votingPolicy || "ONE_VOTE_PER_CATEGORY";

    if (policy === "ONE_VOTE_PER_CATEGORY" && nominee.categoryId) {
      const [existingCategoryVote] = await db
        .select()
        .from(votes)
        .where(
          and(
            eq(votes.voterId, voter.id),
            eq(votes.categoryId, nominee.categoryId),
            eq(votes.isValid, true)
          )
        )
        .limit(1);

      if (existingCategoryVote) {
        return NextResponse.json(
          {
            success: false,
            error: `You have already cast your vote in the '${nominee.categoryName || "selected"}' category. Each verified voter is entitled to one vote per award category.`,
          },
          { status: 409 }
        );
      }
    } else if (policy === "ONE_VOTE_PER_NOMINEE") {
      const [existingNomineeVote] = await db
        .select()
        .from(votes)
        .where(
          and(
            eq(votes.voterId, voter.id),
            eq(votes.nomineeId, nominee.id),
            eq(votes.isValid, true)
          )
        )
        .limit(1);

      if (existingNomineeVote) {
        return NextResponse.json(
          {
            success: false,
            error: `You have already voted for ${nominee.name}. Under this policy, one vote per nominee is permitted.`,
          },
          { status: 409 }
        );
      }
    } else if (policy === "ONE_VOTE_OVERALL") {
      const [anyVote] = await db
        .select()
        .from(votes)
        .where(and(eq(votes.voterId, voter.id), eq(votes.isValid, true)))
        .limit(1);

      if (anyVote) {
        return NextResponse.json(
          {
            success: false,
            error: "You have already cast your single permitted vote in this awards season.",
          },
          { status: 409 }
        );
      }
    }

    // 5. Anti-Fraud heuristics
    let isFraud = false;
    let fraudReason = null;

    // Check recent votes from same IP within 1 hour
    const [ipVoteCountResult] = await db
      .select({ count: sql<number>`count(*)` })
      .from(votes)
      .where(
        and(
          eq(votes.ipAddress, ipAddress),
          sql`${votes.createdAt} > NOW() - INTERVAL '1 hour'`
        )
      );

    if (ipVoteCountResult && Number(ipVoteCountResult.count) > 25) {
      isFraud = true;
      fraudReason = `High velocity IP burst: ${ipVoteCountResult.count} votes in the last hour from IP ${ipAddress}`;
    }

    // 6. Record the Vote
    const [castVote] = await db
      .insert(votes)
      .values({
        voterId: voter.id,
        nomineeId: nominee.id,
        categoryId: nominee.categoryId || 1,
        voterEmail: email,
        ipAddress,
        userAgent,
        deviceFingerprint: deviceFingerprint || null,
        verificationMethod: authProvider || "EMAIL_OTP",
        isFraud,
        fraudReason,
        isValid: !isFraud,
      })
      .returning();

    // 7. Increment nominee vote count (if valid)
    let updatedNomineeVoteCount = nominee.voteCount;
    if (!isFraud) {
      const [updatedNominee] = await db
        .update(nominees)
        .set({
          voteCount: sql`${nominees.voteCount} + 1`,
          updatedAt: new Date(),
        })
        .where(eq(nominees.id, nominee.id))
        .returning();
      updatedNomineeVoteCount = updatedNominee.voteCount;

      await db
        .update(voters)
        .set({
          voteCountTotal: sql`${voters.voteCountTotal} + 1`,
          lastVotedAt: new Date(),
        })
        .where(eq(voters.id, voter.id));
    }

    // 8. Log voter receipt notification
    const receiptCode = `CSCPO-VOTE-${castVote.id}-${Date.now().toString(36).toUpperCase()}`;
    await db.insert(notificationsLog).values({
      recipientEmail: email,
      recipientName: voter.name,
      subject: `CSCPO Awards: Official Voting Confirmation Receipt [${receiptCode}]`,
      type: "VOTE_CONFIRMATION",
      body: `Thank you for casting your verified vote for ${nominee.name} in '${nominee.categoryName}'.\n\nTransaction ID: ${receiptCode}\nTimestamp: ${new Date().toISOString()}\nVerification Method: ${authProvider || "Verified Social/OTP"}\n\nYour vote has been certified into the CSCPO South Asian Leadership Awards Ledger.`,
      status: "DELIVERED",
    });

    return NextResponse.json({
      success: true,
      message: `Your verified vote for ${nominee.name} has been recorded successfully!`,
      data: {
        voteId: castVote.id,
        receiptCode,
        nomineeId: nominee.id,
        nomineeName: nominee.name,
        newVoteCount: updatedNomineeVoteCount,
        categoryName: nominee.categoryName,
        timestamp: castVote.createdAt,
      },
    });
  } catch (error) {
    console.error("Error casting vote:", error);
    return NextResponse.json({ success: false, error: "Failed to record vote: " + String(error) }, { status: 500 });
  }
}
