import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { voters, votes, votingSettings, nominees } from "@/db/schema";
import { eq, and } from "drizzle-orm";
import { readVoterSession, VOTER_SESSION_COOKIE } from "@/lib/voter-session";
import { ensureSeeded } from "@/lib/seed";

export const dynamic = "force-dynamic";

export async function GET(request: NextRequest) {
  try {
    await ensureSeeded();
    const session = readVoterSession(request.cookies.get(VOTER_SESSION_COOKIE)?.value);
    if (!session) {
      return NextResponse.json({ success: true, eligible: true, authenticated: false });
    }

    const nomineeId = Number(new URL(request.url).searchParams.get("nomineeId"));
    if (!Number.isInteger(nomineeId) || nomineeId <= 0) {
      return NextResponse.json({ success: false, error: "A valid nomineeId is required." }, { status: 400 });
    }

    const [voter] = await db.select().from(voters).where(eq(voters.id, session.voterId)).limit(1);
    if (!voter || voter.status !== "ACTIVE" || voter.email !== session.email) {
      return NextResponse.json({ success: false, authenticated: false, error: "Voter session is invalid. Please sign in again." }, { status: 401 });
    }

    const [nominee] = await db.select().from(nominees).where(eq(nominees.id, nomineeId)).limit(1);
    if (!nominee || nominee.status !== "APPROVED") {
      return NextResponse.json({ success: false, error: "Nominee is not available for public voting." }, { status: 404 });
    }

    const [settings] = await db.select().from(votingSettings).limit(1);
    const policy = settings?.votingPolicy || "ONE_VOTE_PER_CATEGORY";
    let existingVote;

    if (policy === "ONE_VOTE_PER_CATEGORY" && nominee.categoryId) {
      [existingVote] = await db
        .select({ nomineeId: votes.nomineeId })
        .from(votes)
        .where(and(eq(votes.voterId, voter.id), eq(votes.categoryId, nominee.categoryId), eq(votes.isValid, true)))
        .limit(1);
    } else if (policy === "ONE_VOTE_PER_NOMINEE") {
      [existingVote] = await db
        .select({ nomineeId: votes.nomineeId })
        .from(votes)
        .where(and(eq(votes.voterId, voter.id), eq(votes.nomineeId, nominee.id), eq(votes.isValid, true)))
        .limit(1);
    } else if (policy === "ONE_VOTE_OVERALL") {
      [existingVote] = await db
        .select({ nomineeId: votes.nomineeId })
        .from(votes)
        .where(and(eq(votes.voterId, voter.id), eq(votes.isValid, true)))
        .limit(1);
    }

    return NextResponse.json({
      success: true,
      authenticated: true,
      eligible: !existingVote,
      votedNomineeId: existingVote?.nomineeId ?? null,
      reason: existingVote ? "This verified account has already voted under the current award policy." : null,
    });
  } catch (error) {
    console.error("Error checking vote eligibility:", error);
    return NextResponse.json({ success: false, error: "Failed to check vote eligibility" }, { status: 500 });
  }
}
