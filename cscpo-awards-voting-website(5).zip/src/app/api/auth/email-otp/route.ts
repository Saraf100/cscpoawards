import { createHmac, randomInt, timingSafeEqual } from "node:crypto";
import { NextRequest, NextResponse } from "next/server";
import { and, desc, eq, gt, isNull } from "drizzle-orm";
import { db } from "@/db";
import { emailOtpRequests, voters } from "@/db/schema";
import { createVoterSession, getVoterSessionSecret, VOTER_SESSION_COOKIE, voterSessionCookieOptions } from "@/lib/voter-session";

export const dynamic = "force-dynamic";

const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

function hashOtp(email: string, code: string) {
  return createHmac("sha256", getVoterSessionSecret())
    .update(`${email.toLowerCase()}:${code}`)
    .digest("hex");
}

function sameHex(left: string, right: string) {
  const a = Buffer.from(left, "hex");
  const b = Buffer.from(right, "hex");
  return a.length === b.length && timingSafeEqual(a, b);
}

function getRequestIp(request: NextRequest) {
  return request.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ||
    request.headers.get("x-real-ip") ||
    "unknown";
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const action = String(body.action || "");
    const email = String(body.email || "").trim().toLowerCase();
    const name = String(body.name || "").trim().slice(0, 255) || email.split("@")[0];

    if (!emailPattern.test(email)) {
      return NextResponse.json({ success: false, error: "Enter a valid email address." }, { status: 400 });
    }

    if (action === "send") {
      const resendApiKey = process.env.RESEND_API_KEY;
      const fromAddress = process.env.RESEND_FROM_EMAIL;
      const developmentDemo = process.env.NODE_ENV !== "production";

      if ((!resendApiKey || !fromAddress) && !developmentDemo) {
        return NextResponse.json(
          {
            success: false,
            error: "Email OTP is not configured yet. The organizer must set RESEND_API_KEY and RESEND_FROM_EMAIL on the production Node.js host.",
          },
          { status: 503 }
        );
      }

      const now = new Date();
      const recentRequests = await db
        .select()
        .from(emailOtpRequests)
        .where(eq(emailOtpRequests.email, email))
        .orderBy(desc(emailOtpRequests.createdAt))
        .limit(10);
      const lastMinute = recentRequests.find((item) => now.getTime() - item.createdAt.getTime() < 60_000);
      const lastHourCount = recentRequests.filter((item) => now.getTime() - item.createdAt.getTime() < 60 * 60_000).length;

      if (lastMinute) {
        return NextResponse.json(
          { success: false, error: "Please wait one minute before requesting another verification code." },
          { status: 429 }
        );
      }
      if (lastHourCount >= 5) {
        return NextResponse.json(
          { success: false, error: "Too many verification code requests. Try again in an hour." },
          { status: 429 }
        );
      }

      const code = String(randomInt(100000, 1_000_000));
      const expiresAt = new Date(now.getTime() + 10 * 60_000);

      await db
        .update(emailOtpRequests)
        .set({ consumedAt: now })
        .where(and(eq(emailOtpRequests.email, email), isNull(emailOtpRequests.consumedAt)));

      const [otpRequest] = await db
        .insert(emailOtpRequests)
        .values({
          email,
          name,
          codeHash: hashOtp(email, code),
          requestedIp: getRequestIp(request),
          expiresAt,
          attempts: 0,
        })
        .returning();

      if (resendApiKey && fromAddress) {
        const mailResponse = await fetch("https://api.resend.com/emails", {
          method: "POST",
          headers: {
            Authorization: `Bearer ${resendApiKey}`,
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            from: fromAddress,
            to: [email],
            subject: "Your CSCPO Awards voter verification code",
            text: `Your CSCPO Awards verification code is ${code}. It expires in 10 minutes. If you did not request this code, you can ignore this email.`,
          }),
        });

        if (!mailResponse.ok) {
          await db
            .update(emailOtpRequests)
            .set({ consumedAt: new Date() })
            .where(eq(emailOtpRequests.id, otpRequest.id));
          const responseBody = await mailResponse.text();
          console.error("Resend delivery failed:", mailResponse.status, responseBody);
          return NextResponse.json(
            { success: false, error: "We could not deliver the verification email. Please try again or contact the organizer." },
            { status: 502 }
          );
        }
      }

      return NextResponse.json({
        success: true,
        expiresInSeconds: 600,
        message: `A verification code was sent to ${email}.`,
        ...(developmentDemo ? { demoCode: code } : {}),
      });
    }

    if (action === "verify") {
      const code = String(body.code || "").trim();
      if (!/^\d{6}$/.test(code)) {
        return NextResponse.json({ success: false, error: "Enter the six-digit verification code." }, { status: 400 });
      }

      const now = new Date();
      const [otp] = await db
        .select()
        .from(emailOtpRequests)
        .where(
          and(
            eq(emailOtpRequests.email, email),
            isNull(emailOtpRequests.consumedAt),
            gt(emailOtpRequests.expiresAt, now)
          )
        )
        .orderBy(desc(emailOtpRequests.createdAt))
        .limit(1);

      if (!otp || otp.attempts >= 5) {
        return NextResponse.json(
          { success: false, error: "That code is expired or unavailable. Request a new verification code." },
          { status: 400 }
        );
      }

      if (!sameHex(hashOtp(email, code), otp.codeHash)) {
        const nextAttempts = otp.attempts + 1;
        await db
          .update(emailOtpRequests)
          .set({ attempts: nextAttempts, ...(nextAttempts >= 5 ? { consumedAt: now } : {}) })
          .where(eq(emailOtpRequests.id, otp.id));
        return NextResponse.json(
          { success: false, error: nextAttempts >= 5 ? "Too many incorrect attempts. Request a new code." : "That code is incorrect. Check the email and try again." },
          { status: 400 }
        );
      }

      await db.update(emailOtpRequests).set({ consumedAt: now }).where(eq(emailOtpRequests.id, otp.id));

      let [voter] = await db.select().from(voters).where(eq(voters.email, email)).limit(1);
      if (voter?.status === "SUSPENDED") {
        return NextResponse.json({ success: false, error: "This voter account is suspended. Please contact the awards organizer." }, { status: 403 });
      }

      if (!voter) {
        const [created] = await db
          .insert(voters)
          .values({
            email,
            name: name || otp.name,
            authProvider: "EMAIL_OTP",
            country: "Bangladesh",
            isIdentityVerified: false,
            ipAddress: getRequestIp(request),
            userAgent: request.headers.get("user-agent") || "Web Browser",
            status: "ACTIVE",
            voteCountTotal: 0,
          })
          .returning();
        voter = created;
      } else {
        const [updated] = await db
          .update(voters)
          .set({
            name: name || otp.name || voter.name,
            authProvider: "EMAIL_OTP",
            lastVotedAt: voter.lastVotedAt,
            ipAddress: getRequestIp(request),
            userAgent: request.headers.get("user-agent") || "Web Browser",
          })
          .where(eq(voters.id, voter.id))
          .returning();
        voter = updated;
      }

      const token = createVoterSession({
        voterId: voter.id,
        email: voter.email,
        name: voter.name,
        authProvider: "EMAIL_OTP",
        country: voter.country || "Bangladesh",
      });
      const response = NextResponse.json({
        success: true,
        voter: {
          id: voter.id,
          email: voter.email,
          name: voter.name,
          authProvider: "EMAIL_OTP",
          country: voter.country || "Bangladesh",
          isIdentityVerified: false,
          status: voter.status,
          voteCountTotal: voter.voteCountTotal,
        },
      });
      response.cookies.set(VOTER_SESSION_COOKIE, token, voterSessionCookieOptions());
      return response;
    }

    return NextResponse.json({ success: false, error: "Unsupported OTP action." }, { status: 400 });
  } catch (error) {
    console.error("Email OTP error:", error);
    return NextResponse.json({ success: false, error: "Email verification is temporarily unavailable." }, { status: 500 });
  }
}
