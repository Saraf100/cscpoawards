import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { voters } from "@/db/schema";
import { eq } from "drizzle-orm";
import { readVoterSession, VOTER_SESSION_COOKIE } from "@/lib/voter-session";

export const dynamic = "force-dynamic";

export async function GET(request: NextRequest) {
  try {
    const token = request.cookies.get(VOTER_SESSION_COOKIE)?.value;
    const session = readVoterSession(token);
    if (!session) {
      return NextResponse.json({ success: true, authenticated: false, voter: null });
    }

    const [voter] = await db.select().from(voters).where(eq(voters.id, session.voterId)).limit(1);
    if (!voter || voter.status !== "ACTIVE" || voter.email !== session.email) {
      const response = NextResponse.json({ success: true, authenticated: false, voter: null });
      response.cookies.delete(VOTER_SESSION_COOKIE);
      return response;
    }

    return NextResponse.json({
      success: true,
      authenticated: true,
      voter: {
        id: voter.id,
        email: voter.email,
        name: voter.name,
        authProvider: voter.authProvider,
        avatarUrl: voter.avatarUrl,
        phone: voter.phone,
        country: voter.country || "Bangladesh",
        isIdentityVerified: voter.isIdentityVerified,
        status: voter.status,
        voteCountTotal: voter.voteCountTotal,
      },
    });
  } catch (error) {
    console.error("Voter session error:", error);
    return NextResponse.json({ success: false, authenticated: false, voter: null }, { status: 500 });
  }
}
