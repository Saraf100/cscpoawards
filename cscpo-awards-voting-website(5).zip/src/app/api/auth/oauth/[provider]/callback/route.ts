import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { voters } from "@/db/schema";
import { eq } from "drizzle-orm";
import { createVoterSession, VOTER_SESSION_COOKIE, voterSessionCookieOptions } from "@/lib/voter-session";

export const dynamic = "force-dynamic";

function safeReturnPath(value?: string) {
  if (!value || !value.startsWith("/") || value.startsWith("//")) return "/voting";
  return value;
}

function clearOAuthCookies(response: NextResponse, provider: string) {
  const options = {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax" as const,
    path: `/api/auth/oauth/${provider}/callback`,
    maxAge: 0,
  };
  response.cookies.set(`cscpo_oauth_state_${provider}`, "", options);
  response.cookies.set(`cscpo_oauth_return_${provider}`, "", options);
}

async function fail(request: NextRequest, provider: string, code: string) {
  const baseUrl = (process.env.PUBLIC_APP_URL || request.nextUrl.origin).replace(/\/$/, "");
  const target = new URL("/voting", baseUrl);
  target.searchParams.set("authError", code);
  const response = NextResponse.redirect(target);
  clearOAuthCookies(response, provider);
  return response;
}

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ provider: string }> }
) {
  const { provider: rawProvider } = await params;
  const provider = rawProvider.toLowerCase();
  if (provider !== "google" && provider !== "facebook") {
    return NextResponse.json({ success: false, error: "Unsupported OAuth provider." }, { status: 404 });
  }

  const state = request.nextUrl.searchParams.get("state");
  const expectedState = request.cookies.get(`cscpo_oauth_state_${provider}`)?.value;
  const code = request.nextUrl.searchParams.get("code");
  const providerError = request.nextUrl.searchParams.get("error");

  if (providerError || !state || !expectedState || state !== expectedState || !code) {
    return fail(request, provider, providerError ? "social_login_cancelled" : "social_state_invalid");
  }

  try {
    const baseUrl = (process.env.PUBLIC_APP_URL || request.nextUrl.origin).replace(/\/$/, "");
    const redirectUri = `${baseUrl}/api/auth/oauth/${provider}/callback`;
    let profile: { id: string; email: string; name: string; avatarUrl?: string };

    if (provider === "google") {
      const clientId = process.env.GOOGLE_CLIENT_ID;
      const clientSecret = process.env.GOOGLE_CLIENT_SECRET;
      if (!clientId || !clientSecret) return fail(request, provider, "google_not_configured");

      const tokenResponse = await fetch("https://oauth2.googleapis.com/token", {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: new URLSearchParams({
          code,
          client_id: clientId,
          client_secret: clientSecret,
          redirect_uri: redirectUri,
          grant_type: "authorization_code",
        }),
        cache: "no-store",
      });
      if (!tokenResponse.ok) return fail(request, provider, "google_token_exchange_failed");
      const tokens = await tokenResponse.json();
      if (!tokens.access_token) return fail(request, provider, "google_token_missing");

      const userResponse = await fetch("https://openidconnect.googleapis.com/v1/userinfo", {
        headers: { Authorization: `Bearer ${tokens.access_token}` },
        cache: "no-store",
      });
      if (!userResponse.ok) return fail(request, provider, "google_profile_failed");
      const user = await userResponse.json();
      if (!user.email || user.email_verified !== true || !user.sub) {
        return fail(request, provider, "google_email_unverified");
      }
      profile = {
        id: String(user.sub),
        email: String(user.email).toLowerCase(),
        name: String(user.name || user.email),
        avatarUrl: user.picture ? String(user.picture) : undefined,
      };
    } else {
      const appId = process.env.FACEBOOK_APP_ID;
      const appSecret = process.env.FACEBOOK_APP_SECRET;
      if (!appId || !appSecret) return fail(request, provider, "facebook_not_configured");
      const version = process.env.FACEBOOK_GRAPH_VERSION || "v27.0";
      const tokenUrl = new URL(`https://graph.facebook.com/${version}/oauth/access_token`);
      tokenUrl.searchParams.set("client_id", appId);
      tokenUrl.searchParams.set("client_secret", appSecret);
      tokenUrl.searchParams.set("redirect_uri", redirectUri);
      tokenUrl.searchParams.set("code", code);

      const tokenResponse = await fetch(tokenUrl, { cache: "no-store" });
      if (!tokenResponse.ok) return fail(request, provider, "facebook_token_exchange_failed");
      const tokens = await tokenResponse.json();
      if (!tokens.access_token) return fail(request, provider, "facebook_token_missing");

      const userUrl = new URL(`https://graph.facebook.com/${version}/me`);
      userUrl.searchParams.set("fields", "id,name,email,picture.type(large)");
      userUrl.searchParams.set("access_token", String(tokens.access_token));
      const userResponse = await fetch(userUrl, { cache: "no-store" });
      if (!userResponse.ok) return fail(request, provider, "facebook_profile_failed");
      const user = await userResponse.json();
      if (!user.id || !user.email) {
        return fail(request, provider, "facebook_email_unavailable");
      }
      profile = {
        id: String(user.id),
        email: String(user.email).toLowerCase(),
        name: String(user.name || user.email),
        avatarUrl: user.picture?.data?.url ? String(user.picture.data.url) : undefined,
      };
    }

    let [voter] = await db.select().from(voters).where(eq(voters.email, profile.email)).limit(1);
    if (voter?.status === "SUSPENDED") {
      return fail(request, provider, "voter_suspended");
    }

    if (!voter) {
      const [created] = await db
        .insert(voters)
        .values({
          email: profile.email,
          name: profile.name,
          authProvider: provider.toUpperCase(),
          providerId: profile.id,
          avatarUrl: profile.avatarUrl || null,
          country: "Bangladesh",
          isIdentityVerified: false,
          ipAddress: request.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || request.headers.get("x-real-ip") || "unknown",
          userAgent: request.headers.get("user-agent") || "Web Browser",
          status: "ACTIVE",
          voteCountTotal: 0,
        })
        .returning();
      voter = created;
    } else {
      const [updated] = await db
        .update(voters)
        .set({
          name: profile.name,
          authProvider: provider.toUpperCase(),
          providerId: profile.id,
          avatarUrl: profile.avatarUrl || voter.avatarUrl,
          ipAddress: request.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || request.headers.get("x-real-ip") || voter.ipAddress,
          userAgent: request.headers.get("user-agent") || voter.userAgent,
        })
        .where(eq(voters.id, voter.id))
        .returning();
      voter = updated;
    }

    const token = createVoterSession({
      voterId: voter.id,
      email: voter.email,
      name: voter.name,
      authProvider: provider.toUpperCase() as "GOOGLE" | "FACEBOOK",
      country: voter.country || "Bangladesh",
    });

    const rawReturn = request.cookies.get(`cscpo_oauth_return_${provider}`)?.value;
    const returnPath = safeReturnPath(rawReturn ? decodeURIComponent(rawReturn) : undefined);
    const destination = new URL(returnPath, baseUrl);
    destination.searchParams.set("auth", "success");
    const response = NextResponse.redirect(destination);
    clearOAuthCookies(response, provider);
    response.cookies.set(VOTER_SESSION_COOKIE, token, voterSessionCookieOptions());
    return response;
  } catch (error) {
    console.error(`${provider} OAuth callback error:`, error);
    return fail(request, provider, "social_login_failed");
  }
}
