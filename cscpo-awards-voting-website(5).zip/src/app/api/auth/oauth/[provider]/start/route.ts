import { randomBytes } from "node:crypto";
import { NextRequest, NextResponse } from "next/server";

export const dynamic = "force-dynamic";

function safeReturnPath(value: string | null) {
  if (!value || !value.startsWith("/") || value.startsWith("//")) return "/voting";
  return value.slice(0, 1000);
}

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ provider: string }> }
) {
  const { provider: rawProvider } = await params;
  const provider = rawProvider.toLowerCase();
  if (provider !== "google" && provider !== "facebook") {
    return NextResponse.json({ success: false, error: "Unsupported sign-in provider." }, { status: 404 });
  }

  const googleClientId = process.env.GOOGLE_CLIENT_ID;
  const googleClientSecret = process.env.GOOGLE_CLIENT_SECRET;
  const facebookAppId = process.env.FACEBOOK_APP_ID;
  const facebookAppSecret = process.env.FACEBOOK_APP_SECRET;
  if (provider === "google" && (!googleClientId || !googleClientSecret)) {
    return NextResponse.json({
      success: false,
      error: "Google sign-in is not configured yet. The site administrator must add GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET to the Node host environment.",
    }, { status: 503 });
  }
  if (provider === "facebook" && (!facebookAppId || !facebookAppSecret)) {
    return NextResponse.json({
      success: false,
      error: "Facebook sign-in is not configured yet. The site administrator must add FACEBOOK_APP_ID and FACEBOOK_APP_SECRET to the Node host environment.",
    }, { status: 503 });
  }

  const baseUrl = (process.env.PUBLIC_APP_URL || request.nextUrl.origin).replace(/\/$/, "");
  const redirectUri = `${baseUrl}/api/auth/oauth/${provider}/callback`;
  const returnTo = safeReturnPath(request.nextUrl.searchParams.get("returnTo"));
  const state = randomBytes(32).toString("hex");
  const stateCookie = `cscpo_oauth_state_${provider}`;
  const returnCookie = `cscpo_oauth_return_${provider}`;
  const cookieOptions = {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax" as const,
    path: `/api/auth/oauth/${provider}/callback`,
    maxAge: 10 * 60,
  };

  const authorizationUrl = provider === "google"
    ? new URL("https://accounts.google.com/o/oauth2/v2/auth")
    : new URL(`https://www.facebook.com/${process.env.FACEBOOK_GRAPH_VERSION || "v27.0"}/dialog/oauth`);

  if (provider === "google") {
    authorizationUrl.searchParams.set("client_id", googleClientId!);
    authorizationUrl.searchParams.set("redirect_uri", redirectUri);
    authorizationUrl.searchParams.set("response_type", "code");
    authorizationUrl.searchParams.set("scope", "openid email profile");
    authorizationUrl.searchParams.set("state", state);
    authorizationUrl.searchParams.set("prompt", "select_account");
  } else {
    authorizationUrl.searchParams.set("client_id", facebookAppId!);
    authorizationUrl.searchParams.set("redirect_uri", redirectUri);
    authorizationUrl.searchParams.set("response_type", "code");
    authorizationUrl.searchParams.set("scope", "email,public_profile");
    authorizationUrl.searchParams.set("state", state);
  }

  const response = NextResponse.json({ success: true, authorizationUrl: authorizationUrl.toString() });
  response.cookies.set(stateCookie, state, cookieOptions);
  response.cookies.set(returnCookie, encodeURIComponent(returnTo), cookieOptions);
  return response;
}
