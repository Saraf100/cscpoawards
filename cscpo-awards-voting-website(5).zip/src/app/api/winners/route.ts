import { NextResponse } from "next/server";
import { db } from "@/db";
import { previousWinners } from "@/db/schema";
import { desc } from "drizzle-orm";
import { ensureSeeded } from "@/lib/seed";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    await ensureSeeded();
    const winners = await db.select().from(previousWinners).orderBy(desc(previousWinners.year));
    return NextResponse.json({ success: true, data: winners });
  } catch (error) {
    console.error("Error fetching winners:", error);
    return NextResponse.json({ success: false, error: "Failed to fetch winners" }, { status: 500 });
  }
}
