import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { categories, adminAuditLogs } from "@/db/schema";
import { eq } from "drizzle-orm";
import { ensureSeeded } from "@/lib/seed";

export const dynamic = "force-dynamic";

export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    await ensureSeeded();
    const resolvedParams = await params;
    const catId = Number(resolvedParams.id);
    const body = await request.json();

    const [existing] = await db.select().from(categories).where(eq(categories.id, catId)).limit(1);
    if (!existing) {
      return NextResponse.json({ success: false, error: "Category not found" }, { status: 404 });
    }

    const [updated] = await db
      .update(categories)
      .set({
        name: body.name ?? existing.name,
        nameBn: body.nameBn ?? existing.nameBn,
        description: body.description ?? existing.description,
        icon: body.icon ?? existing.icon,
        displayOrder: body.displayOrder !== undefined ? Number(body.displayOrder) : existing.displayOrder,
        isActive: body.isActive !== undefined ? Boolean(body.isActive) : existing.isActive,
      })
      .where(eq(categories.id, catId))
      .returning();

    await db.insert(adminAuditLogs).values({
      action: "CATEGORY_UPDATED",
      performedBy: body.adminName || "CSCPO Administrator",
      details: `Updated category #${catId} (${updated.name})`,
    });

    return NextResponse.json({ success: true, data: updated });
  } catch (error) {
    console.error("Error updating category:", error);
    return NextResponse.json({ success: false, error: "Failed to update category" }, { status: 500 });
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    await ensureSeeded();
    const resolvedParams = await params;
    const catId = Number(resolvedParams.id);

    const [existing] = await db.select().from(categories).where(eq(categories.id, catId)).limit(1);
    if (!existing) {
      return NextResponse.json({ success: false, error: "Category not found" }, { status: 404 });
    }

    // Soft delete or deactivate
    await db
      .update(categories)
      .set({ isActive: false })
      .where(eq(categories.id, catId));

    await db.insert(adminAuditLogs).values({
      action: "CATEGORY_DEACTIVATED",
      performedBy: "CSCPO Administrator",
      details: `Deactivated category #${catId} (${existing.name})`,
    });

    return NextResponse.json({ success: true, message: `Category '${existing.name}' deactivated successfully.` });
  } catch (error) {
    console.error("Error deactivating category:", error);
    return NextResponse.json({ success: false, error: "Failed to deactivate category" }, { status: 500 });
  }
}
