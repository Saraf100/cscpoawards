import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { categories, nominees, adminAuditLogs } from "@/db/schema";
import { eq, asc, sql } from "drizzle-orm";
import { ensureSeeded } from "@/lib/seed";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    await ensureSeeded();
    const allCategories = await db
      .select()
      .from(categories)
      .where(eq(categories.isActive, true))
      .orderBy(asc(categories.displayOrder));

    // Aggregate nominees count and total votes per category
    const approvedNominees = await db
      .select({
        categoryId: nominees.categoryId,
        voteCount: nominees.voteCount,
      })
      .from(nominees)
      .where(eq(nominees.status, "APPROVED"));

    const countsMap = new Map<number, { nomineeCount: number; totalVotes: number }>();
    approvedNominees.forEach((n) => {
      if (!n.categoryId) return;
      const current = countsMap.get(n.categoryId) || { nomineeCount: 0, totalVotes: 0 };
      countsMap.set(n.categoryId, {
        nomineeCount: current.nomineeCount + 1,
        totalVotes: current.totalVotes + (n.voteCount || 0),
      });
    });

    const enriched = allCategories.map((c) => {
      const stats = countsMap.get(c.id) || { nomineeCount: 0, totalVotes: 0 };
      return {
        ...c,
        nomineeCount: stats.nomineeCount,
        totalVotes: stats.totalVotes,
      };
    });

    return NextResponse.json({ success: true, count: enriched.length, data: enriched });
  } catch (error) {
    console.error("Error fetching categories:", error);
    return NextResponse.json({ success: false, error: "Failed to fetch categories" }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    await ensureSeeded();
    const body = await request.json();
    const { name, nameBn, description, icon, displayOrder } = body;

    if (!name || !description) {
      return NextResponse.json({ success: false, error: "Name and description are required" }, { status: 400 });
    }

    const slug = name.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "");

    const [newCat] = await db
      .insert(categories)
      .values({
        slug,
        name,
        nameBn: nameBn || null,
        description,
        icon: icon || "Award",
        displayOrder: Number(displayOrder) || 10,
        isActive: true,
      })
      .returning();

    await db.insert(adminAuditLogs).values({
      action: "CATEGORY_CREATED",
      performedBy: "CSCPO Administrator",
      details: `Created new award category '${name}' (Slug: ${slug})`,
    });

    return NextResponse.json({ success: true, data: newCat });
  } catch (error) {
    console.error("Error creating category:", error);
    return NextResponse.json({ success: false, error: "Failed to create category" }, { status: 500 });
  }
}
