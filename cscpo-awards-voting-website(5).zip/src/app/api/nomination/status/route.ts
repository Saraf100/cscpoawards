import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { nominees } from "@/db/schema";
import { eq, and, ilike } from "drizzle-orm";
import { ensureSeeded } from "@/lib/seed";

export const dynamic = "force-dynamic";

export async function POST(request: NextRequest) {
  try {
    await ensureSeeded();
    const body = await request.json();
    const { refNumber, email } = body;

    if (!refNumber || !email) {
      return NextResponse.json(
        { success: false, error: "Please provide both Nomination Reference Number and Email Address." },
        { status: 400 }
      );
    }

    const cleanRef = refNumber.trim().toUpperCase();
    const cleanEmail = email.trim().toLowerCase();

    const [nominee] = await db
      .select()
      .from(nominees)
      .where(
        and(
          eq(nominees.refNumber, cleanRef),
          ilike(nominees.email, cleanEmail)
        )
      )
      .limit(1);

    if (!nominee) {
      return NextResponse.json(
        {
          success: false,
          error: "No nomination found matching this reference number and email. Please check your credentials.",
        },
        { status: 404 }
      );
    }

    return NextResponse.json({
      success: true,
      data: {
        refNumber: nominee.refNumber,
        name: nominee.name,
        organization: nominee.organization,
        categoryName: nominee.categoryName,
        status: nominee.status,
        rejectionReason: nominee.rejectionReason,
        voteCount: nominee.voteCount,
        slug: nominee.slug,
        createdAt: nominee.createdAt,
        updatedAt: nominee.updatedAt,
      },
    });
  } catch (error) {
    console.error("Error looking up nomination status:", error);
    return NextResponse.json({ success: false, error: "Failed to query status" }, { status: 500 });
  }
}
