import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { votes, nominees, categories, voters, adminAuditLogs } from "@/db/schema";
import { desc, eq, sql } from "drizzle-orm";
import { ensureSeeded } from "@/lib/seed";

export const dynamic = "force-dynamic";

export async function GET(request: NextRequest) {
  try {
    await ensureSeeded();
    const { searchParams } = new URL(request.url);
    const filter = searchParams.get("filter"); // all, fraud, valid, invalid

    let query = db
      .select({
        id: votes.id,
        voterId: votes.voterId,
        nomineeId: votes.nomineeId,
        categoryId: votes.categoryId,
        voterEmail: votes.voterEmail,
        ipAddress: votes.ipAddress,
        userAgent: votes.userAgent,
        verificationMethod: votes.verificationMethod,
        isFraud: votes.isFraud,
        fraudReason: votes.fraudReason,
        isValid: votes.isValid,
        revokedReason: votes.revokedReason,
        revokedBy: votes.revokedBy,
        createdAt: votes.createdAt,
      })
      .from(votes)
      .orderBy(desc(votes.createdAt))
      .limit(150);

    const rawVotes = await query;

    // Attach nominee names
    const allNominees = await db.select().from(nominees);
    const nomMap = new Map(allNominees.map((n) => [n.id, n]));

    const enriched = rawVotes.map((v) => {
      const nom = nomMap.get(v.nomineeId);
      return {
        ...v,
        nomineeName: nom ? nom.name : `Nominee #${v.nomineeId}`,
        categoryName: nom?.categoryName || "Category",
      };
    });

    let filtered = enriched;
    if (filter === "fraud") {
      filtered = enriched.filter((v) => v.isFraud);
    } else if (filter === "invalid") {
      filtered = enriched.filter((v) => !v.isValid);
    } else if (filter === "valid") {
      filtered = enriched.filter((v) => v.isValid && !v.isFraud);
    }

    return NextResponse.json({
      success: true,
      count: filtered.length,
      data: filtered,
    });
  } catch (error) {
    console.error("Error fetching admin votes:", error);
    return NextResponse.json({ success: false, error: "Failed to fetch votes" }, { status: 500 });
  }
}

// Revoke or Flag a vote
export async function POST(request: NextRequest) {
  try {
    await ensureSeeded();
    const body = await request.json();
    const { voteId, action, reason, adminName } = body; // action: 'REVOKE' or 'RESTORE' or 'FLAG_VOTER'

    if (!voteId) {
      return NextResponse.json({ success: false, error: "Vote ID required" }, { status: 400 });
    }

    const [targetVote] = await db.select().from(votes).where(eq(votes.id, Number(voteId))).limit(1);
    if (!targetVote) {
      return NextResponse.json({ success: false, error: "Vote not found" }, { status: 404 });
    }

    if (action === "REVOKE") {
      await db
        .update(votes)
        .set({
          isValid: false,
          revokedReason: reason || "Revoked by voting integrity auditor",
          revokedBy: adminName || "CSCPO Admin",
        })
        .where(eq(votes.id, targetVote.id));

      // Decrement nominee vote count if it was valid before
      if (targetVote.isValid && !targetVote.isFraud) {
        await db
          .update(nominees)
          .set({
            voteCount: sql`GREATEST(0, ${nominees.voteCount} - 1)`,
            updatedAt: new Date(),
          })
          .where(eq(nominees.id, targetVote.nomineeId));
      }

      await db.insert(adminAuditLogs).values({
        action: "VOTE_REVOKED",
        performedBy: adminName || "CSCPO Administrator",
        details: `Vote #${targetVote.id} from ${targetVote.voterEmail} for Nominee #${targetVote.nomineeId} revoked. Reason: ${reason}`,
      });

      return NextResponse.json({ success: true, message: "Vote revoked successfully and count adjusted." });
    } else if (action === "FLAG_VOTER") {
      await db
        .update(voters)
        .set({
          status: "SUSPENDED",
          suspiciousReason: reason || "Suspended by admin for automated script activity",
        })
        .where(eq(voters.id, targetVote.voterId));

      await db.insert(adminAuditLogs).values({
        action: "VOTER_SUSPENDED",
        performedBy: adminName || "CSCPO Administrator",
        details: `Voter ${targetVote.voterEmail} suspended. Reason: ${reason}`,
      });

      return NextResponse.json({ success: true, message: `Voter ${targetVote.voterEmail} suspended.` });
    }

    return NextResponse.json({ success: false, error: "Invalid action" }, { status: 400 });
  } catch (error) {
    console.error("Error managing vote:", error);
    return NextResponse.json({ success: false, error: "Failed to manage vote" }, { status: 500 });
  }
}
