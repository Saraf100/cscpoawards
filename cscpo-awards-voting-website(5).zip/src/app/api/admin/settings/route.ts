import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { votingSettings, adminAuditLogs } from "@/db/schema";
import { eq } from "drizzle-orm";
import { ensureSeeded } from "@/lib/seed";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    await ensureSeeded();
    const [settings] = await db.select().from(votingSettings).limit(1);
    return NextResponse.json({ success: true, data: settings });
  } catch (error) {
    console.error("Error getting settings:", error);
    return NextResponse.json({ success: false, error: "Failed to get settings" }, { status: 500 });
  }
}

export async function PUT(request: NextRequest) {
  try {
    await ensureSeeded();
    const body = await request.json();
    const [existing] = await db.select().from(votingSettings).limit(1);

    if (!existing) {
      return NextResponse.json({ success: false, error: "Settings not found" }, { status: 404 });
    }

    const [updated] = await db
      .update(votingSettings)
      .set({
        votingStatus: body.votingStatus ?? existing.votingStatus,
        votingStartDate: body.votingStartDate ? new Date(body.votingStartDate) : existing.votingStartDate,
        votingEndDate: body.votingEndDate ? new Date(body.votingEndDate) : existing.votingEndDate,
        votingPolicy: body.votingPolicy ?? existing.votingPolicy,
        showPublicCounts: body.showPublicCounts !== undefined ? Boolean(body.showPublicCounts) : existing.showPublicCounts,
        showPublicRankings: body.showPublicRankings !== undefined ? Boolean(body.showPublicRankings) : existing.showPublicRankings,
        requireCaptcha: body.requireCaptcha !== undefined ? Boolean(body.requireCaptcha) : existing.requireCaptcha,
        allowNominationDrafts: body.allowNominationDrafts !== undefined ? Boolean(body.allowNominationDrafts) : existing.allowNominationDrafts,
        nominationDeadline: body.nominationDeadline ? new Date(body.nominationDeadline) : existing.nominationDeadline,
        announcementText: body.announcementText ?? existing.announcementText,
        bannerTitle: body.bannerTitle ?? existing.bannerTitle,
        bannerSubtitle: body.bannerSubtitle ?? existing.bannerSubtitle,
        logoUrl: body.logoUrl !== undefined ? body.logoUrl : existing.logoUrl,
        sponsorLogos: body.sponsorLogos !== undefined ? body.sponsorLogos : existing.sponsorLogos,
        supportLogos: body.supportLogos !== undefined ? body.supportLogos : existing.supportLogos,
        updatedAt: new Date(),
      })
      .where(eq(votingSettings.id, existing.id))
      .returning();

    await db.insert(adminAuditLogs).values({
      action: "SETTINGS_UPDATED",
      performedBy: body.adminName || "CSCPO Administrator",
      details: `Settings updated: Status=${updated.votingStatus}, Policy=${updated.votingPolicy}, PublicCounts=${updated.showPublicCounts}`,
    });

    return NextResponse.json({ success: true, data: updated, message: "Settings updated successfully." });
  } catch (error) {
    console.error("Error updating settings:", error);
    return NextResponse.json({ success: false, error: "Failed to update settings" }, { status: 500 });
  }
}
