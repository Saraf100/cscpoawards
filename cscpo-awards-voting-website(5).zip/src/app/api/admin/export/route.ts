import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { nominees, votes, voters } from "@/db/schema";
import { desc } from "drizzle-orm";
import { ensureSeeded } from "@/lib/seed";

export const dynamic = "force-dynamic";

export async function GET(request: NextRequest) {
  try {
    await ensureSeeded();
    const { searchParams } = new URL(request.url);
    const type = searchParams.get("type") || "nominees"; // nominees, votes, voters

    if (type === "nominees") {
      const data = await db.select().from(nominees).orderBy(desc(nominees.voteCount));
      const headers = ["ID", "RefNumber", "Name", "Category", "Designation", "Organization", "Country", "Votes", "Status", "Email"];
      const rows = data.map((n) => [
        n.id,
        `"${n.refNumber}"`,
        `"${n.name.replace(/"/g, '""')}"`,
        `"${(n.categoryName || "").replace(/"/g, '""')}"`,
        `"${n.designation.replace(/"/g, '""')}"`,
        `"${n.organization.replace(/"/g, '""')}"`,
        `"${n.country}"`,
        n.voteCount,
        n.status,
        `"${n.email}"`,
      ]);

      const csv = [headers.join(","), ...rows.map((r) => r.join(","))].join("\n");
      return new NextResponse(csv, {
        headers: {
          "Content-Type": "text/csv; charset=utf-8",
          "Content-Disposition": 'attachment; filename="cscpo-nominees.csv"',
        },
      });
    } else if (type === "votes") {
      const data = await db.select().from(votes).orderBy(desc(votes.createdAt));
      const headers = ["VoteID", "VoterEmail", "NomineeID", "CategoryID", "IPAddress", "Method", "IsValid", "IsFraud", "CreatedAt"];
      const rows = data.map((v) => [
        v.id,
        `"${v.voterEmail}"`,
        v.nomineeId,
        v.categoryId,
        `"${v.ipAddress || ""}"`,
        v.verificationMethod,
        v.isValid,
        v.isFraud,
        `"${v.createdAt.toISOString()}"`,
      ]);

      const csv = [headers.join(","), ...rows.map((r) => r.join(","))].join("\n");
      return new NextResponse(csv, {
        headers: {
          "Content-Type": "text/csv; charset=utf-8",
          "Content-Disposition": 'attachment; filename="cscpo-votes-audit.csv"',
        },
      });
    }

    return NextResponse.json({ success: false, error: "Invalid export type" }, { status: 400 });
  } catch (error) {
    console.error("Export error:", error);
    return NextResponse.json({ success: false, error: "Export failed" }, { status: 500 });
  }
}
