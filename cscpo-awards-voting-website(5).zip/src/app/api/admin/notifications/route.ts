import { NextResponse } from "next/server";
import { db } from "@/db";
import { notificationsLog } from "@/db/schema";
import { desc } from "drizzle-orm";
import { ensureSeeded } from "@/lib/seed";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    await ensureSeeded();
    const logs = await db.select().from(notificationsLog).orderBy(desc(notificationsLog.sentAt)).limit(100);
    return NextResponse.json({ success: true, count: logs.length, data: logs });
  } catch (error) {
    console.error("Error fetching notification logs:", error);
    return NextResponse.json({ success: false, error: "Failed to fetch notification logs" }, { status: 500 });
  }
}
