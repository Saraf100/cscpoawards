import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { nominees, notificationsLog, adminAuditLogs } from "@/db/schema";
import { eq } from "drizzle-orm";
import { ensureSeeded } from "@/lib/seed";

export const dynamic = "force-dynamic";

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    await ensureSeeded();
    const resolvedParams = await params;
    const nomineeId = Number(resolvedParams.id);
    const body = await request.json();
    const { status, rejectionReason, adminName } = body;

    if (!["APPROVED", "REJECTED", "PENDING"].includes(status)) {
      return NextResponse.json({ success: false, error: "Invalid status value" }, { status: 400 });
    }

    const [nominee] = await db.select().from(nominees).where(eq(nominees.id, nomineeId)).limit(1);
    if (!nominee) {
      return NextResponse.json({ success: false, error: "Nominee not found" }, { status: 404 });
    }

    const [updated] = await db
      .update(nominees)
      .set({
        status,
        rejectionReason: status === "REJECTED" ? rejectionReason || "Does not meet category eligibility criteria" : null,
        updatedAt: new Date(),
      })
      .where(eq(nominees.id, nomineeId))
      .returning();

    // Log notification
    if (status === "APPROVED") {
      await db.insert(notificationsLog).values({
        recipientEmail: nominee.email,
        recipientName: nominee.name,
        subject: `CSCPO Awards: Nomination Approved & Voting Card Published`,
        type: "NOMINATION_APPROVED",
        refNumber: nominee.refNumber,
        body: `Dear ${nominee.name},\n\nWe are pleased to inform you that your nomination for '${nominee.categoryName}' has been officially approved by the CSCPO Screening Committee.\n\nYour profile is now live in the Public Voting Gallery at https://cscpo.org/cscpobdawards2026/nominee/${nominee.slug}.\n\nShare your voting link with your professional network!\n\nWarm regards,\nCSCPO Awards Committee`,
        status: "DELIVERED",
      });
    } else if (status === "REJECTED") {
      await db.insert(notificationsLog).values({
        recipientEmail: nominee.email,
        recipientName: nominee.name,
        subject: `CSCPO Awards: Nomination Status Update [Ref: ${nominee.refNumber}]`,
        type: "NOMINATION_REJECTED",
        refNumber: nominee.refNumber,
        body: `Dear ${nominee.name},\n\nThank you for your interest in the CSCPO South Asian Leadership Awards.\n\nAfter careful evaluation by the screening committee, we regret to inform you that your nomination could not be approved for public voting this year.\n\nReason: ${rejectionReason || "Criteria mismatch or incomplete supporting documentation"}.\n\nYou may contact the secretariat at awards@cscpo.org for inquiries.\n\nSincerely,\nCSCPO Awards Committee`,
        status: "DELIVERED",
      });
    }

    // Admin audit trail
    await db.insert(adminAuditLogs).values({
      action: `NOMINATION_${status}`,
      performedBy: adminName || "CSCPO Administrator",
      details: `Nomination #${nominee.id} (${nominee.name}, Ref: ${nominee.refNumber}) marked as ${status}. ${
        status === "REJECTED" ? `Reason: ${rejectionReason}` : ""
      }`,
    });

    return NextResponse.json({
      success: true,
      message: `Nomination marked as ${status} successfully.`,
      data: updated,
    });
  } catch (error) {
    console.error("Error updating nomination status:", error);
    return NextResponse.json({ success: false, error: "Failed to update nomination status" }, { status: 500 });
  }
}
