import { db } from "@/db";
import { sql } from "drizzle-orm";
import { ensureSeeded } from "@/lib/seed";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    await db.execute(sql`select 1`);
    await ensureSeeded();
    return Response.json({ ok: true, status: "CSCPO Awards Platform Ready" });
  } catch (error) {
    console.error("Healthcheck error:", error);
    return Response.json({ ok: false, error: String(error) }, { status: 500 });
  }
}
