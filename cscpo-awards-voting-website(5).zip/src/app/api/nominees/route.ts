import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { nominees, categories, notificationsLog, adminAuditLogs } from "@/db/schema";
import { eq, desc, asc, and, ilike, or, sql } from "drizzle-orm";
import { ensureSeeded } from "@/lib/seed";

export const dynamic = "force-dynamic";

export async function GET(request: NextRequest) {
  try {
    await ensureSeeded();
    const { searchParams } = new URL(request.url);
    const category = searchParams.get("category");
    const country = searchParams.get("country");
    const search = searchParams.get("search");
    const sort = searchParams.get("sort") || "votes"; // votes, name, recent
    const status = searchParams.get("status") || "APPROVED"; // or "ALL" for admin
    const featured = searchParams.get("featured");

    const conditions = [];

    if (status !== "ALL") {
      conditions.push(eq(nominees.status, status));
    }

    if (category && category !== "all") {
      if (isNaN(Number(category))) {
        // category is slug
        const [cat] = await db.select().from(categories).where(eq(categories.slug, category)).limit(1);
        if (cat) {
          conditions.push(eq(nominees.categoryId, cat.id));
        }
      } else {
        conditions.push(eq(nominees.categoryId, Number(category)));
      }
    }

    if (country && country !== "all") {
      conditions.push(ilike(nominees.country, country));
    }

    if (featured === "true") {
      conditions.push(eq(nominees.isFeatured, true));
    }

    if (search && search.trim() !== "") {
      const q = `%${search.trim()}%`;
      conditions.push(
        or(
          ilike(nominees.name, q),
          ilike(nominees.designation, q),
          ilike(nominees.organization, q),
          ilike(nominees.achievementSummary, q)
        )
      );
    }

    let query = db.select().from(nominees);
    if (conditions.length > 0) {
      // @ts-expect-error Drizzle conditional
      query = query.where(and(...conditions));
    }

    let results;
    if (sort === "name") {
      results = await query.orderBy(asc(nominees.name));
    } else if (sort === "recent") {
      results = await query.orderBy(desc(nominees.createdAt));
    } else {
      results = await query.orderBy(desc(nominees.voteCount), asc(nominees.name));
    }

    // Attach category details if needed
    const allCategories = await db.select().from(categories);
    const catMap = new Map(allCategories.map(c => [c.id, c.name]));

    const enriched = results.map((n, idx) => ({
      ...n,
      categoryName: n.categoryName || catMap.get(n.categoryId || 0) || "Leadership Award",
      calculatedRank: idx + 1,
    }));

    return NextResponse.json({ success: true, count: enriched.length, data: enriched });
  } catch (error) {
    console.error("Error fetching nominees:", error);
    return NextResponse.json({ success: false, error: "Failed to fetch nominees" }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    await ensureSeeded();
    const body = await request.json();

    const {
      categoryId,
      name,
      designation,
      organization,
      country,
      email,
      mobile,
      photoUrl,
      achievementSummary,
      whyNominate,
      experienceYears,
      bio,
      careerHistory,
      supplyChainContributions,
      supportingDocuments,
      linkedinUrl,
      websiteUrl,
      isDraft,
      nominatorName,
      nominatorEmail,
      nominatorRelation,
    } = body;

    if (!name || !organization || !categoryId || !email) {
      return NextResponse.json(
        { success: false, error: "Required fields missing: Name, Organization, Category, and Email are mandatory." },
        { status: 400 }
      );
    }

    // Lookup category
    const [cat] = await db.select().from(categories).where(eq(categories.id, Number(categoryId))).limit(1);

    // Generate unique slug
    let baseSlug = name.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "");
    if (!baseSlug) baseSlug = "nominee";
    let finalSlug = baseSlug;
    let counter = 1;
    while (true) {
      const [existing] = await db.select().from(nominees).where(eq(nominees.slug, finalSlug)).limit(1);
      if (!existing) break;
      counter++;
      finalSlug = `${baseSlug}-${counter}`;
    }

    // Generate unique reference number
    const randomSuffix = Math.floor(1000 + Math.random() * 9000);
    const refNumber = `CSCPO-N${randomSuffix}`;

    const defaultPhoto = photoUrl && photoUrl.trim() !== ""
      ? photoUrl
      : "https://images.pexels.com/photos/28442318/pexels-photo-28442318.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940";

    const status = isDraft ? "DRAFT" : "PENDING";

    const [newNominee] = await db
      .insert(nominees)
      .values({
        slug: finalSlug,
        refNumber,
        categoryId: Number(categoryId),
        categoryName: cat ? cat.name : "South Asian Leadership Award",
        name,
        designation: designation || "Executive",
        organization,
        country: country || "Bangladesh",
        email,
        mobile: mobile || "N/A",
        photoUrl: defaultPhoto,
        achievementSummary: achievementSummary || "",
        whyNominate: whyNominate || "",
        experienceYears: Number(experienceYears) || 5,
        bio: bio || achievementSummary || "",
        careerHistory: careerHistory || "",
        supplyChainContributions: supplyChainContributions || "",
        supportingDocuments: supportingDocuments || [],
        linkedinUrl: linkedinUrl || "",
        websiteUrl: websiteUrl || "",
        status,
        isVerified: true,
        isFeatured: false,
        voteCount: 0,
        rank: 0,
        nominatorName: nominatorName || "Self-Nomination",
        nominatorEmail: nominatorEmail || email,
        nominatorRelation: nominatorRelation || "Self",
      })
      .returning();

    // Log notification
    await db.insert(notificationsLog).values({
      recipientEmail: email,
      recipientName: name,
      subject: `CSCPO Awards: Nomination Submitted [Ref: ${refNumber}]`,
      type: "NOMINATION_SUBMITTED",
      refNumber,
      body: `Dear ${name},\n\nThank you for submitting your nomination for '${cat?.name || "CSCPO Leadership Awards"}' in the CSCPO South Asian Leadership Awards.\n\nYour Reference Number is: ${refNumber}.\n\nOur International Award Screening Jury will review the submission. You can track your status anytime using your reference number.\n\nWarm regards,\nCSCPO Awards Committee`,
      status: "DELIVERED",
    });

    // Audit log
    await db.insert(adminAuditLogs).values({
      action: "NOMINATION_SUBMITTED",
      performedBy: nominatorName || name,
      details: `New nomination submitted for ${name} (${organization}) in category ${cat?.name}. Ref: ${refNumber}. Status: ${status}`,
    });

    return NextResponse.json({
      success: true,
      data: newNominee,
      refNumber,
      message: isDraft
        ? "Nomination saved as draft successfully. Use your reference number to resume."
        : "Nomination submitted successfully! An official confirmation email has been logged.",
    });
  } catch (error) {
    console.error("Error creating nomination:", error);
    return NextResponse.json({ success: false, error: "Failed to submit nomination: " + String(error) }, { status: 500 });
  }
}
