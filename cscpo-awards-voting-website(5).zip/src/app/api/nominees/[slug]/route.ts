import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { nominees, categories, adminAuditLogs } from "@/db/schema";
import { eq, desc } from "drizzle-orm";
import { ensureSeeded } from "@/lib/seed";

export const dynamic = "force-dynamic";

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ slug: string }> }
) {
  try {
    await ensureSeeded();
    const resolvedParams = await params;
    const slug = resolvedParams.slug;

    const [nominee] = await db
      .select()
      .from(nominees)
      .where(eq(nominees.slug, slug))
      .limit(1);

    if (!nominee) {
      return NextResponse.json({ success: false, error: "Nominee not found" }, { status: 404 });
    }

    // Category details
    let category = null;
    if (nominee.categoryId) {
      const [cat] = await db
        .select()
        .from(categories)
        .where(eq(categories.id, nominee.categoryId))
        .limit(1);
      category = cat || null;
    }

    // Calculate live position/rank within the category
    let categoryRank = 1;
    let totalCategoryVotes = 0;
    if (nominee.categoryId) {
      const categoryNominees = await db
        .select()
        .from(nominees)
        .where(eq(nominees.categoryId, nominee.categoryId))
        .orderBy(desc(nominees.voteCount));

      const rankIndex = categoryNominees.findIndex((n) => n.id === nominee.id);
      if (rankIndex >= 0) {
        categoryRank = rankIndex + 1;
      }
      totalCategoryVotes = categoryNominees.reduce((acc, curr) => acc + (curr.voteCount || 0), 0);
    }

    return NextResponse.json({
      success: true,
      data: {
        ...nominee,
        category,
        categoryRank,
        totalCategoryVotes,
      },
    });
  } catch (error) {
    console.error("Error fetching single nominee:", error);
    return NextResponse.json({ success: false, error: "Internal error" }, { status: 500 });
  }
}

export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ slug: string }> }
) {
  try {
    await ensureSeeded();
    const resolvedParams = await params;
    const slug = resolvedParams.slug;
    const body = await request.json();

    const [existing] = await db.select().from(nominees).where(eq(nominees.slug, slug)).limit(1);
    if (!existing) {
      return NextResponse.json({ success: false, error: "Nominee not found" }, { status: 404 });
    }

    // Allowed updates
    const updated = await db
      .update(nominees)
      .set({
        name: body.name ?? existing.name,
        designation: body.designation ?? existing.designation,
        organization: body.organization ?? existing.organization,
        country: body.country ?? existing.country,
        photoUrl: body.photoUrl ?? existing.photoUrl,
        achievementSummary: body.achievementSummary ?? existing.achievementSummary,
        whyNominate: body.whyNominate ?? existing.whyNominate,
        bio: body.bio ?? existing.bio,
        careerHistory: body.careerHistory ?? existing.careerHistory,
        supplyChainContributions: body.supplyChainContributions ?? existing.supplyChainContributions,
        experienceYears: body.experienceYears !== undefined ? Number(body.experienceYears) : existing.experienceYears,
        linkedinUrl: body.linkedinUrl ?? existing.linkedinUrl,
        websiteUrl: body.websiteUrl ?? existing.websiteUrl,
        categoryId: body.categoryId !== undefined ? Number(body.categoryId) : existing.categoryId,
        categoryName: body.categoryName ?? existing.categoryName,
        isFeatured: body.isFeatured !== undefined ? Boolean(body.isFeatured) : existing.isFeatured,
        status: body.status ?? existing.status,
        updatedAt: new Date(),
      })
      .where(eq(nominees.id, existing.id))
      .returning();

    await db.insert(adminAuditLogs).values({
      action: "NOMINEE_UPDATED",
      performedBy: body.updatedBy || "CSCPO Administrator",
      details: `Updated nominee details for ${existing.name} (Ref: ${existing.refNumber})`,
    });

    return NextResponse.json({ success: true, data: updated[0] });
  } catch (error) {
    console.error("Error updating nominee:", error);
    return NextResponse.json({ success: false, error: "Failed to update nominee" }, { status: 500 });
  }
}
