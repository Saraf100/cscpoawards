import Link from "next/link";
import { db } from "@/db";
import { categories, nominees, votingSettings, previousWinners } from "@/db/schema";
import { eq, desc } from "drizzle-orm";
import { ensureSeeded } from "@/lib/seed";
import NomineeCard from "@/components/NomineeCard";
import { SponsorLogo, SupportLogo } from "@/lib/types";
import {
  Award,
  Vote,
  ShieldCheck,
  CheckCircle2,
  Users,
  Trophy,
  ArrowRight,
  TrendingUp,
  Globe,
  Sparkles,
  HelpCircle,
  ExternalLink,
  ChevronRight,
  Lock,
  Handshake,
} from "lucide-react";

export const dynamic = "force-dynamic";

export default async function HomePage() {
  await ensureSeeded();

  const [settings] = await db.select().from(votingSettings).limit(1);

  const approvedNominees = await db
    .select()
    .from(nominees)
    .where(eq(nominees.status, "APPROVED"))
    .orderBy(desc(nominees.voteCount));

  const allCategories = await db.select().from(categories).where(eq(categories.isActive, true));
  const winners = await db.select().from(previousWinners).limit(4);

  const totalApprovedNominees = approvedNominees.length;
  const totalVotes = approvedNominees.reduce((acc, curr) => acc + (curr.voteCount || 0), 0);
  const featuredNominees = approvedNominees.filter((n) => n.isFeatured).slice(0, 4);

  // If not enough featured, take top 4
  const displayFeatured = featuredNominees.length >= 4 ? featuredNominees : approvedNominees.slice(0, 4);

  const sponsors = Array.isArray(settings?.sponsorLogos)
    ? (settings.sponsorLogos as unknown as SponsorLogo[])
    : [];
  const supporters = Array.isArray(settings?.supportLogos)
    ? (settings.supportLogos as unknown as SupportLogo[])
    : [];
  const siteLogo = settings?.logoUrl || "/images/cscpo-award-logo.png";
  const titleText = settings?.bannerTitle || "CSCPO South Asian Leadership Awards";
  const subtitleText = settings?.bannerSubtitle || "Recognizing visionaries, innovators, and transformative pioneers driving supply chain resilience, green logistics, and operational excellence across South Asia.";

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col">
      {/* HERO SECTION */}
      <section className="relative overflow-hidden bg-gradient-to-b from-slate-950 via-slate-900 to-slate-950 pt-8 pb-16 md:py-24 border-b border-slate-800">
        {/* Background glow effects */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[400px] bg-amber-500/10 blur-[140px] pointer-events-none rounded-full" />
        <div className="absolute -top-32 right-10 w-96 h-96 bg-blue-600/10 blur-[120px] pointer-events-none rounded-full" />

        <div className="container mx-auto px-4 relative z-10">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            {/* Left Content */}
            <div className="lg:col-span-7 space-y-6 text-center lg:text-left">
              <div className="inline-flex items-center space-x-2 px-3.5 py-1.5 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs font-semibold backdrop-blur-md">
                <Sparkles className="w-4 h-4 text-amber-400" />
                <span>Nominations & Verified Public Voting Platform</span>
              </div>

              <h1 className="text-3xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-white leading-[1.15]">
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-amber-300 via-amber-400 to-amber-500">
                  {titleText}
                </span>
              </h1>

              <p className="text-base sm:text-lg text-slate-300 leading-relaxed max-w-2xl mx-auto lg:mx-0 font-normal">
                {subtitleText}
              </p>

              {/* Action Buttons */}
              <div className="flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-3 pt-2">
                <Link
                  href="/voting"
                  className="w-full sm:w-auto px-8 py-4 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-extrabold text-sm tracking-wide shadow-xl shadow-amber-500/20 transition-all flex items-center justify-center space-x-2 transform hover:-translate-y-0.5"
                >
                  <Vote className="w-5 h-5" />
                  <span>Public Voting Gallery</span>
                  <ArrowRight className="w-4 h-4" />
                </Link>

                <Link
                  href="/nominate"
                  className="w-full sm:w-auto px-6 py-4 rounded-xl bg-slate-900/90 hover:bg-slate-800 border border-slate-700 text-white font-bold text-sm tracking-wide shadow-lg transition-all flex items-center justify-center space-x-2"
                >
                  <Award className="w-4 h-4 text-amber-400" />
                  <span>Submit Nomination</span>
                </Link>

                <Link
                  href="/results"
                  className="w-full sm:w-auto px-5 py-4 rounded-xl bg-transparent hover:bg-slate-900/60 text-slate-300 hover:text-white text-sm font-semibold flex items-center justify-center space-x-1.5 transition"
                >
                  <span>Live Results</span>
                  <ChevronRight className="w-4 h-4" />
                </Link>
              </div>

              {/* Embed & Accreditation Note */}
              <div className="pt-2 flex flex-wrap items-center justify-center lg:justify-start gap-4 text-xs text-slate-400">
                <div className="flex items-center space-x-1.5">
                  <ShieldCheck className="w-4 h-4 text-emerald-400" />
                  <span>Google & OTP Verified Voting</span>
                </div>
                <span>•</span>
                <div className="flex items-center space-x-1.5">
                  <Lock className="w-3.5 h-3.5 text-amber-400" />
                  <span>Duplicate-Protected Ledger</span>
                </div>
                <span>•</span>
                <a
                  href="https://cscpo.org/cscpobdawards2026/"
                  target="_blank"
                  rel="noreferrer"
                  className="hover:text-amber-300 underline underline-offset-2 flex items-center space-x-1"
                >
                  <span>cscpo.org/cscpobdawards2026</span>
                  <ExternalLink className="w-3 h-3" />
                </a>
              </div>
            </div>

            {/* Right Visual / Trophy Showcase */}
            <div className="lg:col-span-5 flex justify-center">
              <div className="relative w-full max-w-md">
                {/* Decorative glowing border */}
                <div className="absolute -inset-1 rounded-3xl bg-gradient-to-r from-amber-500/40 via-amber-300/20 to-blue-500/30 blur-lg opacity-70" />

                <div className="relative rounded-3xl overflow-hidden bg-slate-900 border border-amber-500/30 shadow-2xl">
                  <img
                    src="/images/award-trophy-hero.jpg"
                    alt="CSCPO Leadership Award Trophy"
                    className="w-full h-80 sm:h-96 object-cover object-center"
                  />

                  {/* Accolade badge on bottom */}
                  <div className="absolute bottom-4 left-4 right-4 bg-slate-950/85 backdrop-blur-md border border-amber-500/30 rounded-2xl p-4 shadow-xl">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <div className="w-10 h-10 rounded-full bg-amber-500/20 border border-amber-400/40 flex items-center justify-center text-amber-400">
                          <Trophy className="w-5 h-5" />
                        </div>
                        <div>
                          <div className="text-[10px] uppercase font-bold text-amber-400 tracking-wider">
                            Leadership Honors
                          </div>
                          <div className="text-sm font-bold text-white">Recognizing Outstanding Pioneers</div>
                        </div>
                      </div>
                      <span className="px-2.5 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-[10px] font-bold">
                        Honored Finalists
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* LIVE STATS COUNTER STRIP */}
      <section className="bg-slate-900/80 border-b border-slate-800 py-8 relative">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="p-4 bg-slate-950/60 border border-slate-800/80 rounded-2xl text-center">
              <div className="text-2xl sm:text-3xl font-extrabold text-amber-400 tracking-tight">
                {totalApprovedNominees}
              </div>
              <div className="text-xs uppercase font-bold tracking-wider text-slate-400 mt-1">
                Approved Nominees
              </div>
            </div>

            <div className="p-4 bg-slate-950/60 border border-slate-800/80 rounded-2xl text-center">
              <div className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
                {totalVotes.toLocaleString()}
              </div>
              <div className="text-xs uppercase font-bold tracking-wider text-slate-400 mt-1">
                Total Verified Votes
              </div>
            </div>

            <div className="p-4 bg-slate-950/60 border border-slate-800/80 rounded-2xl text-center">
              <div className="text-2xl sm:text-3xl font-extrabold text-emerald-400 tracking-tight">
                {allCategories.length}
              </div>
              <div className="text-xs uppercase font-bold tracking-wider text-slate-400 mt-1">
                Award Categories
              </div>
            </div>

            <div className="p-4 bg-slate-950/60 border border-slate-800/80 rounded-2xl text-center">
              <div className="text-2xl sm:text-3xl font-extrabold text-blue-400 tracking-tight">
                6 Nations
              </div>
              <div className="text-xs uppercase font-bold tracking-wider text-slate-400 mt-1">
                South Asian Participation
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* FEATURED NOMINEES & QUICK VOTING CARDS */}
      <section className="py-16 bg-slate-950">
        <div className="container mx-auto px-4 space-y-8">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
            <div>
              <div className="text-xs font-bold uppercase tracking-widest text-amber-400 mb-1">
                Public Voting Spotlight
              </div>
              <h2 className="text-2xl sm:text-3xl font-extrabold text-white">
                Featured Nominees & Live Standings
              </h2>
              <p className="text-xs sm:text-sm text-slate-400 mt-1">
                Approved industry leaders currently competing for the CSCPO South Asian Leadership Award.
              </p>
            </div>

            <Link
              href="/voting"
              className="inline-flex items-center space-x-1.5 text-xs sm:text-sm font-bold text-amber-400 hover:text-amber-300 transition"
            >
              <span>Browse All {totalApprovedNominees} Nominees</span>
              <ArrowRight className="w-4 h-4" />
            </Link>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {displayFeatured.map((nominee) => (
              <NomineeCard key={nominee.id} nominee={nominee} />
            ))}
          </div>

          <div className="text-center pt-4">
            <Link
              href="/voting"
              className="px-6 py-3 rounded-xl bg-slate-900 hover:bg-slate-850 border border-slate-700 text-slate-200 text-xs font-bold transition inline-flex items-center space-x-2"
            >
              <span>Open Complete Public Voting Gallery</span>
              <ArrowRight className="w-4 h-4 text-amber-400" />
            </Link>
          </div>
        </div>
      </section>

      {/* AWARD CATEGORIES EXPLORER */}
      <section className="py-16 bg-slate-900/60 border-y border-slate-800">
        <div className="container mx-auto px-4 space-y-10">
          <div className="text-center max-w-2xl mx-auto space-y-2">
            <div className="text-xs font-bold uppercase tracking-widest text-amber-400">
              Excellence Across Disciplines
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-white">
              Official Award Categories
            </h2>
            <p className="text-xs sm:text-sm text-slate-400">
              Spanning executive leadership, multimodal freight, ESG procurement, AI technology, and women leaders.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {allCategories.map((cat) => (
              <Link
                key={cat.id}
                href={`/voting?category=${cat.slug}`}
                className="group p-5 bg-slate-950/80 hover:bg-slate-950 border border-slate-800 hover:border-amber-500/40 rounded-2xl transition duration-300 flex flex-col justify-between space-y-3"
              >
                <div className="space-y-2">
                  <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400 group-hover:scale-110 transition-transform">
                    <Award className="w-5 h-5" />
                  </div>
                  <h3 className="font-bold text-white text-base group-hover:text-amber-400 transition-colors">
                    {cat.name}
                  </h3>
                  {cat.nameBn && (
                    <p className="text-xs text-amber-400/80 font-bangla font-medium">{cat.nameBn}</p>
                  )}
                  <p className="text-xs text-slate-400 leading-relaxed line-clamp-2">
                    {cat.description}
                  </p>
                </div>

                <div className="flex items-center justify-between text-xs font-semibold text-slate-400 group-hover:text-amber-300 pt-2 border-t border-slate-800/80">
                  <span>View Category Nominees</span>
                  <ChevronRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* HOW TO VOTE: 4 TRANSPARENT STEPS */}
      <section className="py-16 bg-slate-950">
        <div className="container mx-auto px-4 space-y-12">
          <div className="text-center max-w-2xl mx-auto space-y-2">
            <div className="text-xs font-bold uppercase tracking-widest text-amber-400">
              Fair & Secure Process
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-white">How to Cast Your Vote</h2>
            <p className="text-xs sm:text-sm text-slate-400">
              CSCPO utilizes institutional voter verification to maintain 100% fair and tamper-proof award standings.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <div className="p-5 bg-slate-900/60 border border-slate-800 rounded-2xl relative">
              <div className="w-8 h-8 rounded-lg bg-amber-500 text-slate-950 font-extrabold text-sm flex items-center justify-center mb-3">
                01
              </div>
              <h3 className="font-bold text-white text-sm mb-1">Select Nominee</h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                Browse approved nominees by category or country, and inspect their verified professional profile & achievements.
              </p>
            </div>

            <div className="p-5 bg-slate-900/60 border border-slate-800 rounded-2xl relative">
              <div className="w-8 h-8 rounded-lg bg-amber-500 text-slate-950 font-extrabold text-sm flex items-center justify-center mb-3">
                02
              </div>
              <h3 className="font-bold text-white text-sm mb-1">Verify Identity</h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                Sign in with Google, Facebook, or instant Email OTP. We verify voter accounts to prevent fake bots and duplicate voting.
              </p>
            </div>

            <div className="p-5 bg-slate-900/60 border border-slate-800 rounded-2xl relative">
              <div className="w-8 h-8 rounded-lg bg-amber-500 text-slate-950 font-extrabold text-sm flex items-center justify-center mb-3">
                03
              </div>
              <h3 className="font-bold text-white text-sm mb-1">Anti-Bot & Confirm</h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                Complete a brief anti-bot security challenge and confirm your single vote for the chosen award category.
              </p>
            </div>

            <div className="p-5 bg-slate-900/60 border border-slate-800 rounded-2xl relative">
              <div className="w-8 h-8 rounded-lg bg-amber-500 text-slate-950 font-extrabold text-sm flex items-center justify-center mb-3">
                04
              </div>
              <h3 className="font-bold text-white text-sm mb-1">Official Digital Receipt</h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                Receive an encrypted vote receipt code and celebrate your nominee by sharing their voting link to LinkedIn & WhatsApp!
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* PREVIOUS WINNERS HIGHLIGHT */}
      <section className="py-16 bg-slate-900/50 border-t border-slate-800">
        <div className="container mx-auto px-4 space-y-8">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
            <div>
              <div className="text-xs font-bold uppercase tracking-widest text-amber-400 mb-1">
                Hall of Fame
              </div>
              <h2 className="text-2xl sm:text-3xl font-extrabold text-white">
                Honoring Past Award Recipients
              </h2>
              <p className="text-xs sm:text-sm text-slate-400 mt-1">
                Celebrating distinguished past laureates of the CSCPO South Asian Leadership Awards.
              </p>
            </div>

            <Link
              href="/winners"
              className="inline-flex items-center space-x-1.5 text-xs sm:text-sm font-bold text-amber-400 hover:text-amber-300 transition"
            >
              <span>View Full Winners Archive</span>
              <ArrowRight className="w-4 h-4" />
            </Link>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
            {winners.map((winner) => (
              <div
                key={winner.id}
                className="bg-slate-950 border border-slate-800 rounded-2xl overflow-hidden p-4 space-y-3 flex flex-col justify-between"
              >
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30">
                      Winner {winner.year}
                    </span>
                    <span className="text-xs text-slate-400">{winner.country}</span>
                  </div>

                  <div className="flex items-center space-x-3">
                    <img
                      src={winner.photoUrl}
                      alt={winner.winnerName}
                      className="w-12 h-12 rounded-xl object-cover border border-amber-500/30"
                    />
                    <div>
                      <h4 className="font-bold text-white text-sm">{winner.winnerName}</h4>
                      <p className="text-[11px] text-slate-400">{winner.designation}</p>
                    </div>
                  </div>

                  <p className="text-xs text-slate-300 leading-relaxed">{winner.achievement}</p>
                </div>

                <div className="pt-2 border-t border-slate-800/80 text-[10px] text-amber-400/90 font-medium">
                  {winner.categoryName}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ESTEEMED SPONSORS & STRATEGIC SUPPORTERS SECTION */}
      {(sponsors.length > 0 || supporters.length > 0) && (
        <section className="py-16 bg-slate-900/60 border-t border-slate-800">
          <div className="container mx-auto px-4 space-y-12">
            {/* Sponsors Block */}
            {sponsors.length > 0 && (
              <div className="space-y-6">
                <div className="text-center max-w-xl mx-auto space-y-1">
                  <div className="inline-flex items-center space-x-1.5 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/20 text-amber-300 text-xs font-semibold">
                    <Handshake className="w-3.5 h-3.5 text-amber-400" />
                    <span>Official Corporate Sponsors</span>
                  </div>
                  <h3 className="text-2xl font-extrabold text-white">Our Esteemed Sponsors</h3>
                  <p className="text-xs text-slate-400">
                    Industry-leading enterprises championing supply chain excellence and regional economic resilience.
                  </p>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-4 gap-4">
                  {sponsors.map((sp) => (
                    <a
                      key={sp.id}
                      href={sp.websiteUrl || "#"}
                      target={sp.websiteUrl ? "_blank" : undefined}
                      rel="noreferrer"
                      className="group p-5 bg-slate-950 border border-slate-800 hover:border-amber-500/50 rounded-2xl flex flex-col items-center justify-between text-center space-y-3 transition duration-300 shadow-lg hover:shadow-amber-500/10"
                    >
                      <span className="px-2.5 py-0.5 rounded-full bg-amber-500/15 border border-amber-500/30 text-amber-300 font-bold text-[10px] uppercase tracking-wider">
                        {sp.tier}
                      </span>
                      <div className="w-24 h-24 rounded-xl overflow-hidden bg-slate-900 border border-slate-800 flex items-center justify-center p-2 group-hover:scale-105 transition-transform">
                        <img
                          src={sp.logoUrl || "/images/cscpo-award-logo.png"}
                          alt={sp.name}
                          className="w-full h-full object-contain"
                        />
                      </div>
                      <div>
                        <div className="font-bold text-white text-xs group-hover:text-amber-400 transition-colors">
                          {sp.name}
                        </div>
                        {sp.websiteUrl && (
                          <div className="text-[10px] text-slate-500 group-hover:text-slate-400 flex items-center justify-center space-x-1 mt-0.5">
                            <span>Visit Partner</span>
                            <ExternalLink className="w-2.5 h-2.5" />
                          </div>
                        )}
                      </div>
                    </a>
                  ))}
                </div>
              </div>
            )}

            {/* Supporters & Partners Block */}
            {supporters.length > 0 && (
              <div className="space-y-6 pt-4 border-t border-slate-800/80">
                <div className="text-center max-w-xl mx-auto space-y-1">
                  <div className="inline-flex items-center space-x-1.5 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-300 text-xs font-semibold">
                    <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Institutional & Supporting Organizations</span>
                  </div>
                  <h3 className="text-2xl font-extrabold text-white">Supported By</h3>
                  <p className="text-xs text-slate-400">
                    Distinguished academic institutions, professional associations, and media bodies supporting this initiative.
                  </p>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-4 gap-4">
                  {supporters.map((sup) => (
                    <a
                      key={sup.id}
                      href={sup.websiteUrl || "#"}
                      target={sup.websiteUrl ? "_blank" : undefined}
                      rel="noreferrer"
                      className="group p-5 bg-slate-950 border border-slate-800 hover:border-emerald-500/50 rounded-2xl flex flex-col items-center justify-between text-center space-y-3 transition duration-300 shadow-lg"
                    >
                      <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 font-bold text-[10px] uppercase tracking-wider">
                        {sup.role}
                      </span>
                      <div className="w-20 h-20 rounded-xl overflow-hidden bg-slate-900 border border-slate-800 flex items-center justify-center p-2 group-hover:scale-105 transition-transform">
                        <img
                          src={sup.logoUrl || "/images/cscpo-award-logo.png"}
                          alt={sup.name}
                          className="w-full h-full object-contain"
                        />
                      </div>
                      <div>
                        <div className="font-bold text-white text-xs group-hover:text-emerald-400 transition-colors">
                          {sup.name}
                        </div>
                        {sup.websiteUrl && (
                          <div className="text-[10px] text-slate-500 group-hover:text-slate-400 flex items-center justify-center space-x-1 mt-0.5">
                            <span>Learn More</span>
                            <ExternalLink className="w-2.5 h-2.5" />
                          </div>
                        )}
                      </div>
                    </a>
                  ))}
                </div>
              </div>
            )}
          </div>
        </section>
      )}

      {/* SUBMISSION CALLOUT BANNER */}
      <section className="py-16 bg-gradient-to-r from-amber-600/20 via-slate-900 to-amber-950/30 border-t border-slate-800">
        <div className="container mx-auto px-4 text-center max-w-3xl space-y-5">
          <div className="w-14 h-14 rounded-2xl bg-amber-500/20 border border-amber-400/40 flex items-center justify-center text-amber-400 mx-auto">
            <Award className="w-7 h-7" />
          </div>

          <h2 className="text-2xl sm:text-4xl font-extrabold text-white">
            Do You Know an Exceptional Supply Chain Leader?
          </h2>

          <p className="text-sm text-slate-300 leading-relaxed">
            Nominations are open to professionals and organizations across South Asia. Submit an individual or
            self-nominate before the official review deadline.
          </p>

          <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
            <Link
              href="/nominate"
              className="px-8 py-3.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-sm tracking-wide shadow-xl shadow-amber-500/20 transition"
            >
              Submit Nomination Form
            </Link>

            <Link
              href="/admin"
              className="px-6 py-3.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-amber-500/40 text-amber-300 font-bold text-sm transition flex items-center space-x-1.5"
            >
              <ShieldCheck className="w-4 h-4" />
              <span>Admin Portal Login</span>
            </Link>

            <Link
              href="/srs"
              className="px-6 py-3.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-200 font-semibold text-sm transition"
            >
              System Specs (SRS)
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
