import { redirect } from "next/navigation";

export default function NomineesRedirect() {
  redirect("/voting");
}
