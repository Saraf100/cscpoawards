import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";
import ClientLayoutShell from "@/components/ClientLayoutShell";

export const metadata: Metadata = {
  title: "CSCPO South Asian Leadership Awards | Nominations & Public Voting",
  description:
    "Official nomination submission, verified public voting, and award transparency ledger for the Council of Supply Chain Professionals Organization (CSCPO) South Asian Leadership Awards.",
  keywords: [
    "CSCPO",
    "South Asian Leadership Awards",
    "Supply Chain Awards Bangladesh",
    "Logistics Awards",
    "Procurement Leadership",
    "Public Voting techawardbd",
  ],
  icons: {
    icon: "/images/cscpo-award-logo.png",
  },
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" className="dark">
      <body className="bg-slate-950 text-slate-100 antialiased selection:bg-amber-500 selection:text-slate-950">
        <ClientLayoutShell>{children}</ClientLayoutShell>
      </body>
    </html>
  );
}
